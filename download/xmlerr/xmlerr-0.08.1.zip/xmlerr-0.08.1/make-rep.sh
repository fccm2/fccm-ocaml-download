
make xmlerr.cma
make xmlerr.cmxa

make xmlerr_report.cmi
make xmlerr_report.cmo

#end
