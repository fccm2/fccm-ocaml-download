
make xmlerr.cma
make xmlerr.cmxa

#end
