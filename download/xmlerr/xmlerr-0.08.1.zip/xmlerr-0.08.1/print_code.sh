cd `dirname $0`

#XMLERR_DIR="$HOME/xmlerr"
XMLERR_DIR="./"

ocaml unix.cma \
  -I $XMLERR_DIR xmlerr.cma \
  print_code.ml $*

