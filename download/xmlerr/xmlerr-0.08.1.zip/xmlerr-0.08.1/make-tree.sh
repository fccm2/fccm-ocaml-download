
make xmlerr.cma
make xmlerr.cmxa

make xmlerr_tree.cmi
make xmlerr_tree.cmo

#end
