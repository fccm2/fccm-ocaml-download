alias ocaml='ocaml -I /mnt/chromeos/MyFiles/Console/usr/lib/ocaml/unix unix.cma -I /mnt/chromeos/MyFiles/Console/usr/lib/ocaml/str str.cma'
ocaml xmlerr.cmo xmlerr_tree.cmo test_tree.ml tree.html
