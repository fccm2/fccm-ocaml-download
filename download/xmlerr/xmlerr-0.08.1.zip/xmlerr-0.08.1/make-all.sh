
make xmlerr.cma
make xmlerr.cmxa

make utils
make tmpl
make utmpl

make xmlerr_tree.cmi
make xmlerr_tree.cmo

make xmlerr_report.cmi
make xmlerr_report.cmo

#end
