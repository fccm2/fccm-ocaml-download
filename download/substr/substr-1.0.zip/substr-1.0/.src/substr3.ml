
(** [count_sub s sub] returns how many times [sub] appears in [s] *)
let count_sub s sub =
  if sub = "" then invalid_arg "count_sub" else
  if s = "" then 0 else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then 0 else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i n =
    if i >= n1 then n else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then aux (i+1) (n+1) else aux (i+1) n
    end
    else aux (i+1) n
  in
  aux 0 0

let test s sub =
  print_endline begin
    s ^ " count_sub " ^ sub ^ ": " ^
    string_of_int (count_sub s sub)
  end;
;;

let () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test s "fox";
  test s "foxy";
  test s "the";
;;

