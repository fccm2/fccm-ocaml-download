
(** [sub_indices s sub] returns a list of all the indices where the sub-string [sub] appears in [s] *)
let sub_indices s sub =
  if sub = "" then invalid_arg "sub_indices" else
  if s = "" then [] else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then [] else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i acc =
    if i < 0 then acc else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then aux (i-1) (i::acc) else aux (i-1) acc
    end
    else aux (i-1) acc
  in
  aux (n1-1) []

let test s sub =
  print_endline begin
    s ^ " sub_indices " ^ sub ^ ": " ^
    String.concat " "
      (List.map string_of_int (sub_indices s sub))
  end;
;;

let () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test s "fox";
  test s "foxy";
  test s "the";
;;

