
(** [sub_index s sub] returns the first index of the sub-string [sub] in [s], or -1 if not found *)
let sub_index s sub =
  if sub = "" then invalid_arg "sub_index" else
  if s = "" then -1 else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then -1 else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i =
    if i >= n1 then -1 else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then i else aux (i+1)
    end
    else aux (i+1)
  in
  aux 0

let test s sub =
  print_endline begin
    s ^ " contains_sub " ^ sub ^ ": " ^
    let i = sub_index s sub in
    ( if i <> -1
      then "Yes: " ^ string_of_int i
      else "No" )
  end;
;;

let () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test s "fox";
  test s "foxy";
  test s "quick";
;;

