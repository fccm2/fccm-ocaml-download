
(** [contains_sub s sub] returns true if the string [s] contains the sub-string [sub] *)
let contains_sub s sub =
  if sub = "" then invalid_arg "contains_sub" else
  if s = "" then false else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then false else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i =
    if i >= n1 then false else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then true else aux (i+1)
    end
    else aux (i+1)
  in
  aux 0

let test s sub =
  print_endline begin
    s ^ " contains_sub " ^ sub ^ ": " ^
    ( if contains_sub s sub
      then "Yes"
      else "No" )
  end;
;;

let () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test s "fox";
  test s "foxy";
  test s "dog";
  test s "dogy";
;;

