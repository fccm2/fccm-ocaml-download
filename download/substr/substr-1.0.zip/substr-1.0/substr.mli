(** Sub-Strings *)

val contains_sub : string -> string -> bool
(** [contains_sub s sub] returns true if the string [s] contains the sub-string [sub] *)

val sub_index : string -> string -> int
(** [sub_index s sub] returns the first index of the sub-string [sub] in [s], or -1 if not found *)

val count_sub : string -> string -> int
(** [count_sub s sub] returns how many times [sub] appears in [s] *)

val sub_indices : string -> string -> int list
(** [sub_indices s sub] returns a list of all the indices where the sub-string [sub] appears in [s] *)

(**/**)

val test1 : string -> string -> unit
val test2 : string -> string -> unit
val test3 : string -> string -> unit
val test4 : string -> string -> unit

val main_test1 : unit -> unit
val main_test2 : unit -> unit
val main_test3 : unit -> unit
val main_test4 : unit -> unit

