(* sub-strings *)
(* author: fccm *)

(** [contains_sub s sub] returns true if the string [s] contains the sub-string [sub] *)
let contains_sub s sub =
  if sub = "" then invalid_arg "contains_sub" else
  if s = "" then false else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then false else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i =
    if i >= n1 then false else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then true else aux (i+1)
    end
    else aux (i+1)
  in
  aux 0

let test1 s sub =
  print_endline begin
    s ^ " contains_sub " ^ sub ^ ": " ^
    ( if contains_sub s sub
      then "Yes"
      else "No" )
  end;
;;

let main_test1 () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test1 s "fox";
  test1 s "foxy";
  test1 s "dog";
  test1 s "dogy";
;;


(** [sub_index s sub] returns the first index of the sub-string [sub] in [s], or -1 if not found *)
let sub_index s sub =
  if sub = "" then invalid_arg "sub_index" else
  if s = "" then -1 else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then -1 else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i =
    if i >= n1 then -1 else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then i else aux (i+1)
    end
    else aux (i+1)
  in
  aux 0

let test2 s sub =
  print_endline begin
    s ^ " contains_sub " ^ sub ^ ": " ^
    let i = sub_index s sub in
    ( if i <> -1
      then "Yes: " ^ string_of_int i
      else "No" )
  end;
;;

let main_test2 () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test2 s "fox";
  test2 s "foxy";
  test2 s "quick";
;;


(** [count_sub s sub] returns how many times [sub] appears in [s] *)
let count_sub s sub =
  if sub = "" then invalid_arg "count_sub" else
  if s = "" then 0 else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then 0 else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i n =
    if i >= n1 then n else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then aux (i+1) (n+1) else aux (i+1) n
    end
    else aux (i+1) n
  in
  aux 0 0

let test3 s sub =
  print_endline begin
    s ^ " count_sub " ^ sub ^ ": " ^
    string_of_int (count_sub s sub)
  end;
;;

let main_test3 () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test3 s "fox";
  test3 s "foxy";
  test3 s "the";
;;


(** [sub_indices s sub] returns a list of all the indices where the sub-string [sub] appears in [s] *)
let sub_indices s sub =
  if sub = "" then invalid_arg "sub_indices" else
  if s = "" then [] else
  let n1 = String.length s in
  let n2 = String.length sub in
  if n1 < n2 then [] else
  let rec cmp i j =
    match i < n1, j < n2 with
    | false, false -> true
    | true, false -> true
    | false, true -> false
    | true, true ->
        if s.[i] = sub.[j]
        then cmp (i+1) (j+1)
        else false
  in
  let rec aux i acc =
    if i < 0 then acc else
    if s.[i] = sub.[0]
    then begin
      let found = cmp (i+1) 1 in
      if found then aux (i-1) (i::acc) else aux (i-1) acc
    end
    else aux (i-1) acc
  in
  aux (n1-1) []

let test4 s sub =
  print_endline begin
    s ^ " sub_indices " ^ sub ^ ": " ^
    String.concat " "
      (List.map string_of_int (sub_indices s sub))
  end;
;;

let main_test4 () =
  let s = "the quick brown fox jumps over the lazy dog" in
  test4 s "fox";
  test4 s "foxy";
  test4 s "the";
;;

