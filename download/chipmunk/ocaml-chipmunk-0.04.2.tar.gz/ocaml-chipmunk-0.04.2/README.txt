
  This archive contains OCaml bindings for the
  Chipmunk 2D physics library:
    https://chipmunk-physics.net/

  This bindings was tested with Chipmunk version 5.2.0
  which can still be found from:
    https://chipmunk-physics.net/release/
  or included in this archive.

  The Makefile uses the local Chipmunk sources.
  To build this dependency:

    cd ./Chipmunk-5.2.0/
    cmake .
    make chipmunk_static

  Then come back in this directory and run 'make'
  to compile the binding, and 'make test' to launch
  the "moon buggy" demo.

  The demo riquire the OpenGL binding called glMLite,
  which can be found at:
    http://decapode314.free.fr/ocaml/GL/

  run 'make doc' to generate the interface ocamldoc
  documentation. Two interfaces are provided, a high
  level object oriented one, and a low level one.

  The commented demo 'moon_buggy.ml' uses the high
  level interface, and the demo 'demo_dist.ml' uses
  the low level one.

  You can choose between two available installations.
  'make install' will apply a manual installation, and
  'make install_findlib' for the findlib users.
  Findlib users can compile stuff with:
    ocamlfind ocamlc -linkpkg -package chipmunk foo.ml
  and for those who prefer the traditional way, just:
    ocamlc -I +chipmunk chipmunk.cma foo.ml

  You can use this binding, either under the terms
  of the Zlib license, or at your option, along
  the terms of the Expat/X11/Zlib license.

  Comments and feedbacks are wellcome, write to
    <monnier.florent (at) gmail.com>

