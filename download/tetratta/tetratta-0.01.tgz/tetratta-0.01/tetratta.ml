(*
  Tetratta, a little game similar to chinese checkers,
  but with a 3D tetrahedral board.
  Copyright (C) 2009  Florent Monnier
  contact: <fmonnier@linux-nantes.org>

  This program is free software: you can redistribute it and/or
  modify it under the terms of the GNU General Public License as
  published by the Free Software Foundation, either version 3 of
  the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*)
open GL
open Glu
open Glut

(* side of the board,
   so also the number of piece of each color *)
let s =
  try int_of_string Sys.argv.(1)
  with _ -> 5
;;

let anglex = ref (-41)
let angley = ref (-5)
let xold = ref 0
let yold = ref 0
let b_down = ref false

let texy = ref 0.
let tex_rot = ref 0.

(* - the board is a 3D board (classic boards are generally 2D)
 * - only a portion of this matrix represents the board of the game
 *   because the 3D board is tetrahedral and is a part of the cube
 *   that the matrix represents.
 * - here are what integers in the matrix represents:
 *   | 0 -> out of the board
 *          (cells of the cube that are not part of the tetrahedral board)
 *   | 1 -> empty cell
 *   | 2 -> red piece
 *   | 3 -> selected red piece
 *   | 4 -> blue piece
 *   | 5 -> selected blue piece
 *   | 6 -> target
 *          (targets indicate where a selected piece can go)
 *)
let board =
  Bigarray.Array3.create
      Bigarray.int8_unsigned Bigarray.c_layout s s s
;;

(* depth of each cell, used for picking (selection) *)
let dep =
  Bigarray.Array3.create
      Bigarray.float32 Bigarray.c_layout s s s
;;

let () =
  (* first fill everything with disallowed tag *)
  for i=0 to pred s do
    for j=0 to pred s do
      for k=0 to pred s do
        board.{i,j,k} <- 0;
      done;
    done;
  done;
;;

let () =
  for k=0 to pred s do
    let k' = (pred s) - k in
    for j=0 to k do
      for i=0 to k' do
        board.{i,k,j} <- 1;  (* empty (but accessible) cells *)
      done;
    done;
  done;
;;

let () =
  for i=0 to pred s do
    board.{i,0,0} <- 2; (* red pieces *)
  done;
  for k=0 to (pred s) do
    board.{0,(pred s),k} <- 4; (* blue pieces *)
  done;
;;

let pos =
  (* 3D XYZ positions for each IJK pieces *)
  Array.init s (fun _ ->
    Array.make_matrix s s (0.0, 0.0, 0.0))
;;

let () =
  (* fill the 'pos' positions matrix *)
  for k=0 to pred s do
    let k' = (pred s) - k in
      let x = ref ((float k) *. 0.5)
      and y = ref ((float k) *. 0.9)
      and z = ref ((float k) *. -0.5) in
      for j=0 to k do
        for i=0 to k' do
          pos.(i).(k).(j) <- (!x +. (float i), !y, !z);
        done;
        z := !z +. 1.0;
      done;
  done;
;;


(* test that all blue pieces have reached the opposite line *)
let blue_reached() =
  let all = ref true in
  for i=0 to pred s do
    all := !all && (board.{i,0,0} = 4);
  done;
  (!all)
;;

(* test that all red pieces have reached the opposite line *)
let red_reached() =
  let all = ref true in
  for k=0 to (pred s) do
    all := !all && (board.{0,(pred s),k} = 2);
  done;
  (!all)
;;


(* when a piece is selected,
   show (with targets) the possible moves *)
let put_targets ~i ~j ~k =
  let lst = [
    (i,   j+1, k  );  (* go to the upper floor *)
    (i,   j+1, k+1);
    (i-1, j+1, k  );
    (i-1, j+1, k+1);

    (i,   j-1, k-1);  (* go to the lower floor *)
    (i,   j-1, k  );
    (i+1, j-1, k-1);
    (i+1, j-1, k  );

    (i-1, j,   k  );  (* go to places at the same floor *)
    (i+1, j,   k  );
    (i,   j,   k-1);
    (i,   j,   k+1);
  ] in
  let lst =
    (* remove coordinates out of the main cube matrix *)
    List.filter
      (fun (i,j,k) ->
         (i >= 0) &&
         (j >= 0) &&
         (k >= 0) &&
         (i <= s-1) &&
         (j <= s-1) &&
         (k <= s-1)
      ) lst
  in
  let lst =
    List.filter
      (fun (i,j,k) ->
        match board.{i,j,k} with
        | 0 -> false  (* asserts inside of the tetrahedral board *)
        | 1 -> true   (* empty cells where we can go *)
        | _ -> false  (* cell where there's something yet *)
      ) lst
  in
  List.iter
    (fun (i,j,k) ->
      board.{i,j,k} <- 6;
    ) lst;
;;


(* remove targets *)
let rem_targets () =
  for i=0 to pred s do
    for j=0 to pred s do
      for k=0 to pred s do
        if board.{i,j,k} = 6 then 
          board.{i,j,k} <- 1;
      done;
    done;
  done;
;;


(* unselect all selected pieces *)
let unsel _i _j _k =
  for i=0 to pred s do
    for j=0 to pred s do
      for k=0 to pred s do
        if not((_i,_j,_k) = (i,j,k)) then
          match board.{i,j,k} with
          | 3 -> board.{i,j,k} <- 2
          | 5 -> board.{i,j,k} <- 4
          | _ -> ()
      done;
    done;
  done;
;;

let make_move ~i:_i ~j:_j ~k:_k =
  try
    for i=0 to pred s do
      for j=0 to pred s do
        for k=0 to pred s do
          match board.{i,j,k} with
          | 3 ->
              board.{i,j,k} <- 1;     (* remove the old position *)
              board.{_i,_j,_k} <- 2;  (* put it at the new position *)
              raise Exit;
          | 5 ->
              board.{i,j,k} <- 1;     (* remove the old position *)
              board.{_i,_j,_k} <- 4;  (* put it at the new position *)
              raise Exit;
          | _ -> ()
        done;
      done;
    done;
    assert(false)
  with Exit -> ()
;;


let draw_game ~mode =
  glLoadIdentity();
  glTranslate 0.0 0.0 ((float s) *. -1.6);
  glRotate (float(- !angley)) 1.0 0.0 0.0;
  glRotate (float(- !anglex)) 0.0 1.0 0.0;

  let p = (float(pred s)) /. -2.0 in
  glTranslate p p 0.0;

  (* draw one tetrahedron *)
  let draw_tretra() =
    glBegin GL_LINES;
      glVertex3 (0.0) (0.0) ( 0.0); (* A *)
      glVertex3 (1.0) (0.0) ( 0.0); (* B *)

      glVertex3 (0.5) (0.9) (-0.5); (* C *)
      glVertex3 (0.5) (0.9) ( 0.5); (* D *)

      glVertex3 (0.0) (0.0) ( 0.0); (* A *)
      glVertex3 (0.5) (0.9) (-0.5); (* C *)

      glVertex3 (0.0) (0.0) ( 0.0); (* A *)
      glVertex3 (0.5) (0.9) ( 0.5); (* D *)

      glVertex3 (1.0) (0.0) ( 0.0); (* B *)
      glVertex3 (0.5) (0.9) (-0.5); (* C *)

      glVertex3 (1.0) (0.0) ( 0.0); (* B *)
      glVertex3 (0.5) (0.9) ( 0.5); (* D *)
    glEnd();
  in

  (* color of the "board" *)
  glColor3 0.0 0.0 0.0;

  (* draw the "board" *)
  if mode = GL_RENDER then
  begin
    for k=0 to (s - 2) do
      let k' = (s - 2) - k in
      glPushMatrix();
      glTranslate ((float k) *. 0.5) ((float k) *. 0.9) ((float k) *. -0.5);
      for j=0 to k do
        for i=0 to k' do
          glPushMatrix();
            glTranslate (float i) 0.0 0.0;
            draw_tretra();
          glPopMatrix();
        done;
      glTranslate 0.0 0.0 1.0;
      done;
      glPopMatrix();
    done;
  end;


  for i=0 to pred s do
    if mode = GL_SELECT then glLoadName i;
    for j=0 to pred s do
      if mode = GL_SELECT then glPushName j;
      for k=0 to pred s do
        if mode = GL_SELECT then glPushName k;

        glPushMatrix();
        glTranslatev pos.(i).(j).(k);

        let m = glGetMatrix Get.GL_MODELVIEW_MATRIX in
        let z = m.(3).(2) in
        dep.{i,j,k} <- z;  (* save the depth of a piece *)

        begin match board.{i,j,k} with
        | 0 ->  (* out of the board *)
            ()
        | 1 ->  (* empty cell *)
            glColor3v (1.0, 1.0, 1.0);
            glutSolidSphere ~radius:0.08 ~slices:8 ~stacks:6;
        | 2 ->  (* red piece *)
            glColor3v (1.0, 0.0, 0.0);
            glutSolidSphere ~radius:0.3 ~slices:10 ~stacks:10;
        | 3 ->  (* selected red piece *)
            glColor3v (1.0, 0.5, 0.2);
            glutSolidSphere ~radius:0.3 ~slices:10 ~stacks:10;
        | 4 ->  (* blue piece *)
            glColor3v (0.0, 0.5, 1.0);
            glutSolidSphere ~radius:0.3 ~slices:10 ~stacks:10;
        | 5 ->  (* selected blue piece *)
            glColor3v (0.2, 0.7, 1.0);
            glutSolidSphere ~radius:0.3 ~slices:10 ~stacks:10;
        | 6 ->  (* target *)
            glColor3v (1.0, 1.0, 0.0);
            glutSolidSphere ~radius:0.12 ~slices:8 ~stacks:6;
        | _ -> assert(false)
        end;
        glPopMatrix();

        if mode = GL_SELECT then glPopName();
      done;
      if mode = GL_SELECT then glPopName();
    done;
  done;
;;

let display() =
  glClear [GL_COLOR_BUFFER_BIT; GL_DEPTH_BUFFER_BIT];
  draw_game GL_RENDER;
  glFlush();
  glutSwapBuffers();
;;


let process_hits ~hits ~buffer =

  let select_buffer_get ar i =
    let res = Bigarray.Array1.get ar i in
    assert(res >= 0n);
    (Nativeint.to_int res)
  in
  let c = ref 0 in

  let sli = ref [] in

  (*  for each hit  *)
  for i = 0 to pred hits do
    let names = select_buffer_get buffer !c in
    incr c;
    incr c;  (* z1 *)
    incr c;  (* z2 *)
    let arn = Array.make names 0 in
    for j = 0 to pred names do
      let name = select_buffer_get buffer !c in
      arn.(j) <- name;
      incr c;
    done;
    begin
      let ijk = (arn.(0), arn.(1), arn.(2)) in
      sli := ijk :: !sli;
    end;
  done;

  match !sli with [] -> ()
  | hd::tl ->
      (* get only the nearest *)
      let (i,j,k) =
        let sort (i1,j1,k1) (i2,j2,k2) =
          let depth1 = dep.{i1,j1,k1}
          and depth2 = dep.{i2,j2,k2} in
          if depth1 > depth2
          then (i1,j1,k1)
          else (i2,j2,k2)
        in
        List.fold_left sort hd tl
      in
      begin match board.{i,j,k} with
      | 2 ->
          board.{i,j,k} <- 3;  (* select a red piece *)
          unsel i j k;
          rem_targets ();
          put_targets i j k;
      | 3 ->
          board.{i,j,k} <- 2;  (* unselect a red piece *)
          rem_targets ();
      | 4 ->
          board.{i,j,k} <- 5;  (* select a blue piece *)
          unsel i j k;
          rem_targets ();
          put_targets i j k;
      | 5 ->
          board.{i,j,k} <- 4;  (* unselect a blue piece *)
          rem_targets ();
      | 6 ->                   (* the player has selected a target *)
          make_move ~i ~j ~k;
          rem_targets ();
          if blue_reached() then Printf.printf "Blue wins\n%!";
          if red_reached()  then Printf.printf "Red wins\n%!";
      | _ -> ()
      end;
;;


let mouse ~button ~state ~x ~y =
  match button, state with
  | GLUT_LEFT_BUTTON, GLUT_DOWN ->
      b_down := true;
      xold := x;
      yold := y;

  | GLUT_LEFT_BUTTON, GLUT_UP ->
      b_down := false;

  | GLUT_RIGHT_BUTTON, GLUT_UP -> ()
  | GLUT_RIGHT_BUTTON, GLUT_DOWN ->
      let buffer_size = 4096 in
      let new_select_buffer =
        Bigarray.Array1.create Bigarray.nativeint Bigarray.c_layout
      in
      let select_buffer = new_select_buffer buffer_size in

      let (viewport_x,
           viewport_y,
           viewport_w,
           viewport_h) as viewport = glGetInteger4 Get.GL_VIEWPORT in

      glSelectBufferBA select_buffer;
      ignore(glRenderMode GL_SELECT);

      glInitNames();
      glPushName 0;

      glMatrixMode GL_PROJECTION;
      glPushMatrix();
      glLoadIdentity();
      (* create a pixel picking region near cursor location *)
      gluPickMatrix (float x) (float(viewport_h - y)) 5.0 5.0 viewport;

      gluPerspective 50.0 ( (float(viewport_w - viewport_x)) /. 
                            (float(viewport_h - viewport_y)) ) 0.02 30.0;

      glMatrixMode GL_MODELVIEW;

        draw_game GL_SELECT;

      glMatrixMode GL_PROJECTION;
      glPopMatrix();
      glMatrixMode GL_MODELVIEW;

      let hits = glRenderMode GL_RENDER in

        process_hits ~hits ~buffer:select_buffer;
      glutPostRedisplay();

  | _ -> ()
;;

let motion ~x ~y =
  if !b_down then
  begin
    anglex := !anglex + (!xold - x);
    angley := !angley + (!yold - y);
    if !angley > 90 then angley := 90;  (* prevents to put the head upsidedown *)
    if !angley < -90 then angley := -90;
    glutPostRedisplay();
  end;
  
  xold := x;
  yold := y;
;;

let keyboard ~key ~x ~y =
  match key with
  | 'e' -> Printf.printf " %d %d\n%!" !anglex !angley;
  | '\027' | 'q' -> exit(0)
  | _ -> ()
;;

let reshape ~width:w ~height:h =
  glViewport 0 0 w h;
  glMatrixMode GL_PROJECTION;
  glLoadIdentity();
  gluPerspective ~fovy:50.0 ~aspect:((float w) /. (float h)) ~zNear:0.2 ~zFar:80.0;
  glMatrixMode GL_MODELVIEW;
;;

let () =
  ignore(glutInit Sys.argv);
  glutInitDisplayMode [GLUT_RGB; GLUT_DOUBLE; GLUT_DEPTH];
  glutInitWindowSize ~width:800  ~height:600;
  ignore(glutCreateWindow ~title:"Tetratta");

  for i=0 to Array.length Sys.argv - 1 do
    if Sys.argv.(i) = "-fs" then
      glutFullScreen();
  done;

  glClearColor 0.8 0.8 0.8 0.0;
  glShadeModel GL_FLAT;
  glEnable GL_DEPTH_TEST;

  glutDisplayFunc ~display;
  glutKeyboardFunc ~keyboard;
  glutReshapeFunc ~reshape;

  glutMouseFunc ~mouse;
  glutMotionFunc ~motion;

  glutMainLoop();
;;

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
