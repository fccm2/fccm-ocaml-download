Tetratta is a little game similar to chinese checkers,
but with a 3D tetrahedral board.

Turn arround the board with the left click,
select pieces with the right click, and then the possible
destinations are marked with yellow targets, there just
click the target you wish to make move the selected piece.

There is no IA yet, so find a friend to play with you!
Or better develop the IA yourself, and send me the patch!

Please let me know what you have thought about this game:
  <fmonnier@linux-nantes.org>
