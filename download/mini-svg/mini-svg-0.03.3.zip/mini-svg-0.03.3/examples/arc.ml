module SvgRel = Svg.Relative

let () =
  let width, height = (160, 80) in
  let svg = Svg.new_svg_document ~width ~height () in

  begin
    let path = Svg.empty_path in
    let path = Svg.move_to path ~x:28.0 ~y:22.0 in
    let path = SvgRel.arc_to path ~x:46.0 ~y:38.0 ~rx:12 ~ry:10 () in

    Svg.add_path svg ~path
      ~stroke:"#246" ~fill:"#8b4"
      ~stroke_opacity:1.0
      ~stroke_width:3.6
      ~fill_opacity:0.6
      ();
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

