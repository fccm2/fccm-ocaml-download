
let () =
  Random.self_init ();
  let width, height = (660, 460) in

  let svg = Svg.new_svg_document ~width ~height () in
  Svg.add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#59B" ();

  for i = 1 to 10 do

    let r = float (30 + Random.int 70) in
    let cx = float (Random.int width) in
    let cy = float (Random.int height) in

    Svg.add_circle svg ~cx ~cy ~r
      ~fill:"#A62" ~stroke:"#247"
      ~fill_opacity:0.6
      ~stroke_width:7.0
      ~stroke_opacity:1.0
      ();
  done;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

