
let () =
  let w, h = (140, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#de1010" in
  let white = "#fbfbfb" in

  let fill_opacity = 1.0 in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red ();

  Svg.add_triangle svg  (* head *)
    ~p1:((w/2),   12)
    ~p2:((w/2)-8, 32)
    ~p3:((w/2)+8, 32)
    ~fill_opacity
    ~fill:white ();

  Svg.add_triangle svg
    ~p1:((w/2)-8,  32)
    ~p2:((w/2)-24, 72)
    ~p3:((w/2)+34, 32)
    ~fill_opacity
    ~fill:white ();

  Svg.add_triangle svg
    ~p1:((w/2)+8,  32)
    ~p2:((w/2)+24, 72)
    ~p3:((w/2)-34, 32)
    ~fill_opacity
    ~fill:white ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

