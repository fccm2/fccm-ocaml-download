module SvgRel = Svg.Relative

let () =
  let width, height = (270, 170) in
  let svg = Svg.new_svg_document ~width ~height () in

  begin
    let path = Svg.empty_path in
    let path = Svg.move_to path ~x:80.0 ~y:110.0 in

    let r = (22.0, 22.0) in
    let dx, dy = (0.0, -40.0) in
    let large_arc, clockwise = (true, true) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in

    let dx, dy = (0.0, 40.0) in
    let large_arc, clockwise = (false, false) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in
    let path = Svg.close_path path in

    Svg.add_path svg ~path
      ~stroke:"#f00"
      ~stroke_width:3.6
      ~fill_opacity:0.0
      ();
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

