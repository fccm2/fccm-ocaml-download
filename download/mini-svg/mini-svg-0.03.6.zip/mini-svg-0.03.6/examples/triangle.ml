
let () =
  let svg = Svg.new_svg_document ~width:220 ~height:180 () in

  Svg.add_triangle svg
    ~p1:(28, 38)
    ~p2:(128, 38)
    ~p3:(28, 138)
    ~fill:"#FFF000"
    ~stroke:"none"
    ();

  Svg.add_triangle svg
    ~p1:(48, 88)
    ~p2:(202, 116)
    ~p3:(78, 168)
    ~fill:"none"
    ~stroke:"#0E0"
    ~stroke_width:6.0
    ~stroke_opacity:0.8
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

