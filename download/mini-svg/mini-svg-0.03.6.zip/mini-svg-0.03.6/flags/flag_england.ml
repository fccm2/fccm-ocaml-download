(* united-kingdom *)
(* .co.uk *)
let () =
  let w, h = (160, 100) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(90) () in
  Svg.begin_group svg ~scale:(1.0, 0.9) ();

  let blue  = "#0812aa" in
  let red   = "#da0406" in
  let white = "#ffffff" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:blue
    ~stroke:blue
    ~stroke_width:1.0
    ();

  Svg.add_polyline svg ~points:[
      (0, 8);
      (0, 0);
      (12, 0);

      (w - 0, h - 8);
      (w - 0, h - 0);
      (w - 12, h - 0);
    ]
    ~fill:white
    ();

  Svg.add_polyline svg ~points:[
      (w - 0, 8);
      (w - 0, 0);
      (w - 12, 0);

      (0, h - 8);
      (0, h - 0);
      (12, h - 0);
    ]
    ~fill:white
    ();

  Svg.add_polyline svg ~points:[
      (w - 0, 0);

      (w - 72, 44);
      (w - 62, 44);

      (w - 0, 6);
      (w - 0, 0);
    ]
    ~fill:red
    ();

  Svg.add_polyline svg ~points:[
      (0, h - 0);

      (72, h - 44);
      (62, h - 44);

      (0, h - 6);
      (0, h - 0);
    ]
    ~fill:red
    ();

  Svg.add_polyline svg ~points:[
      (8, 0);
      (0, 0);

      (68, 44);
      (78, 44);

      (8, 0);
    ]
    ~fill:red
    ();

  Svg.add_polyline svg ~points:[
      (w - 8, h - 0);
      (w - 0, h - 0);

      (w - 68, h - 44);
      (w - 78, h - 44);

      (w - 8, h - 0);
    ]
    ~fill:red
    ();


  Svg.add_rect svg
    ~x:(66) ~y:(0)
    ~width:(28) ~height:(h)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(0) ~y:(37)
    ~width:(w) ~height:(26)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(72) ~y:(0)
    ~width:(16) ~height:(h)
    ~fill:red
    ();

  Svg.add_rect svg
    ~x:(0) ~y:(42)
    ~width:(w) ~height:(16)
    ~fill:red
    ();

  Svg.end_group svg;
  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

