(* ukraine *)

let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:"#006aa7"
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(h/2)
    ~width:(w)
    ~height:(h/2)
    ~fill:"#fecc00"
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

