(* .gh *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#f82020" in
  let yellow = "#fafa20" in
  let green  = "#20d820" in

  let black  = "#101010" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(26)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 26)
    ~width:(w)
    ~height:(26)
    ~fill:green ();

  (* star *)

  let stroke_width = 0.2 in

  Svg.begin_group svg ~scale:(0.5, 0.5) ();
   Svg.begin_group svg ~translate:(79.0, 50.0) ();

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:black
      ~stroke:black
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:black
      ~stroke:black
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:black
      ~stroke:black
      ~stroke_width ();

   Svg.end_group svg;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

