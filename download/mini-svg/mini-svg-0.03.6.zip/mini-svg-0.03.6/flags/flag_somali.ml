
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let stroke_width = 5.8 in

  let blue = "#4a4ac6" in
  let white = "#fcfcfc" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:blue ();

  Svg.begin_group svg ~scale:(0.6, 0.6) ();
   Svg.begin_group svg ~translate:(53.0, 36.0) ();

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();

   Svg.end_group svg;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

