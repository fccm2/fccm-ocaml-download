(* .sr *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#de1010" in
  let white  = "#fefefe" in
  let green  = "#00a800" in
  let yellow = "#fafa20" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(14)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0) ~y:((h/2)-18)
    ~width:(w)
    ~height:(36)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h-14)
    ~width:(w)
    ~height:(14)
    ~fill:green ();

  (* star *)

  let stroke_width = 1.2 in

  Svg.begin_group svg ~scale:(0.5, 0.5) ();
   Svg.begin_group svg ~translate:(79.0, 50.0) ();

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:yellow
      ~stroke:yellow
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:yellow
      ~stroke:yellow
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:yellow
      ~stroke:yellow
      ~stroke_width ();

   Svg.end_group svg;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

