module SvgRel = Svg.Relative

let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#de1010" in
  let green = "#00c800" in
  let white = "#fcfcfc" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w/2)
    ~height:(h)
    ~fill:green
    ();

  (* star *)
  begin
   Svg.begin_group svg ~scale:(0.42, 0.42) ();
    Svg.begin_group svg ~translate:(136.0, 64.0) ();

    let stroke_width = 5.6 in

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:red
      ~stroke:red
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:red
      ~stroke:red
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:red
      ~stroke:red
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;
  end;

  (* moon *)
  begin
    let moon_h = 40.4 in
    let h2 = (float h -. moon_h) /. 2.0 in
    let stroke_width = 3.6 in

    let path = Svg.empty_path in
    let path = Svg.move_to path ~x:72.0 ~y:(moon_h +. h2) in

    let r = (20.6, 20.6) in
    let dx, dy = (0.0, -. moon_h) in
    let large_arc, clockwise = (true, true) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in

    let r = (21.2, 21.2) in
    let dx, dy = (0.0, moon_h) in
    let large_arc, clockwise = (false, false) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in
    let path = Svg.close_path path in

    Svg.add_path svg ~path
      ~fill:red
      ~stroke:red
      ~stroke_width
      ~fill_opacity:1.0 ();
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

