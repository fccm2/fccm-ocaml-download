module SvgRel = Svg.Relative

let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green  = "#00c400" in
  let white  = "#ffffff" in
  let white1 = "#fbfbfb" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w/5)
    ~height:(h)
    ~fill:white1 ();

  Svg.begin_group svg ~translate:(18.0, 0.0) ();

  (* circle *)
  if false then
  begin
    let cx = float (w / 2) in
    let cy = float (h / 2) in
 
    Svg.add_ellipse svg
      ~cx ~cy ~r:(34.4, 33.8)
      ~fill_opacity:0.0
      ~fill:green
      ~stroke:white
      ~stroke_width:3.2
      ~stroke_opacity:1.0 ();
  end;

  (* star *)
  begin
   Svg.begin_group svg ~scale:(0.42, 0.42) ();
    Svg.begin_group svg ~translate:(138.0, 64.0) ();

    let stroke_width = 7.6 in

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;
  end;

  (* moon *)
  begin
    let moon_h = 40.4 in
    let h2 = (float h -. moon_h) /. 2.0 in
    let stroke_width = 4.8 in

    let path = Svg.empty_path in
    let path = Svg.move_to path ~x:74.0 ~y:(moon_h +. h2) in

    let r = (20.6, 20.6) in
    let dx, dy = (0.0, -. moon_h) in
    let large_arc, clockwise = (true, true) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in

    let r = (21.2, 21.2) in
    let dx, dy = (0.0, moon_h) in
    let large_arc, clockwise = (false, false) in
    let path = SvgRel.arc_to path ~x:dx ~y:dy ~r ~large_arc ~clockwise () in
    let path = Svg.close_path path in

    Svg.add_path svg ~path
      ~fill:white
      ~stroke:white
      ~stroke_width
      ~fill_opacity:1.0 ();
  end;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

