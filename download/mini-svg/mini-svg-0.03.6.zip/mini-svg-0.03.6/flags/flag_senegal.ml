
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green  = "#20d820" in
  let red    = "#f82020" in
  let yellow = "#fafa20" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(52)
    ~height:(h)
    ~fill:green
    ();

  Svg.add_rect svg
    ~x:(w-48) ~y:(0)
    ~width:(48)
    ~height:(h)
    ~fill:red
    ();

  (* green-star *)

  let stroke_width = 0.2 in

  let d1 = 0.6 in
  let d2 = 0.4 in

  Svg.begin_group svg ~scale:(1.0 *. d1, 1.0 *. d1) ();
   Svg.begin_group svg ~translate:(58.0, 90.0 *. d2) ();

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill:green
      ~stroke:green
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill:green
      ~stroke:green
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill:green
      ~stroke:green
      ~stroke_width ();

   Svg.end_group svg;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

