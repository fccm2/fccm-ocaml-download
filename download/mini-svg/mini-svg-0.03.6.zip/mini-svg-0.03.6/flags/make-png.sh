EXT="svg"
EXT="png"

make flag_france.$EXT
make flag_england.$EXT
make flag_spain.$EXT
make flag_italy.$EXT
make flag_germany.$EXT
make flag_switzerland.$EXT
make flag_austria.$EXT
make flag_belgium.$EXT
make flag_netherlands.$EXT
make flag_sweden.$EXT
make flag_norway.$EXT
make flag_denmark.$EXT
make flag_finland.$EXT
make flag_slovenia.$EXT
make flag_ukraine.$EXT
make flag_czechia.$EXT
make flag_poland.$EXT

make flag_morocco.$EXT
make flag_tunisia.$EXT
make flag_algeria.$EXT
make flag_turkey.$EXT
make flag_pakistan.$EXT
make flag_lebanon.$EXT

make flag_indonesia.$EXT
make flag_vietnam.$EXT
make flag_thailand.$EXT
make flag_bangladesh.$EXT
make flag_china.$EXT
make flag_japan.$EXT

make flag_mali.$EXT
make flag_guinea.$EXT
make flag_nigeria.$EXT
make flag_senegal.$EXT
make flag_sierra_leone.$EXT
make flag_somali.$EXT
make flag_ghana.$EXT
make flag_benin.$EXT
make flag_gabon.$EXT

make flag_costa_rica.$EXT
make flag_surinam.$EXT

