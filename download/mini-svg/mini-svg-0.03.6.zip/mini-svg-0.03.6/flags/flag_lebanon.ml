module SvgRel = Svg.Relative

let () =
  (*  *)
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#d20605" in
  let white = "#fcfcfc" in

  let brown = "#a02010" in
  let green = "#00a800" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(22)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 22)
    ~width:(w)
    ~height:((h/3)-1)
    ~fill:red ();

  (* tree *)
  begin
   Svg.begin_group svg ~scale:(0.5, 0.5) ();
    Svg.begin_group svg ~translate:(50.0, 61.0) ();

    let stroke_width = 4.2 in
 
    Svg.add_polyline svg
      ~points:[
        (100, 40);
        (120, 40);
        (140, 60);
        ( 80, 60); ]
      ~fill:brown
      ~stroke:brown
      ~stroke_width ();

    Svg.add_polyline svg
      ~points:[
        ( 80, 20);
        (100, 20);
        (100, 30);
        ( 60, 30); ]
      ~fill:green
      ~stroke:green
      ~stroke_width ();

    Svg.add_polyline svg
      ~points:[
        (120, 20);
        (140, 20);
        (160, 30);
        (120, 30); ]
      ~fill:green
      ~stroke:green
      ~stroke_width ();

    Svg.add_polyline svg
      ~points:[
        (108, 2);
        (112, 2);
        (130, 10);
        ( 90, 10); ]
      ~fill:green
      ~stroke:green
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

