
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#d20605" in
  let white = "#fcfcfc" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red
    ();

  Svg.add_rect svg
    ~x:((w/2)-10)
    ~y:((h/2)-32)
    ~width:(20)
    ~height:(64)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:((w/2)-32)
    ~y:((h/2)-10)
    ~width:(64)
    ~height:(20)
    ~fill:white
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

