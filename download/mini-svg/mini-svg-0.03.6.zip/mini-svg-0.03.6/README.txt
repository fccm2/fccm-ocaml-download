Mini-SVG

A small OCaml module for creating SVG files.

This module and the associated elements are provided under the conditions
explained in the file: LICENSE.txt

See the directory ./examples/ for examples.
See the directory ./doc/ for the documentation of this module.

