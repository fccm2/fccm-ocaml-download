(* To the extend permited by law, you can use, modify and redistribute
   this file. *)

(** {2 A mini-SVG module} *)

type svg
type css

val new_svg_document : width:int -> height:int -> ?unit:string -> unit -> svg
(** accepted values for the [unit] parameter can be:
    "px", "cm", "mm", "em", "ex", "in", "pt", "pc"
*)

val finish_svg : svg -> unit
(** closes the root [svg] tag *)

val add_comment : svg -> s:string -> unit -> unit

val add_newline : svg -> unit
(** adds a newline in the source of the [svg] document *)

val get_svg_document : svg -> string
(** return the result svg document as a string *)

val write_svg_file : svg -> filename:string -> unit
(** write the result svg document to a file *)

val print_svg_document : svg -> unit
(** prints the result svg document to stdout *)


(** {3 Shapes} *)

val add_line : svg -> x1:int -> y1:int -> x2:int -> y2:int ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_polyline : svg -> points:(int * int) list ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_rect : svg -> x:int -> y:int -> width:int -> height:int ->
  ?rx:float ->
  ?ry:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_circle : svg -> cx:float -> cy:float -> r:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_ellipse : svg -> cx:float -> cy:float -> r:float * float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_triangle : svg -> p1:int * int -> p2:int * int -> p3:int * int ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


val add_text : svg -> x:int -> y:int -> text:string ->
  ?text_anchor:string ->
  ?font_family:string ->
  ?font_size:float ->
  ?font_weight:string ->
  ?font_style:string ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit



(** {3 Transformations} *)

val begin_group : svg ->
  ?translate:float * float ->
  ?rotate:float * int * int ->
  ?scale:float * float -> unit -> unit

val end_group : svg -> unit



(** {3 Paths} *)

type path
val empty_path : path

val move_to : path -> x:float -> y:float -> path
val line_to : path -> x:float -> y:float -> path

val h_line : path -> x:float -> path
val v_line : path -> y:float -> path

val quad_curve : path ->
  x1:float -> y1:float -> x:float -> y:float -> path

val cubic_curve : path ->
  x1:float -> y1:float ->
  x2:float -> y2:float -> x:float -> y:float -> path

val arc_to : path ->
  x:float -> y:float -> r:float * float ->
  ?rotation:float -> ?large_arc:bool -> ?clockwise:bool -> unit -> path



val close_path : path -> path

val add_path : svg -> path:path ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?id:string -> ?css:css -> ?style:string -> unit -> unit


module Relative : sig
(** {3 Relative commands} *)

(** Same commands than from the Paths cathegory,
    but with coordinates relative to the previous
    coordinates. *)

val move_to : path -> x:float -> y:float -> path
val line_to : path -> x:float -> y:float -> path

val h_line : path -> x:float -> path
val v_line : path -> y:float -> path

val quad_curve : path ->
  x1:float -> y1:float -> x:float -> y:float -> path

val cubic_curve : path ->
  x1:float -> y1:float ->
  x2:float -> y2:float -> x:float -> y:float -> path

val arc_to : path ->
  x:float -> y:float -> r:float * float ->
  ?rotation:float -> ?large_arc:bool -> ?clockwise:bool -> unit -> path

val close_path : path -> path

end



(** {3 CSS / Styles} *)

type css_attr

val fill : css_attr
val fill_opacity : css_attr
val stroke : css_attr
val stroke_width : css_attr
val stroke_opacity : css_attr
val text_anchor : css_attr
val font_family : css_attr
val font_size : css_attr
val font_weight : css_attr
val font_style : css_attr
val letter_spacing : css_attr
val word_spacing : css_attr

val to_style : styles:(css_attr * string) list -> css
(** format parameters for the [style] parameter of the shapes functions *)

