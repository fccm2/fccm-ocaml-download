open Svg

let () = Random.self_init () ;;

let width, height = (220, 200)

let new_point () =
  let x = Random.int width in
  let y = Random.int height in
  (x, y)

let () =
  let svg = new_svg_document ~width ~height () in
  add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#347" ();

  for i = 0 to 2 do
    let p1 = new_point () in
    let p2 = new_point () in
    let p3 = new_point () in

    add_triangle svg
      ~p1 ~p2 ~p3
      ~fill:"#32A040" ~stroke:"none" ();
  done;

  add_newline svg;
  finish_svg svg;
  print_string (get_svg_document svg);
;;

