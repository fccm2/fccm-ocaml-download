let () =
  let svg = Svg.new_svg_document ~width:240 ~height:180 ~unit:"px" () in

  let filter =
    Svg.add_blur_filter svg ~stdDeviation:5.0 ()
  in
  Svg.add_rect svg ~x:30 ~y:40 ~width:120 ~height:80 ~fill:"#082" ~filter ();

  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;
