let () =
  let svg = Svg.new_svg_document ~width:220 ~height:180 ~unit:"px" () in

  let style =
    Svg.add_linear_gradient svg
      ~p1:(0, 0)
      ~p2:(220, 180)
      ~stops:[
        (0.0, "#F00", 1.0);
        (1.0, "#00F", 1.0);
      ] ()
  in
  Svg.add_rect svg ~x:0 ~y:0 ~width:220 ~height:180 ~style ();

  Svg.finish_svg svg;
  print_string (Svg.get_svg_document svg);
;;
