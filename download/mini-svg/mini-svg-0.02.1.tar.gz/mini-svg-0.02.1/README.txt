Mini-SVG

A mini OCaml module for creating SVG files.

This library is provided under a mini Zlib license,
see the file LICENSE.txt for details.

See the directory ./doc/ for generated api-documentation.

See the directory ./examples/ for examples.

You can install with Opam with:
opam install .

