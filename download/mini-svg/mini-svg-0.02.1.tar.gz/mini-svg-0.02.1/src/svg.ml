(** Mini-SVG module *)
(* Copyright (c) 2022 Florent Monnier
 
   This software is provided 'as-is', without any express or implied
   warranty. In no event will the authors be held liable for any damages
   arising from the use of this software.
 
   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute it
   freely.
*)

type svg = Buffer.t
type css = (string * (string * string) list) list ref

let new_svg_document ~width ~height ?(unit = "") () =
  let b = Buffer.create 1024 in
  Printf.kprintf (Buffer.add_string b)
    {|<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
  version="1.1"
  baseProfile="full"
  xmlns="http://www.w3.org/2000/svg"
  xmlns:xlink="http://www.w3.org/1999/xlink"
  width="%d%s"
  height="%d%s"
  viewBox="0 0 %d %d">
|} width unit height unit width height;
  (b)

let finish_svg b =
  Buffer.add_string b "\n</svg>\n";
;;


let new_css () = ref []

let fill           = "fill"
let fill_opacity   = "fill-opacity"
let stroke         = "stroke"
let stroke_width   = "stroke-width"
let stroke_opacity = "stroke-opacity"
let text_anchor    = "text-anchor"
let font_family    = "font-family"
let font_size      = "font-size"
let font_weight    = "font-weight"
let font_style     = "font-style"
let letter_spacing = "letter-spacing"
let word_spacing   = "word-spacing"

let css_add css ~selector ~styles =
  css := (selector, styles) :: !css

let add_css_to_svg css b =
  Printf.kprintf (Buffer.add_string b) {|
<style type="text/css">
<![CDATA[
|};

  List.iter (fun (selector, styles) ->
    Printf.kprintf (Buffer.add_string b) "\n%s {\n" selector;
    List.iter (fun (attr, value) ->
      Printf.kprintf (Buffer.add_string b) "  %s: %s;\n" attr value;
    ) styles;
    Printf.kprintf (Buffer.add_string b) "}\n";
  ) (List.rev !css);

  Printf.kprintf (Buffer.add_string b) {|
]]>
</style>
|};
  css := [];
;;

let to_style ~styles =
  String.concat "; " (
    List.map (fun (attr, value) ->
      Printf.sprintf "%s: %s" attr value;
    ) styles
  )


let _id = ref 0
let get_id s = incr _id; s ^ (string_of_int !_id)

type filter = string

let add_blur_filter b ~stdDeviation () =
  let id = get_id "blur_" in
  Printf.kprintf (Buffer.add_string b) {|
<filter id="%s"
    x="-0.8"
    y="-0.8"
    width="2.6"
    height="2.6">
  <feGaussianBlur stdDeviation="%g" />
</filter>
|} id stdDeviation;
(*
    x, y define the coordinates of the upper left corner for the rendering area of the filter.
    (default value: -10%)

    width, height define the length for the rendering area of the filter.
    (default value: 120%)
*)
  (Printf.sprintf "url(#%s)" id)
;;


let add_linear_gradient b ~p1:(x1, y1) ~p2:(x2, y2) ~stops () =
  let id = get_id "linear_gradient_" in
  Printf.kprintf (Buffer.add_string b) {|
  <linearGradient
     id="%s"
     x1="%d" y1="%d"
     x2="%d" y2="%d"
     gradientUnits="userSpaceOnUse">|} id x1 y1 x2 y2;
  List.iter (fun (offset, color, opacity) ->
    Printf.kprintf (Buffer.add_string b) {|
      <stop offset="%g" style="stop-color:%s; stop-opacity:%g" />|} offset color opacity
  ) stops;
  Printf.kprintf (Buffer.add_string b) "
  </linearGradient>\n";
  let style = Printf.sprintf "fill:url(#%s)" id in
  (style)
;;


let add_text b ~x ~y ~text ?css ?style
      ?text_anchor ?font_family ?font_size ?font_weight ?font_style
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?filter () =
  let css          = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let style        = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let text_anchor  = match text_anchor  with None -> "" | Some v -> Printf.sprintf " text-anchor=\"%s\"" v in
  let font_family  = match font_family  with None -> "" | Some v -> Printf.sprintf " font-family=\"%s\"" v in
  let font_size    = match font_size    with None -> "" | Some v -> Printf.sprintf " font-size=\"%g\"" v in
  let font_weight  = match font_weight  with None -> "" | Some v -> Printf.sprintf " font-weight=\"%s\"" v in
  let font_style   = match font_style   with None -> "" | Some v -> Printf.sprintf " font-style=\"%s\"" v in
  let filter       = match filter       with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<text x="%d" y="%d"%s%s%s%s%s%s%s%s%s%s%s%s%s>%s</text>|}
  x y css style text_anchor font_family font_size font_weight font_style fill fill_opacity
  stroke stroke_width stroke_opacity filter text;
;;


let add_line b ~x1 ~y1 ~x2 ~y2 ?css ?style ?stroke ?stroke_width ?stroke_opacity ?filter () =

  let css          = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let style        = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let filter       = match filter       with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<line x1="%d" y1="%d" x2="%d" y2="%d"%s%s%s%s%s%s />|}
  x1 y1 x2 y2 css style
  stroke stroke_width stroke_opacity filter;
;;


let add_polyline b ~points ?css ?style ?stroke ?stroke_width ?stroke_opacity ?fill ?fill_opacity ?filter () =

  let css          = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let style        = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let filter       = match filter       with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in

  let points = List.map (fun (x, y) -> Printf.sprintf "%d,%d" x y) points in
  let points = String.concat " " points in

  Printf.kprintf (Buffer.add_string b) {|
<polyline points="%s"%s%s%s%s%s%s%s%s />|}
  points css style stroke stroke_width stroke_opacity fill fill_opacity filter;
;;


let add_rect b ~x ~y ~width ~height ?rx ?ry ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?style ?css ?filter () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let css          = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let rx           = match rx           with None -> "" | Some v -> Printf.sprintf " rx=\"%g\"" v in
  let ry           = match ry           with None -> "" | Some v -> Printf.sprintf " ry=\"%g\"" v in
  let style        = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let filter       = match filter       with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<rect x="%d" y="%d" width="%d" height="%d"%s%s%s%s%s%s%s%s%s%s />|}
  x y width height rx ry css fill fill_opacity stroke stroke_width stroke_opacity style filter;
;;


let add_circle b ~cx ~cy ~r ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?style ?css ?id ?filter () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style  = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css    = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id     = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
  let filter = match filter with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in
  Printf.kprintf (Buffer.add_string b) {|
<circle cx="%g" cy="%g" r="%g"%s%s%s%s%s%s%s%s%s />|}
  cx cy r id css fill fill_opacity stroke stroke_width stroke_opacity style filter
;;


let add_ellipse b ~cx ~cy ~rx ~ry ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?style ?css ?id ?filter () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
  let filter = match filter with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in
  Printf.kprintf (Buffer.add_string b) {|
<ellipse cx="%g" cy="%g" rx="%g" ry="%g"%s%s%s%s%s%s%s%s%s />|}
  cx cy rx ry id css fill fill_opacity stroke stroke_width stroke_opacity filter style
;;


let add_triangle b ~p1:(x1, y1) ~p2:(x2, y2) ~p3:(x3, y3)
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?style ?css ?id ?filter () =

  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let filter       = match filter with None -> "" | Some v -> Printf.sprintf " filter=\"%s\"" v in

  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<path%s%s%s%s%s%s%s%s%s
   d="M%d,%d L%d,%d L%d,%d Z" />|}
  id css filter style
  fill fill_opacity stroke stroke_width stroke_opacity
  x1 y1 x2 y2 x3 y3
;;


let begin_group b ?translate ?scale ?rotate ?skew_x ?skew_y () =
  let translate = match translate with None -> ""
    | Some(tx, ty) -> Printf.sprintf "translate(%g %g)" tx ty
  in
  let scale = match scale with None -> ""
    | Some(sx, sy) -> Printf.sprintf "scale(%g %g)" sx sy
  in
  let rotate = match rotate with None -> ""
    | Some(r, cx, cy) -> Printf.sprintf "rotate(%g,%d,%d)" r cx cy
  in
  let skew_x = match skew_x with None -> ""
    | Some(d) -> Printf.sprintf "skewX(%g)" d
  in
  let skew_y = match skew_y with None -> ""
    | Some(d) -> Printf.sprintf "skewY(%g)" d
  in
  let transform =
    String.concat " " (
      List.filter (fun s -> s <> "") [translate; scale; rotate; skew_x; skew_y])
  in
  Printf.kprintf (Buffer.add_string b) {|
<g transform="%s">|} transform
;;

let end_group b =
  Buffer.add_string b "\n</g>\n";
;;


(* Paths *)

type path = string

let empty_path = ""

let move_to path ~x ~y =
  let sep = if path = "" then "" else " " in
  sep ^ path ^ (Printf.sprintf "M %g %g" x y)

let line_to path ~x ~y =
  if path = "" then invalid_arg "line_to" else
  path ^ (Printf.sprintf " L %g %g" x y)

let h_line path ~x =
  if path = "" then invalid_arg "h_line" else
  path ^ (Printf.sprintf " H %g" x)

let v_line path ~y =
  if path = "" then invalid_arg "v_line" else
  path ^ (Printf.sprintf " V %g" y)

let cubic_curve path ~x1 ~y1 ~x2 ~y2 ~x ~y =
  path ^ (Printf.sprintf
    " C %g %g, %g %g, %g %g" x1 y1 x2 y2 x y)

let quad_curve path ~x1 ~y1 ~x ~y =
  path ^ (Printf.sprintf
    " Q %g %g, %g %g" x1 y1 x y)

let close_path path =
  path ^ " Z"


let add_path b ~path
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?style ?css ?id () =
 
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
 
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
 
  Printf.kprintf (Buffer.add_string b) {|
<path%s%s%s%s%s%s%s%s
  d="%s" />|}
  id css style
  fill fill_opacity stroke stroke_width stroke_opacity
  path
;;


module Relative = struct
(* Relative commands *)

let move_to path ~x ~y =
  let sep = if path = "" then "" else " " in
  sep ^ path ^ (Printf.sprintf "m %g %g" x y)

let line_to path ~x ~y =
  if path = "" then invalid_arg "line_to" else
  path ^ (Printf.sprintf " l %g %g" x y)

let h_line path ~x =
  if path = "" then invalid_arg "h_line" else
  path ^ (Printf.sprintf " h %g" x)

let v_line path ~y =
  if path = "" then invalid_arg "v_line" else
  path ^ (Printf.sprintf " v %g" y)

let cubic_curve path ~x1 ~y1 ~x2 ~y2 ~x ~y =
  path ^ (Printf.sprintf
    " c %g %g, %g %g, %g %g" x1 y1 x2 y2 x y)

let quad_curve path ~x1 ~y1 ~x ~y =
  path ^ (Printf.sprintf
    " q %g %g, %g %g" x1 y1 x y)

let close_path path =
  path ^ " z"

end

let add_comment b ~s () =
  Printf.kprintf (Buffer.add_string b) {|
<!-- %s -->
|} s;
;;

let add_newline b =
  Buffer.add_char b '\n';
;;

let get_svg_document b =
  (Buffer.contents b)

let print_svg_document b =
  print_string (Buffer.contents b);
;;

let write_file filename s =
  let oc = open_out filename in
  output_string oc s;
  close_out oc;
;;

let write_svg_file b ~filename =
  let s = get_svg_document b in
  write_file filename s;
;;
