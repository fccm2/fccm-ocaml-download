(* Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to modify it and redistribute it freely. *)

(* Written by Florent Monnier, no copyright claimed, 2022 *)

(** {2 Mini-SVG module} *)

type svg
type css
type filter

val new_svg_document : width:int -> height:int -> ?unit:string -> unit -> svg
(** accepted values for the [unit] parameter can be:
    "px", "cm", "mm", "em", "ex", "in", "pt", "pc"
*)

val finish_svg : svg -> unit
(** closes the root [svg] tag *)

val add_comment : svg -> s:string -> unit -> unit

val add_newline : svg -> unit

val get_svg_document : svg -> string
(** return the result svg document as a string *)

val write_svg_file : svg -> filename:string -> unit
(** write the result svg document in a file *)

val print_svg_document : svg -> unit
(** prints the result svg document to stdout *)


(** {3 Shapes} *)

val add_line : svg -> x1:int -> y1:int -> x2:int -> y2:int ->
  ?css:string ->
  ?style:string ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?filter:filter -> unit -> unit


val add_polyline : svg -> points:(int * int) list ->
  ?css:string ->
  ?style:string ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?filter:filter -> unit -> unit


val add_rect : svg -> x:int -> y:int -> width:int -> height:int ->
  ?rx:float ->
  ?ry:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?style:string ->
  ?css:string ->
  ?filter:filter -> unit -> unit


val add_circle : svg -> cx:float -> cy:float -> r:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?style:string ->
  ?css:string ->
  ?id:string ->
  ?filter:filter -> unit -> unit


val add_ellipse : svg -> cx:float -> cy:float -> rx:float -> ry:float ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?style:string ->
  ?css:string ->
  ?id:string ->
  ?filter:filter -> unit -> unit


val add_triangle : svg -> p1:int * int -> p2:int * int -> p3:int * int ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?style:string ->
  ?css:string ->
  ?id:string ->
  ?filter:filter -> unit -> unit


val add_text : svg -> x:int -> y:int -> text:string ->
  ?css:string ->
  ?style:string ->
  ?text_anchor:string ->
  ?font_family:string ->
  ?font_size:float ->
  ?font_weight:string ->
  ?font_style:string ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?filter:filter -> unit -> unit


(** {3 Transformations} *)

val begin_group : svg ->
  ?translate:float * float ->
  ?scale:float * float ->
  ?rotate:float * int * int ->
  ?skew_x:float -> ?skew_y:float -> unit -> unit

val end_group : svg -> unit


(** {3 Paths} *)

type path
val empty_path : path

val move_to : path -> x:float -> y:float -> path
val line_to : path -> x:float -> y:float -> path

val h_line : path -> x:float -> path
val v_line : path -> y:float -> path

val cubic_curve : path ->
  x1:float -> y1:float ->
  x2:float -> y2:float -> x:float -> y:float -> path

val quad_curve : path ->
  x1:float -> y1:float -> x:float -> y:float -> path

val close_path : path -> path


val add_path : svg -> path:path ->
  ?fill:string ->
  ?fill_opacity:float ->
  ?stroke:string ->
  ?stroke_width:float ->
  ?stroke_opacity:float ->
  ?style:string ->
  ?css:string ->
  ?id:string -> unit -> unit


module Relative : sig
(** {3 Relative commands} *)

val move_to : path -> x:float -> y:float -> path
val line_to : path -> x:float -> y:float -> path

val h_line : path -> x:float -> path
val v_line : path -> y:float -> path

val cubic_curve : path ->
  x1:float -> y1:float ->
  x2:float -> y2:float -> x:float -> y:float -> path

val quad_curve : path ->
  x1:float -> y1:float -> x:float -> y:float -> path

val close_path : path -> path
end


(** {3 Filters and Gradients} *)

val add_blur_filter :
  svg -> stdDeviation:float -> unit -> filter


val add_linear_gradient : svg ->
  p1:(int * int) ->
  p2:(int * int) ->
  stops:(float * string * float) list -> unit -> string
(** provide the returned string to the [style] parameter of primitive functions *)


(** {3 CSS / Styles} *)

(** Warning: CSS in SVG not understood by Firefox version 78.11.0 *)

val new_css : unit -> css

val fill : string
val fill_opacity : string
val stroke : string
val stroke_width : string
val stroke_opacity : string
val text_anchor : string
val font_family : string
val font_size : string
val font_weight : string
val font_style : string
val letter_spacing : string
val word_spacing : string

val css_add : css -> selector:string -> styles:(string * string) list -> unit

val add_css_to_svg : css -> svg -> unit

val to_style : styles:(string * string) list -> string
(** format parameters for the [style] parameter of the shapes functions *)

