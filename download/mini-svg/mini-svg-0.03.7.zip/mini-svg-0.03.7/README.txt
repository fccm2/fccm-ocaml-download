# mini-svg

A small ocaml module for creating svg files.

This module and the associated elements are provided under the conditions
explained in the file: LICENSE.txt

In the directory ./src compile with the command:
  make

To create the api-documentation in html format, go in the
directory ./src and run the command:
  make doc

The directory ./src/doc with then contain the documentation of this module.

See the directory ./examples for examples.

