(* .cu *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#e81212" in
  let white = "#fbfbfb" in
  let blue  = "#0830cf" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(18)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(18 * 2)
    ~width:(w)
    ~height:(18)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(18 * 4)
    ~width:(w)
    ~height:(18)
    ~fill:blue ();

  Svg.add_triangle svg
    ~p1:(0, 0)
    ~p2:(74,45)
    ~p3:(0,90)
    ~fill:red ();

  (* star *)
  begin
   Svg.begin_group svg ~scale:(0.39, 0.39) ();
    Svg.begin_group svg ~translate:(6.8, 68.2) ();

    let stroke_width = 7.6 in

    Svg.add_triangle svg
      ~p1:((w/3),   10)
      ~p2:((w/3)-8, 30)
      ~p3:((w/3)+8, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/3)-8,  30)
      ~p2:((w/3)-24, 70)
      ~p3:((w/3)+34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/3)+8,  30)
      ~p2:((w/3)+24, 70)
      ~p3:((w/3)-34, 30)
      ~fill:white
      ~stroke:white
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

