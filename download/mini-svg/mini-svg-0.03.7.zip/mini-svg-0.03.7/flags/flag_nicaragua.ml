(* .ni *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let white = "#fefefe" in
  let blue  = "#0121ab" in  (* "#0830cf" *)

  let h2 = ((h/3)-2) in
  let w2 = ((w/2)) in
  let h3 = ((h/2)) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - h2)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();

  Svg.add_circle svg
    ~fill_opacity:0.0
    ~cx:(float w2)
    ~cy:(float h3)
    ~r:12.8
    ~stroke:blue
    ~stroke_width:2.6
    ~stroke_opacity:1.0 ();

  Svg.add_triangle svg
    ~p1:(w2 - 9, h3 +  6)
    ~p2:(w2,     h3 - 10)
    ~p3:(w2 + 9, h3 +  6)
    ~fill:blue ();

  Svg.add_circle svg
    ~cx:(float(w2 - 2))
    ~cy:(float(h3 - 2))
    ~r:3.2
    ~fill_opacity:1.0
    ~fill:white
    ~stroke:white
    ~stroke_width:1.2
    ~stroke_opacity:0.0 ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

