(* .ga *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00ca00" in
  let yellow = "#fafa20" in
  let blue = "#4a4ac6" in

  let sh = ((h/3)-2) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(sh)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - sh)
    ~width:(w)
    ~height:(sh)
    ~fill:blue ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

