(* .jp *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#de1010" in
  let white = "#fbfbfb" in

  let cx = float (w / 2) in
  let cy = float (h / 2) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_circle svg
    ~cx ~cy ~r:(28.0)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

