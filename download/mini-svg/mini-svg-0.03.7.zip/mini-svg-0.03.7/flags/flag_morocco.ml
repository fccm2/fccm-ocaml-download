module SvgRel = Svg.Relative
(* .ma *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#f82020" in
  let green  = "#20ff20" in
  let dark_blue = "#020836" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red ();

  (* stars *)
  let mk_star ~stroke_width ~color () =

   Svg.begin_group svg ~scale:(0.48, 0.48) ();
    Svg.begin_group svg ~translate:(86.0, 55.0) ();

    Svg.add_triangle svg
      ~p1:((w/2),   10)
      ~p2:((w/2)-8, 30)
      ~p3:((w/2)+8, 30)
      ~fill_opacity:0.0
      ~fill:color
      ~stroke:color
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  30)
      ~p2:((w/2)-24, 70)
      ~p3:((w/2)+34, 30)
      ~fill_opacity:0.0
      ~fill:color
      ~stroke:color
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  30)
      ~p2:((w/2)+24, 70)
      ~p3:((w/2)-34, 30)
      ~fill_opacity:0.0
      ~fill:color
      ~stroke:color
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;
  in
  mk_star ~stroke_width:12.0 ~color:dark_blue ();
  mk_star ~stroke_width:6.2 ~color:green ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

