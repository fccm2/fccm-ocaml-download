(* .ve *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#f82020" in
  let yellow = "#fafa20" in
  let blue   = "#0830cf" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(28)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 28)
    ~width:(w)
    ~height:(28)
    ~fill:red ();

  (* stars *)

  let stroke_width = 7.6 in

  let white = "#ffffff" in

  List.iter (fun (scale, translate) ->

   Svg.begin_group svg ~scale ();
    Svg.begin_group svg ~translate ();
 
     Svg.add_triangle svg
       ~p1:((w/6),   10)
       ~p2:((w/6)-8, 30)
       ~p3:((w/6)+8, 30)
       ~fill:white
       ~stroke:white
       ~stroke_width ();
  
     Svg.add_triangle svg
       ~p1:((w/6)-8,  30)
       ~p2:((w/6)-24, 70)
       ~p3:((w/6)+34, 30)
       ~fill:white
       ~stroke:white
       ~stroke_width ();
  
     Svg.add_triangle svg
       ~p1:((w/6)+8,  30)
       ~p2:((w/6)+24, 70)
       ~p3:((w/6)-34, 30)
       ~fill:white
       ~stroke:white
       ~stroke_width ();
 
    Svg.end_group svg;
   Svg.end_group svg;

  ) [
    ((0.17, 0.17), (280.0, 240.0));
    ((0.17, 0.17), (400.0, 218.0));
    ((0.17, 0.17), (520.0, 218.0));
    ((0.17, 0.17), (640.0, 240.0));
  ];

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

