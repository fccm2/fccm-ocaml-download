module SvgRel = Svg.Relative
module SvgF = Svg.Float
(* .sk *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#e81212" in
  let white = "#fbfbfb" in
  let blue  = "#0830cf" in

  let h2 = ((h/3)-1) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h2)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - h2)
    ~width:(w)
    ~height:(h2)
    ~fill:red ();

  let path = Svg.empty_path in
  let path = Svg.move_to path ~x:20.0 ~y:23.6 in
  let path = SvgRel.line_to path ~x:(-1.0) ~y:24.0 in

  let path = SvgRel.arc_to path ~x:18.4 ~y:20.6 ~r:(30.2, 30.2)
                      ~large_arc:false ~clockwise:false () in

  let path = SvgRel.arc_to path ~x:18.4 ~y:(-20.6) ~r:(30.2, 30.2)
                      ~large_arc:false ~clockwise:false () in

  let path = SvgRel.line_to path ~x:(-1.0) ~y:(-24.0) in

  let path = Svg.close_path path in

  Svg.add_path svg ~path
    ~fill:red
    ~stroke:white
    ~stroke_width:1.4 ();

  SvgF.add_line svg
    ~x1:37.4 ~y1:29.0
    ~x2:37.4 ~y2:52.0
    ~stroke:"#fff"
    ~stroke_width:4.4 ();

  SvgF.add_line svg
    ~x1:(37.4 -. 7.0) ~y1:35.0
    ~x2:(37.4 +. 7.0) ~y2:35.0
    ~stroke:"#fff"
    ~stroke_width:4.4 ();

  SvgF.add_line svg
    ~x1:(37.4 -. 9.0) ~y1:44.0
    ~x2:(37.4 +. 9.0) ~y2:44.0
    ~stroke:"#fff"
    ~stroke_width:4.4 ();

  Svg.add_circle svg ~cx:38.4 ~cy:57.6 ~r:6.8 ~fill:blue ();
  Svg.add_circle svg ~cx:30.3 ~cy:57.0 ~r:3.6 ~fill:blue ();
  Svg.add_circle svg ~cx:46.5 ~cy:57.0 ~r:3.6 ~fill:blue ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

