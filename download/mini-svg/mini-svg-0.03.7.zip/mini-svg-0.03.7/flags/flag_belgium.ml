(* .be *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let black  = "#000000" in
  let red    = "#ff0000" in
  let yellow = "#f8f800" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(50)
    ~height:(h)
    ~fill:black
    ();

  Svg.add_rect svg
    ~x:(110)
    ~y:(0)
    ~width:(50)
    ~height:(h)
    ~fill:red
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

