(* .pa *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#e81212" in
  let white = "#fbfbfb" in
  let blue  = "#0830cf" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(w / 2) ~y:(0)
    ~width:(w / 2)
    ~height:(h / 2)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h / 2)
    ~width:(w / 2)
    ~height:(h / 2)
    ~fill:blue ();

  (* star *)

  let stroke_width = 0.2 in

  let d1 = 0.56 in

  let draw_star ~x ~y ~color =

   Svg.begin_group svg ~scale:(1.0 *. d1, 1.0 *. d1) ();
    Svg.begin_group svg ~translate:(x, y) ();
   
     Svg.add_triangle svg
       ~p1:((w/2),   10)
       ~p2:((w/2)-8, 30)
       ~p3:((w/2)+8, 30)
       ~fill:color
       ~stroke:color
       ~stroke_width ();
  
     Svg.add_triangle svg
       ~p1:((w/2)-8,  30)
       ~p2:((w/2)-24, 70)
       ~p3:((w/2)+34, 30)
       ~fill:color
       ~stroke:color
       ~stroke_width ();
  
     Svg.add_triangle svg
       ~p1:((w/2)+8,  30)
       ~p2:((w/2)+24, 70)
       ~p3:((w/2)-34, 30)
       ~fill:color
       ~stroke:color
       ~stroke_width ();
   
    Svg.end_group svg;
   Svg.end_group svg;
  in
  draw_star ~x:(-10.0) ~y:( 0.1) ~color:(blue);
  draw_star ~x:(136.0) ~y:(80.0) ~color:(red);

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

