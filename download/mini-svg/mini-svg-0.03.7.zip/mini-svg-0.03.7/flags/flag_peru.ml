(* .pe *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let white = "#ffffff" in
  let red   = "#e81212" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(50)
    ~height:(h)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(110) ~y:(0)
    ~width:(50)
    ~height:(h)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

