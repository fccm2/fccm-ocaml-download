(* .bg *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00c800" in
  let white = "#fefefe" in
  let red   = "#f82020" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(30)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 30)
    ~width:(w)
    ~height:(30)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

