(* .bd *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00a800" in
  let red  = "#c61400" in

  let cx = float (w / 2) in
  let cy = float (h / 2) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:green ();

  Svg.add_circle svg
    ~cx ~cy ~r:(28.0)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

