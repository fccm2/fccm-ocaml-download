(* .fl *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let blue = "#4a4ac6" in
  let white = "#fcfcfc" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(52)
    ~y:(0)
    ~width:(20)
    ~height:(h)
    ~fill:blue
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(35)
    ~width:(w)
    ~height:(20)
    ~fill:blue
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

