module SvgRel = Svg.Relative
(* .br *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green  = "#00c800" in
  let yellow = "#fafa20" in
  let blue   = "#0812aa" in
  let white = "#fbfbfb" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:green ();

  Svg.add_polyline svg ~points:[
      (10, 45);
      (80, 10);
      (w - 10, 45);
      (80, h - 10);
    ] ~fill:yellow ();

  let cx = float (w / 2) in
  let cy = float (h / 2) in

  Svg.add_circle svg
    ~cx ~cy ~r:(26.0) ~fill:blue ();

  Svg.begin_group svg
    ~translate:(0.0, 0.0)
    ~rotate:(10.0, w/2, h/2)
    ~scale:(1.0, 1.0) ();

  (* arc *)
  begin
    let pa = Svg.empty_path in
    let pa = Svg.move_to pa ~x:43.0 ~y:45.0 in
    let pa =
      Svg.arc_to pa ~x:((float w) -. 43.0) ~y:45.0
        ~r:(76.0, 76.0) ~large_arc:false ~clockwise:true ()
    in
    Svg.add_path svg ~path:pa
      ~fill:white
      ~stroke:white
      ~stroke_width:4.8
      ~stroke_opacity:1.0
      ~fill_opacity:0.0 ();
  end;
  Svg.end_group svg;
  Svg.add_newline svg;

  let stroke_width = 3.2 in

  List.iter (fun (scale, translate) ->

    Svg.begin_group svg ~scale ();
     Svg.begin_group svg ~translate ();
 
      Svg.add_triangle svg
        ~p1:((w/2),   10)
        ~p2:((w/2)-8, 30)
        ~p3:((w/2)+8, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)-8,  30)
        ~p2:((w/2)-24, 70)
        ~p3:((w/2)+34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)+8,  30)
        ~p2:((w/2)+24, 70)
        ~p3:((w/2)-34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
 
     Svg.end_group svg;
    Svg.end_group svg;
  ) [
      ((0.16, 0.16), (316.0, 236.0));
      ((0.12, 0.12), (696.0, 380.0));
      ((0.08, 0.08), (824.0, 468.0));

      ((0.0768, 0.0768), (864.0, 672.0));
      ((0.0768, 0.0768), (924.0, 698.0));
      ((0.0768, 0.0768), (984.0, 684.0));
    ];

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

