(* .ng *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00c800" in
  let white = "#ffffff" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(51)
    ~height:(h)
    ~fill:green
    ();

  Svg.add_rect svg
    ~x:(110)
    ~y:(0)
    ~width:(50)
    ~height:(h)
    ~fill:green
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

