(* .ee *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let black = "#101010" in
  let white = "#fefefe" in
  let blue  = "#4a4ac6" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(30)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(30)
    ~width:(w)
    ~height:(30)
    ~fill:black ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

