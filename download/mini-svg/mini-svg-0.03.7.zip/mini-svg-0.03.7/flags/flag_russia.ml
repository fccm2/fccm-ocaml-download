(* .ru *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#e81212" in
  let white = "#fbfbfb" in
  let blue  = "#0830cf" in

  let h2 = ((h/3)-1) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h2)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - h2)
    ~width:(w)
    ~height:(h2)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

