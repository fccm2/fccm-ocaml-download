(* .cz *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let blue  = "#060098" in
  let red   = "#c60404" in
  let white = "#fdfdfd" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(h/2)
    ~width:(w)
    ~height:(h/2)
    ~fill:red
    ();

  Svg.add_polyline svg ~points:[
      (0, 0);
      (74, h/2);
      (0, h);
    ]
    ~fill:blue
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

