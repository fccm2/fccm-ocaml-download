(* .mg *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00c800" in
  let red   = "#e81212" in
  let white = "#fafafa" in

  Svg.add_rect svg
    ~x:(56) ~y:(0)
    ~width:(w - 56)
    ~height:(h/2)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(56) ~y:(h/2)
    ~width:(w - 56)
    ~height:(h/2)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(56)
    ~height:(h)
    ~fill:white ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

