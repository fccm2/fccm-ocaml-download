(* .il *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let stroke_width = 2.6 in

  let white = "#fcfcfc" in
  let blue = "#4a4ac6" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_line svg
    ~x1:(0) ~y1:(12)
    ~x2:(w) ~y2:(12)
    ~stroke:blue
    ~stroke_width:12.0 ();

  Svg.add_line svg
    ~x1:(0) ~y1:(h - 12)
    ~x2:(w) ~y2:(h - 12)
    ~stroke:blue
    ~stroke_width:12.0 ();

  Svg.begin_group svg ~translate:(float(w/2), 10.0) ();
   Svg.begin_group svg ~scale:(2.2, 1.6) ();

    Svg.add_triangle svg
      ~p1:( 0, 10)
      ~p2:(-8, 28)
      ~p3:(+8, 28)
      ~fill_opacity:0.0
      ~fill:white
      ~stroke:blue
      ~stroke_width ();

    Svg.add_triangle svg
      ~p1:(-8, 16)
      ~p2:(+8, 16)
      ~p3:( 0, 34)
      ~fill_opacity:0.0
      ~fill:white
      ~stroke:blue
      ~stroke_width ();

   Svg.end_group svg;
  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

