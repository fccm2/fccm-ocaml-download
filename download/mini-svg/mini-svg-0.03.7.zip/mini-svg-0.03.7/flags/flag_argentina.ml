module SvgRel = Svg.Relative
(* .ar *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let white = "#fefefe" in
  let blue  = "#0121ab" in

  let yellow = "#ed0" in
  let orange = "#dc0" in

  let h2 = ((h/3)-2) in
  let w2 = ((w/2)) in
  let h3 = ((h/2)) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - h2)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();

  Svg.add_circle svg
    ~cx:(float w2)
    ~cy:(float h3)
    ~r:9.8
    ~fill:yellow ();

  Svg.add_newline svg;

  let path = Svg.new_path () in
  let path = Svg.move_to path ~x:0.0 ~y:11.2 in
  let path = SvgRel.line_to path ~x:1.1 ~y:2.6 in
  let path = SvgRel.arc_to path ~x:(-2.2) ~y:0.0 ~r:(4.0, 4.0)
               ~large_arc:false ~clockwise:false () in
  let path = SvgRel.line_to path ~x:1.1 ~y:(-2.6) in
  let path = Svg.close_path path in

  let cx, cy = 
    (float w2,
     float h3)
  in

  Svg.begin_group svg ~translate:(cx, 21.0)  ();

  for i = 0 to pred 18 do
   let a = float (i * 20) in

   Svg.begin_group svg ~rotate:(a, 0, 24) ();
    Svg.add_path svg ~path ~fill:orange ();
   Svg.end_group svg;

  done;

  Svg.end_group svg;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

