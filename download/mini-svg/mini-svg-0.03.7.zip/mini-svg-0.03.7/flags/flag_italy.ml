(* .it *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00a800" in
  let red   = "#c61400" in

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:"#fff"
    ();

  Svg.add_rect svg
    ~x:(0)
    ~y:(0)
    ~width:(51)
    ~height:(h)
    ~fill:green
    ();

  Svg.add_rect svg
    ~x:(109)
    ~y:(0)
    ~width:(51)
    ~height:(h)
    ~fill:red
    ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

