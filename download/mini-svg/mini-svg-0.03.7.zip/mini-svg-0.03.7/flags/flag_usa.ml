(* .us *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#d20605" in
  let white = "#fefefe" in
  let blue  = "#0526ab" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red ();

  let fill = white in
  Svg.add_rect svg ~x:(0) ~y:(10) ~width:(w) ~height:(8) ~fill ();
  Svg.add_rect svg ~x:(0) ~y:(30) ~width:(w) ~height:(8) ~fill ();
  Svg.add_rect svg ~x:(0) ~y:(50) ~width:(w) ~height:(8) ~fill ();
  Svg.add_rect svg ~x:(0) ~y:(70) ~width:(w) ~height:(8) ~fill ();
  Svg.add_rect svg ~x:(0) ~y:(90) ~width:(w) ~height:(8) ~fill ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(72)
    ~height:(50)
    ~fill:blue ();

  let scale = (0.11, 0.11) in
  let stroke_width = 6.2 in

  let draw_star translate =

    Svg.begin_group svg ~scale ();
     Svg.begin_group svg ~translate ();
 
      Svg.add_triangle svg
        ~p1:((w/2),   10)
        ~p2:((w/2)-8, 30)
        ~p3:((w/2)+8, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)-8,  30)
        ~p2:((w/2)-24, 70)
        ~p3:((w/2)+34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)+8,  30)
        ~p2:((w/2)+24, 70)
        ~p3:((w/2)-34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
 
     Svg.end_group svg;
    Svg.end_group svg;
  in
  
  for i = 0 to pred 4 do
    for j = 0 to pred 4 do
      let x = 10.0 +. (float i *. 158.0) in
      let y = 28.0 +. (float j *. 104.0) in
      draw_star (x, y);
    done;
  done;

  for i = 0 to pred 3 do
    for j = 0 to pred 3 do
      let x = 10.0 +. (float i *. 158.0) +. (158.0 /. 2.0) in
      let y = 28.0 +. (float j *. 104.0) +. (104.0 /. 2.0) in
      draw_star (x, y);
    done;
  done;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

