(* .bn *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let yellow = "#fafa20" in
  let red    = "#f82020" in
  let green  = "#20d820" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(h/2)
    ~width:(w)
    ~height:(h/2)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(56)
    ~height:(h)
    ~fill:green ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

