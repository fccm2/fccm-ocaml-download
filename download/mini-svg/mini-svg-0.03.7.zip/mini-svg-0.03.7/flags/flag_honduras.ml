(* .hn *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let white = "#fefefe" in
  let blue  = "#0121ab" in

  let h2 = ((h/3)-2) in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - h2)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h2)
    ~fill:blue ();


  (* stars *)

  let stroke_width = 2.4 in

  List.iter (fun (scale, translate) ->

   Svg.begin_group svg ~scale ();
    Svg.begin_group svg ~translate ();

    Svg.add_triangle svg
      ~p1:((w/2),    0)
      ~p2:((w/2)-8, 20)
      ~p3:((w/2)+8, 20)
      ~fill:blue
      ~stroke:blue
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)-8,  20)
      ~p2:((w/2)-24, 60)
      ~p3:((w/2)+34, 20)
      ~fill:blue
      ~stroke:blue
      ~stroke_width ();
 
    Svg.add_triangle svg
      ~p1:((w/2)+8,  20)
      ~p2:((w/2)+24, 60)
      ~p3:((w/2)-34, 20)
      ~fill:blue
      ~stroke:blue
      ~stroke_width ();

    Svg.end_group svg;
   Svg.end_group svg;

  ) [
    ((0.23, 0.23), (150.0, 130.0));
    ((0.23, 0.23), (150.0, 202.0));

    ((0.23, 0.23), (284.0, 166.0));

    ((0.23, 0.23), (418.0, 130.0));
    ((0.23, 0.23), (418.0, 202.0));
  ];

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

