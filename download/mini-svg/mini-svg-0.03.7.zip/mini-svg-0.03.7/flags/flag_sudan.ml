(* .sd *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#f82020" in
  let white = "#fefefe" in
  let black = "#101010" in
  let green = "#00c800" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(28)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 28)
    ~width:(w)
    ~height:(28)
    ~fill:black ();

  (* triangle *)

  Svg.add_polyline svg ~points:[
      (0, 0);
      (68, h/2);
      (0, h);
    ] ~fill:green ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

