(* .co *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#f82020" in
  let yellow = "#fafa20" in
  let blue   = "#0830cf" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - (24 * 2))
    ~width:(w)
    ~height:(24)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 24)
    ~width:(w)
    ~height:(24)
    ~fill:red ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

