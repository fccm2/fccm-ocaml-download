(* .no *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red = "#f80804" in
  let white = "#ffffff" in
  let blue = "#303098" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(48) ~y:(0)
    ~width:(24)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(33)
    ~width:(w)
    ~height:(24)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(54) ~y:(0)
    ~width:(12)
    ~height:(h)
    ~fill:blue ();

  Svg.add_rect svg
    ~x:(0) ~y:(39)
    ~width:(w)
    ~height:(12)
    ~fill:blue ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

