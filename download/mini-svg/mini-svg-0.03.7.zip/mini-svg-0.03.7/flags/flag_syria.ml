(* .sy *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let green = "#00c800" in
  let white = "#fefefe" in
  let black = "#101010" in
  let red   = "#f82020" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(28)
    ~fill:green ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 28)
    ~width:(w)
    ~height:(28)
    ~fill:black ();

  (* stars *)

  let draw_start ~translate =
    Svg.begin_group svg ~scale:(0.4, 0.4) ();
     Svg.begin_group svg ~translate ();
 
      Svg.add_triangle svg
        ~p1:((w/2),   10)
        ~p2:((w/2)-8, 30)
        ~p3:((w/2)+8, 30)
        ~fill:red ();
  
      Svg.add_triangle svg
        ~p1:((w/2)-8,  30)
        ~p2:((w/2)-24, 70)
        ~p3:((w/2)+34, 30)
        ~fill:red ();
  
      Svg.add_triangle svg
        ~p1:((w/2)+8,  30)
        ~p2:((w/2)+24, 70)
        ~p3:((w/2)-34, 30)
        ~fill:red ();
 
     Svg.end_group svg;
    Svg.end_group svg;
  in
  draw_start ~translate:( 30.0, 74.0);
  draw_start ~translate:(120.0, 74.0);
  draw_start ~translate:(210.0, 74.0);

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

