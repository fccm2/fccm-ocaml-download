(* .bo *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red    = "#de1010" in
  let yellow = "#fafa20" in
  let green  = "#00a800" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:yellow ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(28)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(h - 28)
    ~width:(w)
    ~height:(28)
    ~fill:green ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

