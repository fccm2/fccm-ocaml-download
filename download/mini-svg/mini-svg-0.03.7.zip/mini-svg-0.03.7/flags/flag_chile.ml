(* .cl *)
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let red   = "#e81212" in
  let white = "#fbfbfb" in
  let blue  = "#0830cf" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:white ();

  Svg.add_rect svg
    ~x:(0) ~y:(h/2)
    ~width:(w)
    ~height:(h/2)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(56)
    ~height:(h/2)
    ~fill:blue ();

  let stroke_width = 7.2 in

  List.iter (fun (scale, translate) ->

    Svg.begin_group svg ~scale ();
     Svg.begin_group svg ~translate ();
 
      Svg.add_triangle svg
        ~p1:((w/3),   10)
        ~p2:((w/3)-8, 30)
        ~p3:((w/3)+8, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/3)-8,  30)
        ~p2:((w/3)-24, 70)
        ~p3:((w/3)+34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/3)+8,  30)
        ~p2:((w/3)+24, 70)
        ~p3:((w/3)-34, 30)
        ~fill:white
        ~stroke:white
        ~stroke_width ();
 
     Svg.end_group svg;
    Svg.end_group svg;
  ) [
      ((0.36, 0.36), (25.0, 22.0));
    ];

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

