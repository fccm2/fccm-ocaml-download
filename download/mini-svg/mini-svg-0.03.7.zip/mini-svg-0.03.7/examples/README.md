- `triangle.ml`: draws 2 triangles (one filled, and one with only stroke)
- `arc.ml`: draws 4 arcs (demonstrating how to use the `large_arc`, and `clockwise` flags)
- `arc2.ml`: draws a small moon using 2 arcs.
- `star.ml`: draws a little star with 3 triangles.

- `path.svg`: an example of use of the path interface.

- `chart.svg`: demonstrate how to use the `circle_sector` primitive, to draw a minimalist pie-chart.
- `slice.svg`: an example of use of the `donut_slice` primitive (usefull to create donut-charts)

- `circles.svg`: draws 10 circles, with a random center, and random radius.

- `bar_chart.svg`: a vertical, bar-chart
- `pie_chart.svg`: a pie-chart
- `donut_slice.svg`: a donut-chart
- `candlestick.svg`: a candlestick-chart

The `Makefile` creates the svg files, from the sources `.ml` files.
for example, the `triangle.svg` file is created with the command:
$ make triangle.svg

If you edit the file `triangle.ml`, then you can run this command
again to update the result file: `triangle.svg`

It will work only if the `svg.cma` has been created first with the command:
$ make
while being in the directory ../src

You can visualise the .svg files, for example, with `inkview`.
`inkview` is installed with `inkscape` (for example with the command:
  sudo apt-get install inkscape
on Debian), or with a modern web-browser.

