
let () =
  Random.self_init ();
  let width, height = (400, 310) in

  let svg = Svg.new_svg_document ~width ~height () in
  Svg.add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#fff" ();

  begin
    let r = (float 90) in
    let cx = (float width *. 0.5) in
    let cy = (float height *. 0.5) in
    let pi = Float.pi in

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 1.5)
      ~angle2:(pi *. 1.9)
      ~fill:"#64A" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 1.9)
      ~angle2:(pi *. 2.3)
      ~fill:"#A24" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 2.3)
      ~angle2:(pi *. 2.8)
      ~fill:"#2A4" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 2.8)
      ~angle2:(pi *. 2.9)
      ~fill:"#CA2" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 2.9)
      ~angle2:(pi *. 3.2)
      ~fill:"#D72" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_circle_sector svg ~cx ~cy ~r
      ~angle1:(pi *. 3.2)
      ~angle2:(pi *. 3.5)
      ~fill:"#249" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

