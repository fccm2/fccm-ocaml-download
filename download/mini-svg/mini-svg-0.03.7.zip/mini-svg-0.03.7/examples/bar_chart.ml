
let () =
  let width, height = (560, 340) in
  let svg = Svg.new_svg_document ~width ~height () in

  (* title *)
  Svg.add_text svg ~x:26 ~y:27 ~text:"Bar Chart"
    ~font_size:16.4
    ~fill:"#888"
    ~fill_opacity:0.9 ();

  (* y-axis *)
  Svg.add_line svg ~x1:50 ~y1:50 ~x2:50 ~y2:(height - 50)
    ~stroke:"#888"
    ~stroke_width:1.7
    ~stroke_opacity:0.9 ();

  (* y-axis ticks *)
  for i = 0 to pred 13 do
    let y = (height - 50) - (i * 19) in
    (* ticks marks *)
    Svg.add_line svg ~x1:47 ~y1:y ~x2:50 ~y2:y
      ~stroke:"#888"
      ~stroke_width:1.2
      ~stroke_opacity:0.9 ();

    (* ticks labels *)
    Svg.add_text svg ~x:42 ~y ~text:(Printf.sprintf "%d" (i * 6))
      ~text_anchor:"end"
      ~font_size:8.2
      ~fill:"#888"
      ~fill_opacity:0.9 ();
  done;

  (* x-axis *)
  Svg.add_line svg ~x1:50 ~y1:(height - 50) ~x2:(width - 50) ~y2:(height - 50)
    ~stroke:"#888"
    ~stroke_width:1.7
    ~stroke_opacity:0.9 ();

  (* x-axis ticks *)
  for j = 0 to pred 19 do
    let x = 54 + (j * 24) in
    (* ticks marks *)
    Svg.add_line svg ~x1:x ~y1:(height - 50) ~x2:x ~y2:(height - 47)
      ~stroke:"#888"
      ~stroke_width:1.7
      ~stroke_opacity:0.9 ();

    (* ticks labels *)
    Svg.add_text svg ~x ~y:(height - 34) ~text:(Printf.sprintf "%d" (j * 8))
      ~text_anchor:"middle"
      ~font_size:8.2
      ~fill:"#888"
      ~fill_opacity:0.9 ();
  done;

  Svg.add_newline svg;

  Random.self_init ();

  (* bars *)
  for j = 0 to pred 19 do
    let x = 54 + (j * 24) in
    let cl = [| "#34e"; "#e32"; "#1d2" |].(Random.int 3) in
    let h = 8 + Random.int 160 + Random.int 30 in
    let y = height - 50 - h in

    Svg.add_rect svg ~x ~y ~width:8 ~height:h ~fill:cl ();
  done;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

