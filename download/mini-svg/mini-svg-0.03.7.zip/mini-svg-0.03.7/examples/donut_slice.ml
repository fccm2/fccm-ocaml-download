
let () =
  let width, height = (400, 310) in

  let svg = Svg.new_svg_document ~width ~height () in
  Svg.add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#fff" ();

  begin
    let r1 = (float 54) in
    let r2 = (float 92) in
    let cx = (float width *. 0.5) in
    let cy = (float height *. 0.5) in
    let pi = Float.pi in

    let layer2 = Svg.new_fragment () in

    let slice ~fill ~angles:(a1, a2) ~text =
      let a3 = ((a1 +. a2) /. 2.0) in

      Svg.add_donut_slice svg ~cx ~cy ~r1 ~r2
        ~angle1:(pi *. a1)
        ~angle2:(pi *. a2)
        ~fill ~stroke:"#fff"
        ~fill_opacity:1.0
        ~stroke_width:1.6
        ~stroke_opacity:1.0 ();
     
      let x1, y1 =
        let angle = (pi *. a3) in
        let r = (float 98) in
        int_of_float (cx +. r *. cos angle),
        int_of_float (cy +. r *. sin angle)
      in
      Svg.add_text svg ~x:x1 ~y:y1 ~text
        ~text_anchor:(if a3 > 1.5 && a3 < 2.5 then "start" else "end")
        ~dominant_baseline:(if a3 > 2.0 && a3 < 3.0 then "hanging" else "auto")
        ~font_size:16.6
        ~font_weight:"bold"
        ~fill ~stroke:fill
        ~fill_opacity:1.0
        ~stroke_width:0.2
        ~stroke_opacity:1.0 ();

      let x1, y1 =
        let angle = (pi *. a3) in
        let r = (float 73) in
        int_of_float (cx +. r *. cos angle),
        int_of_float (cy +. r *. sin angle)
      in
      Svg.add_text layer2 ~x:x1 ~y:y1
        ~text:(Printf.sprintf "%.0f%%" ((a2 -. a1) /. 2.0 *. 100.0))
        ~text_anchor:"middle"
        ~dominant_baseline:"middle"
        ~font_size:11.3
        ~font_weight:"bold"
        ~fill:"#222" ~stroke:"#222"
        ~fill_opacity:1.0
        ~stroke_width:0.1
        ~stroke_opacity:1.0 ();
    in
    slice ~fill:"#64A" ~angles:(1.5, 1.9) ~text:"Violet";
    slice ~fill:"#A24" ~angles:(1.9, 2.3) ~text:"Red";
    slice ~fill:"#2A4" ~angles:(2.3, 2.8) ~text:"Green";
    slice ~fill:"#CA2" ~angles:(2.8, 2.9) ~text:"Yellow";
    slice ~fill:"#D72" ~angles:(2.9, 3.2) ~text:"Orange";
    slice ~fill:"#249" ~angles:(3.2, 3.5) ~text:"Blue";
    Svg.add_fragment svg layer2;
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

