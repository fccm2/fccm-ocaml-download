
let () =
  Random.self_init ();
  let width, height = (400, 310) in

  let svg = Svg.new_svg_document ~width ~height () in
  Svg.add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#fff" ();

  begin
    let r1 = (float 62) in
    let r2 = (float 96) in
    let cx = (float width *. 0.5) in
    let cy = (float height *. 0.5) in
    let pi = Float.pi in

    Svg.add_donut_slice svg ~cx ~cy ~r1 ~r2
      ~angle1:(pi *. 1.2)
      ~angle2:(pi *. 2.4)
      ~fill:"#C41" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();

    Svg.add_donut_slice svg ~cx ~cy ~r1 ~r2
      ~angle1:(pi *. 1.4)
      ~angle2:(pi *. 1.9)
      ~fill:"#64A" ~stroke:"#111"
      ~fill_opacity:1.0
      ~stroke_width:2.0
      ~stroke_opacity:1.0 ();
  end;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

