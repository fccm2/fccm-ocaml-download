open Svg

let () =
  let width, height = (480, 320) in

  let svg = Svg.new_svg_document ~width ~height () in
  Svg.add_rect svg ~x:0 ~y:0 ~width ~height ~fill:"#ABC" ();

  let path = Svg.empty_path in
  let path = Svg.move_to path ~x:40. ~y:20. in
  let path = Svg.line_to path ~x:100. ~y:60. in
  let path = Svg.quad_curve path ~x1:200. ~y1:240. ~x:280. ~y:20. in
  let path = Svg.close_path path in

  Svg.add_path svg ~path
      ~fill:"#A62" ~stroke:"#247"
      ~fill_opacity:0.6
      ~stroke_width:5.0
      ~stroke_opacity:1.0
      ();

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

