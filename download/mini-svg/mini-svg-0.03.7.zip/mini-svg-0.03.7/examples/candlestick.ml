
let () =
  let width, height = (600, 360) in
  let svg = Svg.new_svg_document ~width ~height () in

  Svg.add_text svg ~x:25 ~y:25 ~text:"Candlestick Chart"
    ~font_size:16.0
    ~fill:"#999"
    ~fill_opacity:0.9 ();

  Svg.add_line svg ~x1:40 ~y1:40 ~x2:40 ~y2:(height - 40)
    ~stroke:"#999"
    ~stroke_width:1.7
    ~stroke_opacity:0.9 ();

  for i = 0 to pred 16 do
    let y = (height - 40) - (i * 18) in
    Svg.add_line svg ~x1:38 ~y1:y ~x2:40 ~y2:y
      ~stroke:"#999"
      ~stroke_width:1.2
      ~stroke_opacity:0.9 ();

    Svg.add_text svg ~x:33 ~y ~text:(Printf.sprintf "%d" (i * 4))
      ~text_anchor:"end"
      ~font_size:8.0
      ~fill:"#999"
      ~fill_opacity:0.9 ();
  done;

  Svg.add_line svg ~x1:40 ~y1:(height - 40) ~x2:(width - 40) ~y2:(height - 40)
    ~stroke:"#999"
    ~stroke_width:1.7
    ~stroke_opacity:0.9 ();

  for j = 0 to pred 24 do
    let x = 40 + (j * 22) in
    Svg.add_line svg ~x1:x ~y1:(height - 40) ~x2:x ~y2:(height - 38)
      ~stroke:"#999"
      ~stroke_width:1.7
      ~stroke_opacity:0.9 ();

    Svg.add_text svg ~x ~y:(height - 26) ~text:(Printf.sprintf "%d" (j * 8))
      ~text_anchor:"middle"
      ~font_size:8.0
      ~fill:"#999"
      ~fill_opacity:0.9 ();
  done;

  Svg.add_newline svg;

  let candlestick (x, y) (a, b, c, d) color =
    let inv_y y = height - (y + 40) in
    let x = 40 + x in
    let a = inv_y (y + a) in
    let b = inv_y (y + b) in
    let c = inv_y (y + c) in
    let d = inv_y (y + d) in
    let h = (b - c) in
    Svg.add_line svg ~x1:(x+3) ~y1:a ~x2:(x+3) ~y2:d
      ~stroke:"#777"
      ~stroke_width:1.6
      ~stroke_opacity:0.5 ();
    Svg.add_rect svg ~x ~y:c ~width:6 ~height:h
      ~rx:3.0 ~ry:3.0
      ~fill:color
      ();
    Svg.add_newline svg;
  in

  Random.self_init ();

  for i = 0 to pred 18 do
    let x = 20 + (i * 29) in
    let y = 18 + Random.int 136 in

    let a = 2 + Random.int 26 in
    let b = a +  6 + Random.int 22 in
    let c = b + 14 + Random.int 34 in
    let d = c +  6 + Random.int 22 in

    let cl = [| "#34e"; "#e32"; "#1d2" |].(Random.int 3) in
    candlestick (x,  y) (a, b, c, d) cl;
  done;

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

