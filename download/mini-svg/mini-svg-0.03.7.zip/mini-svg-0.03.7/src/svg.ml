(* Copyright (c) 2023-2025 Florent Monnier *)
(* A mini-svg module *)
 
(* To the extent permitted by law, you can use, modify and
   redistribute this file. *)

type svg = Buffer.t

type css = string
type css_attr = string


let new_svg_document ~width ~height ?(unit = "") () =
  let b = Buffer.create 1024 in
  Printf.kprintf (Buffer.add_string b)
    {|<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
  version="1.1"
  baseProfile="full"
  xmlns="http://www.w3.org/2000/svg"
  width="%d%s"
  height="%d%s"
  viewBox="0 0 %d %d">
|} width unit height unit width height;
  (b)

let finish_svg b =
  Buffer.add_string b "\n</svg>\n";
;;



let fill           = "fill"
let fill_opacity   = "fill-opacity"
let stroke         = "stroke"
let stroke_width   = "stroke-width"
let stroke_opacity = "stroke-opacity"
let text_anchor    = "text-anchor"
let font_family    = "font-family"
let font_size      = "font-size"
let font_weight    = "font-weight"
let font_style     = "font-style"
let letter_spacing = "letter-spacing"
let word_spacing   = "word-spacing"



let to_style ~styles =
  String.concat "; " (
    List.map (fun (attr, value) ->
      Printf.sprintf "%s: %s" attr value;
    ) styles
  )



let add_text b ~x ~y ~text ?text_anchor ?dominant_baseline
      ?font_family ?font_size ?font_weight ?font_style
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let text_anchor  = match text_anchor  with None -> "" | Some v -> Printf.sprintf " text-anchor=\"%s\"" v in
  let dominant_baseline = match dominant_baseline with None -> "" | Some v -> Printf.sprintf " dominant-baseline=\"%s\"" v in
  let font_family  = match font_family  with None -> "" | Some v -> Printf.sprintf " font-family=\"%s\"" v in
  let font_size    = match font_size    with None -> "" | Some v -> Printf.sprintf " font-size=\"%g\"" v in
  let font_weight  = match font_weight  with None -> "" | Some v -> Printf.sprintf " font-weight=\"%s\"" v in
  let font_style   = match font_style   with None -> "" | Some v -> Printf.sprintf " font-style=\"%s\"" v in
  let style        = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css          = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id           = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in


  Printf.kprintf (Buffer.add_string b) {|
<text x="%d" y="%d"%s%s%s%s%s%s%s%s%s%s%s%s%s%s>%s</text>|}
  x y id css style text_anchor dominant_baseline
  font_family
  font_size
  font_weight
  font_style
  fill
  fill_opacity
  stroke
  stroke_width
  stroke_opacity
  text;
;;



let add_line b ~x1 ~y1 ~x2 ~y2 ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =

  let stroke         = match stroke         with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width   with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in

  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<line x1="%d" y1="%d" x2="%d" y2="%d"%s%s%s%s%s%s />|}
  x1 y1 x2 y2 id css style
  stroke
  stroke_width
  stroke_opacity;
;;



let add_polyline b ~points ?stroke ?stroke_width ?stroke_opacity ?fill ?fill_opacity ?id ?css ?style () =

  let stroke         = match stroke         with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width   with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let fill           = match fill           with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity   = match fill_opacity   with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in

  let style        = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css          = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id           = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  let points = List.map (fun (x, y) -> Printf.sprintf "%d,%d" x y) points in
  let points = String.concat " " points in

  Printf.kprintf (Buffer.add_string b) {|
<polyline points="%s"%s%s%s%s%s%s%s%s />|}
  points id css style stroke stroke_width stroke_opacity fill fill_opacity;
;;



let add_polygon b ~points ?stroke ?stroke_width ?stroke_opacity ?fill ?fill_opacity ?id ?css ?style () =

  let stroke         = match stroke         with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width   with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let fill           = match fill           with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity   = match fill_opacity   with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in

  let style        = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css          = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id           = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  let points = List.map (fun (x, y) -> Printf.sprintf "%d,%d" x y) points in
  let points = String.concat " " points in

  Printf.kprintf (Buffer.add_string b) {|
<polygon points="%s"%s%s%s%s%s%s%s%s />|}
  points id css style stroke stroke_width stroke_opacity fill fill_opacity;
;;



let add_rect b ~x ~y ~width ~height ?rx ?ry ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
  let fill           = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity   = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke         = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let rx      = match rx           with None -> "" | Some v -> Printf.sprintf " rx=\"%g\"" v in
  let ry      = match ry           with None -> "" | Some v -> Printf.sprintf " ry=\"%g\"" v in
  let style   = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css     = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id      = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<rect x="%d" y="%d" width="%d" height="%d"%s%s%s%s%s%s%s%s%s%s />|}
  x y width height rx ry id css fill fill_opacity stroke stroke_width stroke_opacity style;
;;



let add_circle b ~cx ~cy ~r ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style  = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css    = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id     = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<circle cx="%g" cy="%g" r="%g"%s%s%s%s%s%s%s%s />|}
  cx cy r id css fill fill_opacity stroke stroke_width stroke_opacity style
;;



let add_ellipse b ~cx ~cy ~r:radius ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
  let rx, ry = match radius with rx, ry -> (rx, ry) in
  Printf.kprintf (Buffer.add_string b) {|
<ellipse cx="%g" cy="%g" rx="%g" ry="%g"%s%s%s%s%s%s%s%s />|}
  cx cy rx ry id css fill fill_opacity stroke stroke_width stroke_opacity style
;;



let add_triangle b ~p1:(x1, y1) ~p2:(x2, y2) ~p3:(x3, y3)
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =

  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in

  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<path%s%s%s%s%s%s%s%s
   d="M%d,%d L%d,%d L%d,%d Z" />|}
  id css style
  fill fill_opacity stroke stroke_width stroke_opacity
  x1 y1 x2 y2 x3 y3
;;



let add_circle_sector b ~cx ~cy ~r ~angle1 ~angle2
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =

  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  let x1, y1 =
    (cx +. r *. cos angle1,
     cy +. r *. sin angle1)
  in
  let x2, y2 =
    (cx +. r *. cos angle2,
     cy +. r *. sin angle2)
  in
  let sweep_flag = if angle2 > angle1 then 1 else 0 in

  let angle =
    if angle2 > angle1
    then angle2 -. angle1
    else angle1 -. angle2
  in
  let pi = 3.141592653589793 in
  let large_arc = if angle > pi then 1 else 0 in

  Printf.kprintf (Buffer.add_string b) {|
<path d="M %g,%g L %g,%g A %g,%g 0 %d,%d %g,%g Z"
 %s%s%s%s%s%s%s%s />|}
  cx cy x1 y1 r r large_arc sweep_flag x2 y2
  id css style
  fill fill_opacity stroke stroke_width stroke_opacity
;;



let add_donut_slice b ~cx ~cy ~r1 ~r2 ~angle1 ~angle2
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =

  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  let x1, y1 =
    (cx +. r2 *. cos angle1,
     cy +. r2 *. sin angle1)
  in
  let x2, y2 =
    (cx +. r2 *. cos angle2,
     cy +. r2 *. sin angle2)
  in
  let sweep_flag1 = if angle2 > angle1 then 1 else 0 in
  let sweep_flag2 = if angle2 > angle1 then 0 else 1 in

  let angle =
    if angle2 > angle1
    then angle2 -. angle1
    else angle1 -. angle2
  in
  let pi = 3.141592653589793 in
  let large_arc = if angle > pi then 1 else 0 in

  let x3, y3 =
    (cx +. r1 *. cos angle2,
     cy +. r1 *. sin angle2)
  in
  let x4, y4 =
    (cx +. r1 *. cos angle1,
     cy +. r1 *. sin angle1)
  in

  Printf.kprintf (Buffer.add_string b) {|
<path d="M %g,%g L %g,%g A %g,%g 0 %d,%d %g,%g L %g,%g A %g,%g 0 %d,%d %g,%g Z"
 %s%s%s%s%s%s%s%s />|}
  x4 y4 x1 y1
  r2 r2 large_arc sweep_flag1 x2 y2
  x3 y3
  r1 r1 large_arc sweep_flag2 x4 y4
  id css style
  fill fill_opacity stroke stroke_width stroke_opacity
;;
(*
let arc_to path ~x ~y ~r:radius ?rotation ?(large_arc = false) ?(clockwise = true) () =
  if path = "" then invalid_arg "arc_to" else
  let r = match rotation with None -> 0.0 | Some r -> r in
  let rx, ry = match radius with rx, ry -> (rx, ry) in
  let large_arc_flag = match large_arc with true -> (1) | false -> (0) in
  let sweep_flag = match clockwise with true -> (1) | false -> (0) in
  let f1, f2 = (large_arc_flag, sweep_flag) in
  path ^ (Printf.sprintf " A %g,%g %g %d,%d %g,%g" rx ry r f1 f2 x y)
*)



(* Group *)

let begin_group b ?translate ?rotate ?scale () =
  let translate = match translate with None -> ""
  | Some(tx, ty) -> Printf.sprintf "translate(%g %g)" tx ty
  in
  let rotate = match rotate with None -> ""
  | Some(r, cx, cy) -> Printf.sprintf "rotate(%g,%d,%d)" r cx cy
  in
  let scale = match scale with None -> ""
  | Some(sx, sy) -> Printf.sprintf "scale(%g %g)" sx sy
  in
  let transform =
    String.concat " " (
      List.filter (fun s -> s <> "") [translate; rotate; scale])
  in
  Printf.kprintf (Buffer.add_string b) {|
<g transform="%s">|} transform
;;

let end_group b =
  Buffer.add_string b "\n</g>\n";
;;



(* Paths *)

type path = string

let empty_path = ""
let new_path () = ""

let move_to path ~x ~y =
  let sep = if path = "" then "" else " " in
  path ^ sep ^ (Printf.sprintf "M %g %g" x y)

let line_to path ~x ~y =
  if path = "" then invalid_arg "line_to" else
  path ^ (Printf.sprintf " L %g %g" x y)

let h_line path ~x =
  if path = "" then invalid_arg "h_line" else
  path ^ (Printf.sprintf " H %g" x)

let v_line path ~y =
  if path = "" then invalid_arg "v_line" else
  path ^ (Printf.sprintf " V %g" y)

let quad_curve path ~x1 ~y1 ~x ~y =
  path ^ (Printf.sprintf
    " Q %g %g, %g %g" x1 y1 x y)

let cubic_curve path ~x1 ~y1 ~x2 ~y2 ~x ~y =
  path ^ (Printf.sprintf
    " C %g %g, %g %g, %g %g" x1 y1 x2 y2 x y)

let close_path path =
  path ^ " Z"



(* The Arc command:

  A rx ry rotation large_arc_flag sweep_flag x y
  a rx ry rotation large_arc_flag sweep_flag dx dy

  " A 30 50   0 0 1 162.55 162.45"
  " A 30 50 -45 0 1 215.10 109.90"
*)

(* radius:(rx, ry)
   flags:(large_arc_flag, sweep_flag)
*)
let arc_to path ~x ~y ~r:radius ?rotation ?(large_arc = false) ?(clockwise = true) () =
  if path = "" then invalid_arg "arc_to" else
  let r = match rotation with None -> 0.0 | Some r -> r in
  let rx, ry = match radius with rx, ry -> (rx, ry) in
  let large_arc_flag = match large_arc with true -> (1) | false -> (0) in
  let sweep_flag = match clockwise with true -> (1) | false -> (0) in
  let f1, f2 = (large_arc_flag, sweep_flag) in
  path ^ (Printf.sprintf " A %g,%g %g %d,%d %g,%g" rx ry r f1 f2 x y)




let add_path b ~path
      ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
 
  let fill         = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke       = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
 
  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in
 
  Printf.kprintf (Buffer.add_string b) {|
<path%s%s%s%s%s%s%s%s
  d="%s" />|}
  id css style
  fill fill_opacity stroke stroke_width stroke_opacity
  path
;;


module Relative = struct
(* Relative commands *)

let move_to path ~x ~y =
  let sep = if path = "" then "" else " " in
  path ^ sep ^ (Printf.sprintf "m %g %g" x y)

let line_to path ~x ~y =
  if path = "" then invalid_arg "line_to" else
  path ^ (Printf.sprintf " l %g %g" x y)

let h_line path ~x =
  if path = "" then invalid_arg "h_line" else
  path ^ (Printf.sprintf " h %g" x)

let v_line path ~y =
  if path = "" then invalid_arg "v_line" else
  path ^ (Printf.sprintf " v %g" y)

let quad_curve path ~x1 ~y1 ~x ~y =
  path ^ (Printf.sprintf
    " q %g %g, %g %g" x1 y1 x y)

let cubic_curve path ~x1 ~y1 ~x2 ~y2 ~x ~y =
  path ^ (Printf.sprintf
    " c %g %g, %g %g, %g %g" x1 y1 x2 y2 x y)

let close_path path =
  path ^ " z"

let arc_to path ~x ~y ~r:radius ?rotation ?(large_arc = false) ?(clockwise = true) () =
  if path = "" then invalid_arg "arc_to" else
  let rx, ry = match radius with rx, ry -> (rx, ry) in
  let r = match rotation with None -> 0.0 | Some r -> r in
  let large_arc_flag = match large_arc with true -> (1) | false -> (0) in
  let sweep_flag = match clockwise with true -> (1) | false -> (0) in
  let f1, f2 = (large_arc_flag, sweep_flag) in
  path ^ (Printf.sprintf " a %g,%g %g %d,%d %g,%g" rx ry r f1 f2 x y)

end


module Float = struct
(* commands with floats *)

let add_line b ~x1 ~y1 ~x2 ~y2 ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =

  let stroke         = match stroke         with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width   with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in

  let style = match style with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css   = match css   with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id    = match id    with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<line x1="%g" y1="%g" x2="%g" y2="%g"%s%s%s%s%s%s />|}
  x1 y1 x2 y2 id css style
  stroke
  stroke_width
  stroke_opacity;
;;


let add_polyline b ~points ?stroke ?stroke_width ?stroke_opacity ?fill ?fill_opacity ?id ?css ?style () =

  let stroke         = match stroke         with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width   with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let fill           = match fill           with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity   = match fill_opacity   with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in

  let style        = match style  with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css          = match css    with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id           = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  let points = List.map (fun (x, y) -> Printf.sprintf "%g,%g" x y) points in
  let points = String.concat " " points in

  Printf.kprintf (Buffer.add_string b) {|
<polyline points="%s"%s%s%s%s%s%s%s%s />|}
  points id css style stroke stroke_width stroke_opacity fill fill_opacity;
;;


let add_rect b ~x ~y ~width ~height ?rx ?ry ?fill ?fill_opacity ?stroke ?stroke_width ?stroke_opacity ?id ?css ?style () =
  let fill           = match fill         with None -> "" | Some v -> Printf.sprintf " fill=\"%s\"" v in
  let fill_opacity   = match fill_opacity with None -> "" | Some v -> Printf.sprintf " fill-opacity=\"%g\"" v in
  let stroke         = match stroke       with None -> "" | Some v -> Printf.sprintf " stroke=\"%s\"" v in
  let stroke_width   = match stroke_width with None -> "" | Some v -> Printf.sprintf " stroke-width=\"%g\"" v in
  let stroke_opacity = match stroke_opacity with None -> "" | Some v -> Printf.sprintf " stroke-opacity=\"%g\"" v in
  let rx      = match rx           with None -> "" | Some v -> Printf.sprintf " rx=\"%g\"" v in
  let ry      = match ry           with None -> "" | Some v -> Printf.sprintf " ry=\"%g\"" v in
  let style   = match style        with None -> "" | Some v -> Printf.sprintf " style=\"%s\"" v in
  let css     = match css          with None -> "" | Some v -> Printf.sprintf " class=\"%s\"" v in
  let id      = match id     with None -> "" | Some v -> Printf.sprintf " id=\"%s\"" v in

  Printf.kprintf (Buffer.add_string b) {|
<rect x="%g" y="%g" width="%g" height="%g"%s%s%s%s%s%s%s%s%s%s />|}
  x y width height rx ry id css fill fill_opacity stroke stroke_width stroke_opacity style;
;;


end


let add_comment b ~s () =
  Printf.kprintf (Buffer.add_string b) {|
<!-- %s -->
|} s;
;;

let add_newline b =
  Buffer.add_char b '\n';
;;

let get_svg_document b =
  (Buffer.contents b)

let print_svg_document b =
  print_string (Buffer.contents b);
;;

let write_file filename s =
  let oc = open_out filename in
  output_string oc s;
  close_out oc;
;;

let write_svg_file b ~filename =
  let s = get_svg_document b in
  write_file filename s;
;;

(* fragments *)

let new_fragment () =
  let b = Buffer.create 86 in
  (b)

let add_fragment b frag =
  Buffer.add_string b (Buffer.contents frag);
;;

