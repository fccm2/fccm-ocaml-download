
let () =
  let w, h = (160, 90) in
  let svg = Svg.new_svg_document ~width:(w) ~height:(h) () in

  let stroke_width = 5.8 in

  let red    = "#de1010" in
  let red2   = "#df2020" in
  let yellow = "#eeee00" in

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red ();

  Svg.add_rect svg
    ~x:(0) ~y:(0)
    ~width:(w)
    ~height:(h)
    ~fill:red2 ();

  List.iter (fun (scale, translate) ->

    Svg.begin_group svg ~scale ();
     Svg.begin_group svg ~translate ();
 
      Svg.add_triangle svg
        ~p1:((w/2),   10)
        ~p2:((w/2)-8, 30)
        ~p3:((w/2)+8, 30)
        ~fill:yellow
        ~stroke:yellow
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)-8,  30)
        ~p2:((w/2)-24, 70)
        ~p3:((w/2)+34, 30)
        ~fill:yellow
        ~stroke:yellow
        ~stroke_width ();
  
      Svg.add_triangle svg
        ~p1:((w/2)+8,  30)
        ~p2:((w/2)+24, 70)
        ~p3:((w/2)-34, 30)
        ~fill:yellow
        ~stroke:yellow
        ~stroke_width ();
 
     Svg.end_group svg;
    Svg.end_group svg;
  ) [
      ((0.46, 0.46), (4.6, 22.4));
      ((0.11, 0.11), (580.0, 14.8 +. (92.0 *. 1.0) ));
      ((0.11, 0.11), (620.0, 14.8 +. (92.0 *. 2.0) ));
      ((0.11, 0.11), (620.0, 14.8 +. (92.0 *. 3.0) ));
      ((0.11, 0.11), (580.0, 14.8 +. (92.0 *. 4.0) ));
    ];

  Svg.add_newline svg;
  Svg.finish_svg svg;
  Svg.print_svg_document svg;
;;

