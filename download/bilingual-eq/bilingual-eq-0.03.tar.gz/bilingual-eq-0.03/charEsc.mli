val esc : string -> string
