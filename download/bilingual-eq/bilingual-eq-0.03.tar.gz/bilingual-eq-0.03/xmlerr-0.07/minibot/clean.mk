clean:
	$(RM) *.[oa] *.so *.dll *.cm[ioxa] *.cmx[as]
