(** xmlerr, xml parsing with error *)
(* Copyright (C) 2011 Florent Monnier, Some rights reserved
  Contact: <monnier.florent(_)gmail.com>

 Permission to use, copy, modify, distribute, and sell this software and
 its documentation for any purpose is hereby granted without fee.
 No representations are made about the suitability of this software for any
 purpose.  It is provided "AS IS" without express or implied warranty.
*)

let usage () =
  Printf.eprintf "\
    usage:\n %s ( -url <url> | -file <filename> | - <input on stdin> )\n%!"
    Sys.argv.(0)

let print_from_url url =
  let statut_line, header, page =
    Http.make_request ~url ()
  in
  let xs = Xmlerr.parse_string page in
  let xs = Xmlerr.strip_white xs in
  print_endline statut_line;
  List.iter print_endline header;
  Xmlerr.print_code xs

let print_from_file fn =
  let xs = Xmlerr.parse_file fn in
  let xs = Xmlerr.strip_white xs in
  Xmlerr.print_code xs

let print_from_ic ic =
  let xs = Xmlerr.parse_ic ic in
  let xs = Xmlerr.strip_white xs in
  Xmlerr.print_code xs

let () =
  let args = List.tl (Array.to_list Sys.argv) in
  match args with
  | ["-url"; url] -> print_from_url url
  | ["-file"; filename] -> print_from_file filename
  | ["-"] -> print_from_ic stdin
  | _ -> usage ()
