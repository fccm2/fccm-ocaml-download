
This package contains "ml-conjure".
The original conjure is an ImageMagick utility.
ml-conjure is written in OCaml, so it requires the OCaml compiler,
the ImageMagick wraper for OCaml, and the XML library xml-light.

You can get OCaml from:
http://caml.inria.fr/download.en.html
(or you can use the package manager of your system)

The OCaml-ImageMagick wraper can be reached at:
http://www.linux-nantes.org/~fmonnier/OCaml/ImageMagick

Get xml-light at:
http://tech.motion-twin.com/xmllight

ml-conjure is free software,
it is distributed under the terms of the GNU General Public License.
You can find it in this package in the file LICENSE_GPL.txt,
or on the internet at: http://www.fsf.org/licensing/licenses/gpl.html

To test ml-conjure from the package directory, just run:
  make test
  make test-opt
To install, as usual:
  make install

ml-conjure is a sandbox made to experiment ergonomic enhancements for the
ImageMagick original MSL.
For explanations about MSL read the file 'documentation.html'
which you should have received along in this package.
You can also read it online:
http://www.linux-nantes.org/~fmonnier/OCaml/ml-conjure/documentation.php

In this current MSL version, there are only the basic functionalities:
multi-layers with nested recursive layers, id/idref of layers,
append layers, variables %[VAR], and that's it.

http://www.linux-nantes.org/~fmonnier/OCaml/ml-conjure/

Please notice that ml-conjure is mainly a sandbox made for experimenting,
so if you feel concerned with the conjure concepts, any kind of suggestion
are wellcome. Everything, every ergonomic choice that have been made
can be changed.

I would like in the futur to implement the functionnalities of this MSL
interpreter in the original ImageMagick conjure, but I'm not really sure that
my skills in C are solid enough :-)


-- 2006/08/06 18:49
-- Monnier Florent <fmonnier@linux-nantes.org>
