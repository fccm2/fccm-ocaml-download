#! /usr/bin/env ocaml
(* {{{ COPYING *(

  ml-conjure: a conjure (ImageMagick utility) written in OCaml
  Copyright (C) 2006  Monnier Florent

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

  http://www.fsf.org/licensing/licenses/gpl.html

)* }}} *)
#directory "+xml-light/"
#load "xml-light.cma"

#directory "+libMagick/"
#load "magick.cma"
open Magick

let id a = a ;;

let color_of_string = Magick.Imper.color_of_string ;;
let black = color_of_string "#000000" ;;
let white = color_of_string "#FFFFFF" ;;
let transparent = Magick.Imper.color_of_rgbo_tuple(0, 0, 0, Magick.get_max_colormap()) ;;

let int_of_string i = truncate(0.5 +. float_of_string i ) ;;

type err_msg = ((string -> string), unit, string) format ;;

(* {{{ get the arguements *)

let get_optional_arg ~attrs ~arg ~conv ~default =
  try conv(List.assoc arg attrs)
  with Not_found -> default
;;

(*
let get_required_arg ~attrs ~arg ~conv ~error =
  try conv(List.assoc arg attrs)
  with Not_found -> failwith(Printf.sprintf error arg)
;;
*)

let get_required_arg ~attrs ~arg ~conv ~error =
  let _arg =
    try (List.assoc arg attrs)
    with Not_found -> failwith(Printf.sprintf error arg)
  in
  try conv _arg
  with _ ->
    failwith(Printf.sprintf "'%s' wrong value for attribute '%s'" _arg arg)
;;

(* the argument have one (or more) alias *)
let get_required_alt_arg ~attrs ~arg ~conv ~error =
  let rec aux = function
    | hd::tl ->
        (try conv(List.assoc hd attrs)
         with Not_found -> aux tl)
    | [] ->
        failwith(Printf.sprintf error (List.hd arg))
  in
  aux arg
;;

(* }}} *)
(* {{{ var management *)

(* {{{ put_var *)

(* add a variable in the vars assoc list *)

(*
  <set var='TS' op='sin' val='60' />
  TODO: op OR val
*)

let put_var ~vars ~attrs =
  let var_name =
    try List.assoc "var" attrs
    with Not_found -> failwith "variable name missing ('var' attribute)"
  in
  let var_value =
    try List.assoc "value" attrs
    with Not_found -> failwith(Printf.sprintf "value for variable '%s' is missing" var_name)
  in
  let op =
    try List.assoc "op" attrs
    with Not_found -> "="
  in
  let new_value op =
    let prev_value =
      try List.assoc var_name vars
      with Not_found -> failwith(Printf.sprintf "variable '%s' is not previously set" var_name)
    in
    let f = float_of_string in
    match op with
    | "+" -> (f prev_value) +. (f var_value)
    | "-" -> (f prev_value) -. (f var_value)
    | "/" -> (f prev_value) /. (f var_value)
    | "*" -> (f prev_value) *. (f var_value)
    | "**"
    | "^" -> (f prev_value) ** (f var_value)
    | "%" -> mod_float (f prev_value) (f var_value)
    | err -> failwith(Printf.sprintf "unknown operator '%s'" err)
  in
  let var_value =
    match op with
    | "=" -> var_value
    |  _  -> string_of_float(new_value op)
  in
  let new_var = (var_name, var_value) in
  (new_var::vars)
;;
(* }}} *)

(* {{{ replace vars *)

(* {{{ str_replace *)

let str_replace ~vars str =
  let len = String.length str in

  (* get the begining position of all the vars *)
  let rec start_var acc i =
    if i >= 0 then begin
      if str.[i] = '%' &&
         str.[succ i] = '['
      then start_var (i+2::acc) (pred i)
      else start_var acc (pred i)
    end else
      (acc)
  in
  let start_pos = start_var [] (len - 4) in

  (* get the ending position of all the vars *)
  let rec ends i =
    if i < len then begin
      if str.[i] = ']'
      then i
      else ends (succ i)
    end else
      raise Not_found
  in
  let end_pos = List.map ends start_pos in

  let rec loop i buf ~start_pos ~end_pos =
    match start_pos, end_pos with
    | start::start_pos, _end::end_pos ->
        begin try
          let var = String.sub str start (_end - start) in
          let value = List.assoc var vars in
          let _prev = String.sub str i (start - i - 2) in
          Buffer.add_string buf _prev;
          Buffer.add_string buf value;
          loop (succ _end) buf ~start_pos ~end_pos
        with Not_found ->
          loop i buf ~start_pos ~end_pos
        end
    | [], _ | _, [] ->
        let _end = String.sub str i (len - i) in
        Buffer.add_string buf _end;
        Buffer.contents buf
  in
  let buf = Buffer.create 16 in
  loop 0 buf ~start_pos ~end_pos;
;;
(* }}} *)

(* replace the vars by its values in the attributes of a function *)

let replace_vars ~attrs ~vars =
  let rec aux acc = function [] -> acc
    | (k,v)::tl ->
        let v = str_replace ~vars v in
        aux ((k,v)::acc) tl
  in
  aux [] attrs
;;

(* }}} *)

(* }}} *)

(* {{{ fun filters *)

(* {{{ display *)

let display ~attrs ~img_hdl =
  (Magick.Fun.view () img_hdl)

(* }}} *)
(* {{{ write_image *)

let write_image ~attrs ~img_hdl =
  let error = ("the filter 'emboss' expects an attribute '%s'" :err_msg)
  in
  let filename = get_required_arg ~attrs ~arg:"filename" ~conv:id ~error
  in
  Magick.write_image img_hdl filename;
  (img_hdl)

(* }}} *)
(* {{{ emboss *)

let emboss ~attrs ~img_hdl =
  let error = ("the filter 'emboss' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma" ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  in
  (Magick.Fun.emboss ~radius ~sigma () img_hdl)

(* }}} *)
(* {{{ charcoal *)

let charcoal ~attrs ~img_hdl =
  let error = ("the filter 'charcoal' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma" ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  in
  (Magick.Fun.charcoal ~radius ~sigma () img_hdl)

(* }}} *)
(* {{{ blur *)

let blur ~attrs ~img_hdl =
  let error = ("the filter 'blur' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma"  ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  in
  (Magick.Fun.blur ~radius ~sigma () img_hdl)

(* }}} *)
(* {{{ gaussian_blur *)

let gaussian_blur ~attrs ~img_hdl =
  let error = ("the filter 'gaussian_blur' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma" ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  in
  (Magick.Fun.gaussian_blur ~radius ~sigma () img_hdl)

(* }}} *)
(* {{{ radial_blur *)

let radial_blur ~attrs ~img_hdl =
  let error = ("the filter 'radial_blur' expects an attribute '%s'" :err_msg)
  and conv  = float_of_string in
  let angle = get_required_arg ~attrs ~arg:"angle" ~conv ~error
  in
  (Magick.Fun.radial_blur ~angle () img_hdl)

(* }}} *)
(* {{{ radial_blur_channel *)

let radial_blur_channel ~attrs ~img_hdl =
  let error = ("the filter 'radial_blur_channel' expects an attribute '%s'" :err_msg) in
  let angle   = get_required_arg ~attrs ~arg:"angle"   ~conv:float_of_string ~error
  and channel = get_required_arg ~attrs ~arg:"channel" ~conv:channel_type_of_string' ~error
  in
  (Magick.Fun.radial_blur_channel ~channel ~angle () img_hdl)

(* }}} *)
(* {{{ motion_blur *)

let motion_blur ~attrs ~img_hdl =
  let error = ("the filter 'motion_blur' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma"  ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  and angle  = get_optional_arg ~attrs ~arg:"angle"  ~conv ~default:0.0
  in
  (Magick.Fun.motion_blur ~radius ~sigma ~angle () img_hdl)

(* }}} *)
(* {{{ swirl *)

let swirl ~attrs ~img_hdl =
  let error = ("the filter 'swirl' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let degrees = get_required_arg ~attrs ~arg:"degrees" ~conv ~error
  in
  (Magick.Fun.swirl ~degrees () img_hdl)

(* }}} *)
(* {{{ edge *)

let edge ~attrs ~img_hdl =
  let error = ("the filter 'edge' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  in
  (Magick.Fun.edge ~radius () img_hdl)

(* }}} *)
(* {{{ implode *)

let implode ~attrs ~img_hdl =
  let error = ("the filter 'implode' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let amount = get_required_arg ~attrs ~arg:"amount" ~conv ~error
  in
  (Magick.Fun.implode ~amount () img_hdl)

(* }}} *)
(* {{{ medianfilter *)

let medianfilter ~attrs ~img_hdl =
  let error = ("the filter 'medianfilter' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  in
  (Magick.Fun.medianfilter ~radius () img_hdl)

(* }}} *)
(* {{{ spread *)

let spread ~attrs ~img_hdl =
  let error = ("the filter 'spread' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  in
  (Magick.Fun.spread ~radius () img_hdl)

(* }}} *)
(* {{{ roll *)

let roll ~attrs ~img_hdl =
  let error = ("the filter 'roll' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x = get_required_arg ~attrs ~arg:"x" ~conv ~error
  and y = get_required_arg ~attrs ~arg:"y" ~conv ~error
  in
  (Magick.Fun.roll ~x ~y () img_hdl)

(* }}} *)
(* {{{ sample *)

let sample ~attrs ~img_hdl =
  let error = ("the filter 'sample' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  in
  (Magick.Fun.sample ~width ~height () img_hdl)

(* }}} *)
(* {{{ scale *)

let scale ~attrs ~img_hdl =
  let error = ("the filter 'scale' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  in
  (Magick.Fun.scale ~width ~height () img_hdl)

(* }}} *)
(* {{{ thumbnail *)

let thumbnail ~attrs ~img_hdl =
  let error = ("the filter 'thumbnail' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  in
  (Magick.Fun.thumbnail ~width ~height () img_hdl)

(* }}} *)
(* {{{ resize [XXX] *)

let resize ~attrs ~img_hdl =
  let error = ("the filter 'resize' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  and filter = get_required_arg ~attrs ~arg:"filter" ~conv:Magick.resize_filter_of_string' ~error
  and blur   = get_optional_arg ~attrs ~arg:"blur"   ~conv:float_of_string ~default:1.0
  in
  (Magick.Fun.resize ~width ~height ~filter ~blur () img_hdl)

(* }}} *)
(* {{{ shade [XXX] *)

let shade ~attrs ~img_hdl =
  let error = ("the filter 'shade' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let azimuth = get_required_arg ~attrs ~arg:"azimuth" ~conv ~error
  and elevation = get_required_arg ~attrs ~arg:"elevation" ~conv ~error
  in
  (Magick.Fun.shade ~azimuth ~elevation () img_hdl) (* TODO: ~gray *)

(* }}} *)
(* {{{ crop *)

let crop ~attrs ~img_hdl =
  let error = ("the filter 'crop' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x = get_required_arg ~attrs ~arg:"x" ~conv ~error
  and y = get_required_arg ~attrs ~arg:"y" ~conv ~error
  and width = get_required_arg ~attrs ~arg:"width" ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  in
  (Magick.Fun.crop ~x ~y ~width ~height () img_hdl)

(* }}} *)
(* {{{ splice *)

let splice ~attrs ~img_hdl =
  let error = ("the filter 'splice' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x = get_required_arg ~attrs ~arg:"x" ~conv ~error
  and y = get_required_arg ~attrs ~arg:"y" ~conv ~error
  and width = get_required_arg ~attrs ~arg:"width" ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  in
  (Magick.Fun.splice ~x ~y ~width ~height () img_hdl)

(* }}} *)
(* {{{ enhance *)

let enhance ~attrs ~img_hdl =
  (Magick.Fun.enhance () img_hdl)

(* }}} *)
(* {{{ despeckle *)

let despeckle ~attrs ~img_hdl =
  (Magick.Fun.despeckle () img_hdl)

(* }}} *)
(* {{{ minify *)

let minify ~attrs ~img_hdl =
  (Magick.Fun.minify () img_hdl)

(* }}} *)
(* {{{ magnify *)

let magnify ~attrs ~img_hdl =
  (Magick.Fun.magnify () img_hdl)

(* }}} *)
(* {{{ flip *)

let flip ~attrs ~img_hdl =
  (Magick.Fun.flip () img_hdl)

(* }}} *)
(* {{{ flop *)

let flop ~attrs ~img_hdl =
  (Magick.Fun.flop () img_hdl)

(* }}} *)
(* {{{ oilpaint *)

let oilpaint ~attrs ~img_hdl =
  let error = ("the filter 'oilpaint' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  in
  (Magick.Fun.oilpaint ~radius () img_hdl)

(* }}} *)
(* {{{ reduce_noise *)

let reduce_noise ~attrs ~img_hdl =
  let error = ("the filter 'reduce_noise' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  in
  (Magick.Fun.reduce_noise ~radius () img_hdl)

(* }}} *)
(* {{{ sharpen *)

let sharpen ~attrs ~img_hdl =
  let error = ("the filter 'sharpen' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma"  ~conv ~error
  and radius = get_optional_arg ~attrs ~arg:"radius" ~conv ~default:0.0
  in
  (Magick.Fun.sharpen ~radius ~sigma () img_hdl)

(* }}} *)
(* {{{ unsharpmask *)

let unsharpmask ~attrs ~img_hdl =
  let error = ("the filter 'unsharpmask' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let sigma  = get_required_arg ~attrs ~arg:"sigma"  ~conv ~error
  and radius = get_required_arg ~attrs ~arg:"radius" ~conv ~error
  and amount = get_required_arg ~attrs ~arg:"amount" ~conv ~error
  and threshold = get_required_arg ~attrs ~arg:"threshold" ~conv ~error
  in
  (Magick.Fun.unsharpmask ~radius ~sigma ~amount ~threshold () img_hdl)

(* }}} *)
(* {{{ wave *)

let wave ~attrs ~img_hdl =
  let error = ("the filter 'wave' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let amplitude   = get_required_arg ~attrs ~arg:"amplitude"  ~conv ~error
  and wave_length = get_required_arg ~attrs ~arg:"wave_length" ~conv ~error
  in
  (Magick.Fun.wave ~amplitude ~wave_length () img_hdl)

(* }}} *)
(* {{{ rotate *)

let rotate ~attrs ~img_hdl =
  let error = ("the filter 'rotate' expects an attribute '%s'" :err_msg)
  and conv = float_of_string in
  let degrees = get_required_arg ~attrs ~arg:"degrees"  ~conv ~error
  in
  (Magick.Fun.rotate ~degrees () img_hdl)

(* }}} *)
(* {{{ shear *)

let shear ~attrs ~img_hdl =
  let conv = float_of_string in
  let x = get_optional_arg ~attrs ~arg:"x" ~conv ~default:0.0
  and y = get_optional_arg ~attrs ~arg:"y" ~conv ~default:0.0
  in
  (Magick.Fun.shear ~x ~y () img_hdl)

(* }}} *)

(* }}} *)
(* {{{ imper filters *)

(* {{{ negate [*] *)

let negate ~attrs ~img_hdl =
  (Magick.Fun.negate () img_hdl)  (* TODO: the parameter *)

(* }}} *)
(* {{{ modulate *)

let modulate ~attrs ~img_hdl =
  let conv = int_of_string in
  let brightness = get_optional_arg ~attrs ~arg:"brightness" ~conv ~default:100
  and saturation = get_optional_arg ~attrs ~arg:"saturation" ~conv ~default:100
  and hue        = get_optional_arg ~attrs ~arg:"hue"        ~conv ~default:100
  in
  (Magick.Fun.modulate ~brightness ~saturation ~hue () img_hdl)

(* }}} *)
(* {{{ contrast *)

let contrast ~attrs ~img_hdl =
  let sharp = get_optional_arg ~attrs ~arg:"sharp" ~conv:id ~default:"increase"
  and times = get_optional_arg ~attrs ~arg:"times" ~conv:int_of_string ~default:1
  in
  let sharpen =
    match sharp with
    | "increase" -> Magick.MagickTrue
    | "reduce"   -> Magick.MagickFalse
    | _ -> invalid_arg "the 'sharp' argument for 'contrast' should be 'increase' or 'reduce'"
  in
  let rec loop i img_hdl =
    if i <= times
    then loop (succ i) (Magick.Fun.contrast ~sharpen () img_hdl)
    else (img_hdl)
  in
  loop 0 img_hdl

(* }}} *)

(* }}} *)
(* {{{ draw functions *)

(* {{{ draw_line *)

let draw_line ~attrs ~img_hdl =
  let error = ("the filter 'draw_line' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x0 = get_required_arg ~attrs ~arg:"x1" ~conv ~error
  and y0 = get_required_arg ~attrs ~arg:"y1" ~conv ~error
  and x1 = get_required_arg ~attrs ~arg:"x2" ~conv ~error
  and y1 = get_required_arg ~attrs ~arg:"y2" ~conv ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:black
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_line img_hdl ~x0 ~y0 ~x1 ~y1 ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_rectangle *)

let draw_rectangle ~attrs ~img_hdl =
  let error = ("the filter 'draw_rectangle' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x0 = get_required_arg ~attrs ~arg:"x1" ~conv ~error
  and y0 = get_required_arg ~attrs ~arg:"y1" ~conv ~error
  and x1 = get_required_arg ~attrs ~arg:"x2" ~conv ~error
  and y1 = get_required_arg ~attrs ~arg:"y2" ~conv ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:transparent
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_rectangle img_hdl ~x0 ~y0 ~x1 ~y1 ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_circle *)

let draw_circle ~attrs ~img_hdl =
  let error = ("the filter 'draw_circle' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x0 = get_required_arg ~attrs ~arg:"x1" ~conv ~error
  and y0 = get_required_arg ~attrs ~arg:"y1" ~conv ~error
  and x1 = get_required_arg ~attrs ~arg:"x2" ~conv ~error
  and y1 = get_required_arg ~attrs ~arg:"y2" ~conv ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:transparent
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_circle img_hdl ~x0 ~y0 ~x1 ~y1 ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_ellipse *)

let draw_ellipse ~attrs ~img_hdl =
  let error = ("the filter 'draw_ellipse' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let cx = get_required_arg ~attrs ~arg:"cx" ~conv ~error
  and cy = get_required_arg ~attrs ~arg:"cy" ~conv ~error
  and rx = get_required_arg ~attrs ~arg:"rx" ~conv ~error
  and ry = get_required_arg ~attrs ~arg:"ry" ~conv ~error
  and a0 = get_optional_arg ~attrs ~arg:"a1" ~conv:int_of_string ~default:0
  and a1 = get_optional_arg ~attrs ~arg:"a2" ~conv:int_of_string ~default:360
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:transparent
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_ellipse img_hdl ~cx ~cy ~rx ~ry ~a0 ~a1 ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_round_rectangle *)

let draw_round_rectangle ~attrs ~img_hdl =
  let error = ("the filter 'draw_round_rectangle' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let x0 = get_required_arg ~attrs ~arg:"x1" ~conv ~error
  and y0 = get_required_arg ~attrs ~arg:"y1" ~conv ~error
  and x1 = get_required_arg ~attrs ~arg:"x2" ~conv ~error
  and y1 = get_required_arg ~attrs ~arg:"y2" ~conv ~error
  and wc = get_required_arg ~attrs ~arg:"wc" ~conv ~error
  and hc = get_required_arg ~attrs ~arg:"hc" ~conv ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:transparent
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_round_rectangle img_hdl ~x0 ~y0 ~x1 ~y1 ~wc ~hc ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_path *)

let draw_path ~attrs ~img_hdl =
  let error = ("the filter 'draw_path' expects an attribute '%s'" :err_msg) in
  let path = get_required_arg ~attrs ~arg:"path" ~conv:id ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:black
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_path img_hdl ~path ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)
(* {{{ draw_text *)

let draw_text ~attrs ~img_hdl =
  let error = ("the filter 'draw_path' expects an attribute '%s'" :err_msg) in
  let text = get_required_arg ~attrs ~arg:"text" ~conv:id ~error
  and font = get_optional_arg ~attrs ~arg:"font" ~conv:id ~default:""
  and x = get_required_arg ~attrs ~arg:"x" ~conv:int_of_string ~error
  and y = get_required_arg ~attrs ~arg:"y" ~conv:int_of_string ~error
  and point_size   = get_required_arg ~attrs ~arg:"point_size"   ~conv:float_of_string ~error
  and fill_color   = get_optional_arg ~attrs ~arg:"fill_color"   ~conv:color_of_string ~default:black
  and stroke_color = get_optional_arg ~attrs ~arg:"stroke_color" ~conv:color_of_string ~default:transparent
  and stroke_width = get_optional_arg ~attrs ~arg:"stroke_width" ~conv:float_of_string ~default:1.0
  in
  Magick.Imper.draw_text img_hdl ~text ~font ~x ~y ~point_size ~fill_color ~stroke_color ~stroke_width ();
  (img_hdl)

(* }}} *)

(* }}} *)
(* {{{ primitives *)

(* {{{ get_canvas *)

let get_canvas ~attrs =
  let error = ("the tag 'canvas' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  and color  = get_required_arg ~attrs ~arg:"color"  ~conv:(id) ~error
  in
  (Magick.get_canvas ~width ~height ~color)

(* }}} *)
(* {{{ read_image *)

let read_image ~attrs =
  let error = ("the tag 'read_image' expects an attribute '%s'" :err_msg) in
  let filename  = get_required_arg ~attrs ~arg:"filename" ~conv:(id) ~error
  in
  (Magick.read_image ~filename)

(* }}} *)
(* {{{ create_image *)

let create_image ~attrs =
  let error = ("the tag 'make_image' expects an attribute '%s'" :err_msg)
  and conv = int_of_string in
  let width  = get_required_arg ~attrs ~arg:"width"  ~conv ~error
  and height = get_required_arg ~attrs ~arg:"height" ~conv ~error
  and pseudo_format = get_required_alt_arg ~attrs ~arg:["from"; "pseudo_format"] ~conv:(id) ~error
  in
  (Magick.create_image ~width ~height ~pseudo_format)

(* }}} *)

(* }}} *)
(* {{{ misc *)

(* {{{ print *)

let msl_print ~attrs ~img_hdl =
  let error = ("the filter 'print' expects an attribute '%s'" :err_msg) in
  let output = get_required_arg ~attrs ~arg:"output" ~conv:id ~error in
  print_endline output;
  flush_all();
  (img_hdl)

(* }}} *)
(* {{{ print *)

let set_compression ~attrs ~img_hdl =
  let error = ("the filter 'set_compression' expects an attribute '%s'" :err_msg) in
  let quality = get_required_arg ~attrs ~arg:"quality" ~conv:int_of_string ~error in
  Magick.Imper.set_compression_quality img_hdl quality;
  (img_hdl)

(* }}} *)

(* }}} *)

(* {{{ filters_list *)

let filters_list = [
  ("display", display);
  ("emboss", emboss);
  ("charcoal", charcoal);
  ("blur", blur);
  ("gaussian_blur", gaussian_blur);
  ("radial_blur", radial_blur);
  ("radial_blur_channel", radial_blur_channel);
  ("motion_blur", motion_blur);
  ("swirl", swirl);
  ("edge", edge);
  ("implode", implode);
  ("medianfilter", medianfilter);
  ("spread", spread);
  ("roll", roll);
  ("sample", sample);
  ("scale", scale);
  ("thumbnail", thumbnail);
  ("resize", resize);
  ("shade", shade);
  ("crop", crop);
  ("splice", splice);
  ("enhance", enhance);
  ("despeckle", despeckle);
  ("minify", minify);
  ("magnify", magnify);
  ("flip", flip);
  ("flop", flop);
  ("oilpaint", oilpaint);
  ("reduce_noise", reduce_noise);
  ("sharpen", sharpen);
  ("unsharpmask", unsharpmask);
  ("wave", wave);
  ("rotate", rotate);
  ("shear", shear);

  ("negate", negate);
  ("modulate", modulate);
  ("contrast", contrast);

  ("draw_line", draw_line);
  ("draw_circle", draw_circle);
  ("draw_ellipse", draw_ellipse);
  ("draw_rectangle", draw_rectangle);
  ("draw_round_rectangle", draw_round_rectangle);
  ("draw_path", draw_path);
  ("draw_text", draw_text);
  ("annotation", draw_text);  (* alias *)

  ("write_image", write_image);
  ("write", write_image);

  ("print", msl_print);
  ("set_compression", set_compression);
]

(* }}} *)

let rec create_prim vars ids ~primitive = match primitive with
  | Xml.Element("canvas", attrs, []) ->
      let attrs = replace_vars ~attrs ~vars in
      ((get_canvas ~attrs), ids, vars)
  | Xml.Element("read", attrs, []) ->
      let attrs = replace_vars ~attrs ~vars in
      ((read_image ~attrs), ids, vars)
  | Xml.Element(tag, attrs, []) when
    (tag="make" || tag="make_image" || tag="create_image" || tag="create") ->
      let attrs = replace_vars ~attrs ~vars in
      ((create_image ~attrs), ids, vars)
  | Xml.Element("composite", [], nested_layers)
  | Xml.Element("merge", [], nested_layers) ->
      let (layers,ids,vars) = parse_layers vars ids nested_layers in
      let result = merge_layers ~layers in
      (result, ids, vars)
  | Xml.Element("append",attrs,_layers) ->
      let (layers,ids,vars) = parse_layers vars ids _layers in
      let result = append_layers ~attrs ~layers in
      (result, ids, vars)
  | Xml.Element(tag,attrs,_) ->
      failwith(Printf.sprintf "unrecognised primitive for tag '%s'" tag)
  | _ ->
      failwith "unrecognised primitive"


and apply_filter img_hdl vars = function
  | Xml.Element("set",attrs,[]) ->
      let attrs = replace_vars ~attrs ~vars in
      let vars = put_var ~vars ~attrs in
      (img_hdl, vars)
  | Xml.Element(tag, attrs, []) ->
      let filter =
        try List.assoc tag filters_list
        with Not_found ->
          failwith(Printf.sprintf "unknown filter '%s'" tag)
      and attrs = replace_vars ~attrs ~vars in
      (filter ~attrs ~img_hdl, vars)
  | Xml.PCData str ->
      failwith(Printf.sprintf "filter tag expected instead of content '%s'" str)
  | _ ->
      failwith "bad filter match"


and make_layer vars ids = function
  | Some ref_hdl ->
      (* {{{ layer loaded from an idref *)
      (function
      | [] -> 
          (ref_hdl, ids, vars)
      | filters ->
          let rec _apply_filters hdl vars = function
            | filter::todo ->
                let (hdl,vars) = apply_filter hdl vars filter in
                _apply_filters hdl vars todo
            | [] -> 
                (hdl, ids, vars)
          in
          _apply_filters ref_hdl vars filters)
      (* }}} *)
  | None ->
      (* {{{ layer created from a primitive *)
      (function
      | [] ->
          failwith "empty layer"
      | primitive::filters ->
          let (hdl,ids,vars) = create_prim vars ids ~primitive in
          let rec _apply_filters hdl vars = function
            | filter::todo ->
                let (hdl,vars) = apply_filter hdl vars filter in
                _apply_filters hdl vars todo
            | [] -> 
                (hdl, ids, vars)
          in
          _apply_filters hdl vars filters)
      (* }}} *)


and process_layer ~attrs vars ids layer_src =
  let (idref, ref_comp) =
    try
      let idref_name = List.assoc "idref" attrs in
      let (hdl,compose,_) =
        try List.assoc idref_name ids
        with Not_found -> failwith(Printf.sprintf "no id found for idref '%s'" idref_name)
      in
      (Some hdl, Some compose)
    with Not_found ->
      (None, None)
  in
  let compose =
    try let op = List.assoc "compose" attrs in
      try composite_operator_of_string' op
      with Not_found -> failwith(Printf.sprintf "unrecognized composite operator: '%s'" op)
    with Not_found ->
      match ref_comp with
      | Some op -> op
      | None -> Magick.Undefined_composite_operator
  and id_name =
    try Some(List.assoc "id" attrs)
    with Not_found -> None
  and name =
    try List.assoc "name" attrs
    with Not_found -> ""
  in
  let (hdl,ids,vars) = make_layer vars ids idref layer_src in
  let layer = (hdl, compose, name) in
  let ids =
    match id_name with
    | None -> ids
    | Some id ->
        let layer = (hdl, compose, name) in
        ((id,layer)::ids)
  in
  (layer, ids, vars)


and parse_layers vars ids _layers =
  let rec parse_layer acc vars ids = function
    | Xml.Element("layer", attrs, layer_src)::tail ->
        let (layer, ids, vars) =
          process_layer ~attrs vars ids layer_src
        in
        parse_layer (layer::acc) vars ids tail
    | [] ->
        (acc, ids, vars)
    | Xml.Element(tag,_,_)::_ ->
        failwith(Printf.sprintf "the tag '%s' should be a 'layer' tag" tag)
    | Xml.PCData(str)::_ ->
        failwith(Printf.sprintf "layer tag expected instead of content '%s'" str)
  in
  parse_layer [] vars ids _layers


and merge bg =
  let rec merging = function
    | (on,op,_)::uppon ->
        Magick.Imper.composite_image  bg on  ~compose:op ();
        merging uppon
    | [] -> bg
  in
  merging

and merge_layers ~layers =
  (* merge layers starting with the background, from bottom to top *)
  match layers with
  | (bg,_,_)::uppon ->
      (merge bg uppon)
  | [] ->
      failwith "layer list empty inside 'merge' tag"


and append_layers ~attrs ~layers =
  let li = Imper.new_image_list() in
  let stack =
    try
      let stack = List.assoc "stack" attrs in
      Imper.stack_dir_of_string ~stack
    with Not_found ->
      Imper.Left_to_right
  in
  let rec append = function
    | (hdl,_,_)::others ->
        Imper.append_image_to_list li hdl ~delay:60000 ();
        at_exit(fun () -> Imper.no_op hdl);
        append others
    | [] ->
        Imper.append_images li ~stack
  in
  append(List.rev layers)
;;


let parse_msl datas =
  let rec browse acc vars ids = function [] -> acc
    | item::todo ->
        match item with
        | Xml.Element("image", attrs, img_src) ->
            let (layer, ids, vars) =
              process_layer ~attrs vars ids img_src
            in
            browse (layer::acc) vars ids todo
        | Xml.Element("set",attrs,[]) ->
            let attrs = replace_vars ~attrs ~vars in
            let vars = put_var ~vars ~attrs in
            browse acc vars ids todo
        | _ ->
            browse acc vars ids todo
  in
  browse [] [] [] datas
;;

let _ =
  let xml = Xml.parse_file Sys.argv.(1) in
  match xml with
  | Xml.Element("msl",attrs,datas) -> parse_msl datas
  | _ -> []
;;

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
