val comb2_filter: ('a -> 'a -> bool) -> 'a list -> 'a list
val comb2_map: ('a -> 'a -> 'a * 'a) -> 'a list -> 'a list
val comb2_fold: ('a list -> 'b -> 'b -> 'a list) -> 'b list -> 'a list -> 'a list
val comb2: 'a list -> ('a -> 'a -> 'b) -> 'b list -> 'b list
