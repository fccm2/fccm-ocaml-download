let comb2_filter p ls =
  let rec aux ls acc =
    match ls with
    | [] -> (List.rev acc)
    | x::xs ->
        let _acc, ys =
          List.fold_left (fun (acc, ys) y ->
            if (p x y)
            then (acc, y::ys)
            else (false, ys)
          ) (true, []) xs
        in
        let acc = if _acc then x::acc else acc in
        let ys = List.rev ys in
        aux ys acc
  in
  aux ls []

let comb2_map f ls =
  let rec aux ls acc =
    match ls with
    | [] -> (List.rev acc)
    | x::xs ->
        let x, ys =
          List.fold_left (fun (x, ys) y ->
            let x, y = (f x y) in
            (x, y::ys)
          ) (x, []) xs
        in
        aux (List.rev ys) (x::acc)
  in
  aux ls []

let comb2_fold f ls init =
  let rec aux ls acc =
    match ls with
    | [] -> (List.rev acc)
    | x::xs ->
        let acc =
          List.fold_left (fun acc y ->
            (f acc x y)
          ) acc xs
        in
        aux xs acc
  in
  aux ls init

let comb2 ls f init =
  let rec aux ls acc =
    match ls with
    | [] -> (List.rev acc)
    | hd :: tl ->
        let acc =
          List.fold_left (fun acc this -> (f hd this)::acc) acc tl
        in
        aux tl acc
  in
  aux ls init

