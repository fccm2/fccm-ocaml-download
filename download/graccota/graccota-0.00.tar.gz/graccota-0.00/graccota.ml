(* {{{ COPYING *)
(*
 * +-----------------------------------------------------------------+
 * | Copyright (C) 2006 Florent Monnier                              |
 * +-----------------------------------------------------------------+
 * | This CGI is the prototyping of a                                |
 * | web-interface for a GRAC Corppus Tagger.                        |
 * +-----------------------------------------------------------------+
 * |                                                                 |
 * | This program is free software; you can redistribute it and/or   |
 * | modify it under the terms of the GNU General Public License     |
 * | as published by the Free Software Foundation; either version 2  |
 * | of the License, or (at your option) any later version.          |
 * |                                                                 |
 * | This program is distributed in the hope that it will be useful, |
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
 * | GNU General Public License for more details.                    |
 * |                                                                 |
 * | http://www.fsf.org/licensing/licenses/gpl.html                  |
 * |                                                                 |
 * | You should have received a copy of the GNU General Public       |
 * | License along with this program; if not,                        |
 * | write to the Free Software Foundation, Inc.,                    |
 * | 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA    |
 * |                                                                 |
 * +-----------------------------------------------------------------+
 * | Author: Florent Monnier <fmonnier@linux-nantes.fr.eu.org>       |
 * +-----------------------------------------------------------------+
 *
 * $Id$
 *
 * }}} *)

let start = Unix.gettimeofday() ;;
print_string "Content-Type: text/html\r\n\r\n" ;;
open Printf ;;

(* {{{ utilities *)

let echo str = print_string str; print_string "\r\n" ;;

(* {{{ str_split *)

let str_split chr str =
  let len = String.length str in
  let rec aux pos i acc =
    if i = (pred len) then
      let item = String.sub str pos ((succ i) - pos) in
      item::acc
    else
      if str.[i] <> chr then aux pos (succ i) acc
      else
        let item = String.sub str pos (i - pos) in
        aux (succ i) (succ i) (item::acc)
  in
  aux 0 0 []
;;

let amp_split = str_split '&' ;;

(* }}} *)
(* {{{ equiv *)

let equiv c1 c2 =
  char_of_int (int_of_string (sprintf "0x%c%c" c1 c2))
;;
(* }}} *)
(* {{{ dec_chars *)

let dec_chars str =
  let len = String.length str in
  let rec aux i acc =
    if i >= len then List.rev acc else
    match str.[i] with
    | '+' -> aux (succ i) (' '::acc)
    | '%' ->
        if (i + 2) < len then
          let chr = equiv str.[succ i] str.[i + 2] in
          aux (i + 3) (chr::acc)
        else
          aux (succ i) ('%'::acc)
    | _ -> aux (succ i) (str.[i]::acc)
  in
  let lst = aux 0 [] in
  let len = List.length lst in
  let str = String.create len in
  let rec make i = function
    | [] -> str
    | c::tl -> begin str.[i] <- c; make (succ i) tl end
  in
  make 0 lst
;;
(* }}} *)
(* {{{ is_enc_chars *)

let is_enc_chars str =
  let rec aux i =
    if i < 0 then false else
    let c = str.[i] in
    c = '%' || c = '+' || aux (pred i)
  in
  aux(pred(String.length str))
;;
(* }}} *)
(* {{{ is_pct_chars *)

let is_pct_chars str =
  let rec aux i =
    if i < 0 then false else
    let c = str.[i] in
    c = ',' || c = ';' || c = '\'' || aux (pred i)
  in
  aux(pred(String.length str))
;;
(* }}} *)
(* {{{ cut in key / value *)

let cut item =
  let last = pred (String.length item) in
  let rec aux i =
    if i = last then
      (String.sub item 0 last, "")
    else if item.[i] = '=' then
      (String.sub item 0 i, String.sub item (succ i) (last - i))
    else
      aux (succ i)
  in
  aux 0
;;
(* }}} *)
(* {{{ strip empty elements *)

let strip_empty lst =
  let rec aux lst acc = match lst with
  | [] -> acc
  | (_,v) as hd::tl -> if v = "" then aux tl acc else aux tl (hd::acc)
  in
  aux lst []
;;
(* }}} *)
(* {{{ get stdin *)

let in_lines =
  let rec read_stdin acc =
    try let line = input_line stdin in read_stdin (line::acc)
    with End_of_file -> List.rev acc
  in
  read_stdin []
;;
(* }}} *)
(* {{{ file_exists *)

let file_exists ~filename =
  try Unix.access filename [Unix.F_OK];
    (true)
  with Unix.Unix_error _ ->
    (false)
;;
(* }}} *)
(* {{{  *)

let log ~filename ~logs =
  try
    let o = open_out_gen [Open_creat;Open_append] 0o0600 filename in
    output_string o logs;
    close_out o;
    Unix.chmod filename 0o0644;
    (true)
  with _ ->
    (false)
;;
(* }}} *)

(* }}} *)
(* {{{ main *)

type attribution = Anonymous | Author of string ;;

let _ =
  (* {{{ head *)
  echo "\
<?xml version='1.0' encoding='iso-8859-1' ?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
    'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>\n\
  <head>\n\
    <title>Graccota - GRAC Corpus Tagger</title>\n\
    <link rev='made' href='mailto:fmonnier@linux-nantes.fr.eu.org' />\n\
    <meta name='keywords' content='GRAC Corpus Tagger correcteur grammatical Graccota' />\n\
    <meta name='encoding' content='iso-8859-1' />\n\
    <meta name='description' content='GRAC Corpus Tagger' />\n\
    ";
  (* {{{ style *)
  echo "<style type='text/css'>\r\n\
    \
    body{ background:#666;}\r\n\
    \
    acronym{ text-decoration:none;}\r\n\
    #_grac  { color:#66F}\r\n\
    #_corpus{ color:#DE4}\r\n\
    #_tagger{ color:#E21}\r\n\
    #_graccota{ text-shadow: -1px 2px 5px #111;}\r\n\
    \
    #sentence{ font-size:1.2em; line-height: 2em; \
        background:#999; border: 1px solid #CCC;}\r\n\
    #by{ font-size:small; font-style:italic;}\r\n\
    \
    #words{}\r\n\
    ._word{ float:left; border:1px solid #777; background:#6E6E6E;}\r\n\
    ._word, ._word span{ margin: 3px; font-size:1.1em;}\r\n\
    ._word{ text-align:center;}\r\n\
    \
    select{ height:20px; font-size:xx-small; \
      color:#000; background-color:#4B5;}\r\n\
    input{ color:#000; background-color:#F63; font-weight:bold;}\r\n\
    \
    fieldset{ border:1px solid #777; background:#5D5D5D;}\r\n\
    legend{ color: #888;}\r\n\
    small{ font-size: xx-small;}\r\n\
    #bench{ font-size: xx-small; color:#444;}\r\n\
    \
    #grammar_abbr{ height:400px; overflow:auto; border:1px solid #777; text-align:center;}\r\n\
    .css_table tr td{ border:2px solid #777;}\r\n\
    .css_table tr td._desc_categ{ border:1px solid #555; \
        background:#5D5D5D; color:#F63; \
        font-weight:bold; padding-left:1.2em;}\r\n\
    .css_table{ border:2px solid #444; \
        margin-left:auto; margin-right:auto; text-align:left; \
        margin-top:0.8em; margin-bottom:2.2em;}\r\n\
    \
    </style>";
  (* }}} *)
  echo "</head>";
  (* }}} *)
  echo "<body>";
  (* {{{ process environment *(
  let env = Unix.environment() in
  for i = 0 to pred(Array.length env) do
    echo(Printf.sprintf " &nbsp; '%s'<br />" env.(i));
  done;
  )* }}} *)
  (* {{{ title *)
  echo ("<h1 id='_graccota'><acronym title='GRAC Corpus Tagger'>\
         <span id='_grac'>GRAC</span>\
         <span id='_corpus'>CO</span>\
         <span id='_tagger'>TA</span></acronym></h1>");
  (* }}} *)
  (* {{{ corpus *)
  let corpus = [|
    (* {{{ *)
    "La guerre, c'est une chose trop grave pour la confier � des militaires.", Author "Georges Cl�menceau.";
    "Offrir l'amiti� � qui veut l'amour, c'est donner du pain � qui meurt de soif.", Author "Proverbe Espagnol";
    "On perd moins de temps � se faire pardonner qu'� demander la permission.", Anonymous;
    "Si quelqu'un m'avait dit un jour que je serais Pape, j'aurais �tudi� plus s�rieusement.",
        Author "Karol Wojtyla (Jean Paul II).";
    "Quand quelqu'un dit qu'il est r�aliste, c'est qu'il s'appr�te � faire \
        quelque chose dont il a sacrement honte.", Author "Sydney Harrys";
    "Quand l'homme aura pollu� et empoisonn� tous les cours d'eau, mers et \
        oc�ans, Qu'il aura d�truit toutes les for�ts et tu� tous les animaux, \
        Il se rendra compte qu'il ne peut manger l'argent.", Author "I Guayazu";
    "Il faut remettre une fois par an son avenir en jeu.", Author "Arthur Cravan";
    "Il faut ne choisir pour �pouse que la femme qu'on choisirait pour ami, si elle �tait un homme.",
        Author "J. Joubert";
    "Ventre affam� n'a pas d'oreilles, mais il a un sacr� nez.", Author "Alphonse Allais";
    "Mieux vaut m�contenter par cent refus que de manquer � une seule promesse.", Anonymous;
    "Ce n'est pas en continuant de faire ce que l'on connait que l'on pourra faire ce que l'on ne connait pas.",
        Anonymous;
    "La hi�rarchie, c'est comme les �tag�res : plus c'est haut, moins �a sert.", Anonymous;
    "L'homme est l'animal le plus �volu�, parce que c'est lui qui fait le classement.", Anonymous;
    "Pour atteindre le bonheur il y a deux r�gles : 1 contentez vous de ce que vous avez, \
        2 essayez d'en avoir un maximum.", Anonymous;
    "Il existe deux types de gens : ceux qui divisent les gens en deux cat�gories, et les autres.", Anonymous;
    "Heureux l'�tudiant qui, comme la rivi�re, suit son cours dans son lit.", Anonymous;
    "Lorsqu'une d�cision est unanime, elle n'a pas besoin d'�tre logique.", Anonymous;
    "Si le hasard fait bien les choses, tu n'as pas d� �tre fait par hasard.", Anonymous;
    "Quand tu es du m�me avis que moi, j'ai l'impression de m'�tre tromp�.", Anonymous;
    "Nul vent n'est favorable � celui qui ne sait pas o� il va.", Anonymous;
    "Je suis aveugle, mais on trouve toujours plus malheureux que soi... J'aurais pu �tre noir.",
        Author "Ray Charles";
    "Leia est tr�s belle, mais elle a des verues plein les pieds.", Author "Yann Solo";
    "Le rire c'est comme les essuie-glaces, il permet d'avancer m�me s'il n'arr�te pas la pluie !",
        Author "G�rard Jugnot";
    "Il y a deux genre d'avocats : ceux qui connaissent bien la loi, et ceux qui connaissent bien le juge.",
        Author "Coluche";
    "D�conner, c'est se vider de la connerie acquise par osmose.", Author "Fr�d�ric Dare";
    "Plus je connais les hommes, plus j'aime les femmes.", Author "Fr�d�ric Dare";
    "L'intelligence achev�e est la facult� de fabriquer et d'employer des instruments..",
        Author "Henri Bergson, L'�volution Cr�ative";
    "Comme les maladies contagieuses, les id�es neuves demandent une certaine p�riode d'incubation \
        avant que elles soient reconnus.", Author "Arthur Koestler, les somnambules";
    "L'homme est un �tre raisonnable, mais les hommes le sont-ils ?",
        Author "Raymond Aron, Dimensions de la conscience historique";
    "Le rituel de l'�change est le rituel majeur de la neutralisation de la violence.",
        Author "Jacques Attali, Les Trois Mondes";
    "S'aimer, ce n'est pas se regarder l'un l'autre, c'est regarder ensemble dans la m�me direction.",
        Author "Antoine de Saint-Exup�ry";
    "Il faut vivre pour l'effort de vivre, pour la pierre apport�e � l'oeuvre lointaine et myst�rieuse, \
        et la seule joie possible, sur cette terre, est dans la joie de cet effort accompli.",
        Author "Emile Zola, Le Docteur Pascal";
    "Toi, qui me lis, es-tu s�r de comprendre ma langue ?", Author "Jorge Luis Borges, La biblioth�que de Babel";
    "Une femme qui se croit intelligente r�clame les m�mes droits que l'homme ; une femme intelligente y renonce.",
        Author "Colette";
    "Mais vous changez d'avis comme de chemise ? Oui, c'est une question de propret� !", Author "C�line";
    "Le meilleur moyen de prendre un train a l'heure, c'est de s'arranger pour rater le pr�c�dant.",
        Author "Marcel Achard";
    "Les hommes se contentent de tuer le temps en attendant que le temps les tue.", Author "Simone De Beauvoir";
    "La vraisemblance rend les mensonges sans cons�quence, en �tant le d�sir de les v�rifier.",
        Author "Choderlos de Laclos, Les Liaisons dangereuses";
    "�crivez dans l'ivresse, mais relisez-vous � jeun.", Author "Andr� Gide";
    "Quand un scientifique distingu� mais �g� d�clare que quelque chose est possible il a certainement raison. \
        Quand il dit que c'est impossible, il a tr�s probablement tort.", Author "Arthur C. Clarke - Loi N 1";
    "Le seul moyen de d�couvrir les limites du possible est de s'aventurer un peu au del� dans l'impossible.",
        Author "Arthur C. Clarke - Loi N 2";
    "Toute technologie suffisamment avanc�e est indistingable de la magie.",
        Author "Arthur C. Clarke - Loi N 3";
    "Ton bras est invaincu, mais non pas invincible.", Author "Le Cid, Corneille";
    "Car le jeune homme est beau, mais le vieillard est grand.", Author "Victor Hugo";
    "Le style sur l'id�e, c'est l'�mail sur la dent.", Author "Victor Hugo";
    "Son pas �tait �troit, mais sa route �tait �troite.", Author "Victor Hugo";
    "Tout a �t� dit ; mais comme personne n'�coute, il faut toujours r�p�ter.", Author "Andr� Gide";
    "Un classique c'est ce que tout le monde veut avoir lu et que personne ne veut lire.", Author "Mark Twain";
    "La violence est le dernier refuge de l'incomp�tence.", Author "Issac Asimov (Foundation)";
    "Plus le d�sir s'accroit, plus l'effet se recule.", Author "Corneille (Polyeucte)";
    "Le mal que fait un homme vit apr�s lui ; souvent ses bonnes actions vont dans la terre avec ses os.",
        Author "William Shakespeare, Jules C�sar, III, 2, Antoine";
    "Il devrait exister une science de la contrari�t�, les gens ont besoins d'�preuves difficiles et \
        d'agression pour d�velopper leurs muscles psychique.", Author "Frank Herbert, Dune";
    "Maintenant c'est complet, car cela s'ach�ve ici.", Author "Frank Herbert, Dune";
    "Il n'est probablement pas de r�v�lation plus terrible que l'instant ou vous d�couvrez que votre p�re \
        est homme... fait de chair.", Author "Frank Herbert, Dune";
    "Il n'y a pas d'issue. Nous payons la violence de nos anc�tres.", Author "Frank Herbert, Dune";
    "Que m�prisez-vous ? Par cela on vous conna�t vraiment.", Author "Frank Herbert, Dune";
    "A 15 ans j'avais d�j� appris le silence.", Author "Frank Herbert, Dune";
    "Le concept de progr�s agit comme son m�canisme de protection destin� � nous isoler des terreurs de l'avenir.",
        Author "Frank Herbert, Dune";
    "Combien de fois l'homme en col�re nie-t-il avec rage ce que lui souffle son moi int�rieur.",
        Author "Frank Herbert, Dune";
    "Chaque civilisation doit affronter une force inconsciente susceptible d'annuler, de d�vier ou de \
        contrarier presque toute intention consciente de la collectivit�.", Author "Frank Herbert, Dune";
    "Ce n'est pas a leur cr�ation que les empires souffrent de ne pas avoir de but, mais plus tard \
        lorsque qu'ils sont fermement �tablis et que leurs objectifs sont oubli�s et remplac�s par \
        des rites sans fondement.", Author "Frank Herbert, Dune";
    "La v�rit� souffre d'�tre trop analys�e.", Author "Frank Herbert, Dune";
    "Le besoin pressant d'un univers logique et coh�rent est profond�ment ancr� dans l'inconscient humain. \
        Mais l'univers r�el est toujours � peu pr�s au-del� de la logique.", Author "Frank Herbert, Dune";
    "Si le coeur humain trouve des repos en montant les hauteurs de l'affection, il s'arr�te rarement \
        sur la pente rapide des sentiments haineux.", Author "Honor� de Balzac, Le p�re Goriot";
    "On n'est point l'ami d'une femme quand on peut �tre son amant.", Author "Honor� de Balzac";
    "Quand il se pr�sente � la culture scientifique, l'esprit n'est jamais jeune. Il est m�me tr�s vieux, \
        car il a l'�ge de ses pr�jug�s.", Author "Gaston Bachelard";
    "L'Homme anim� par l'esprit scientifique d�sire sans doute savoir, mais c'est aussit�t pour mieux \
        interroger.", Author "Bachelard";
    "Si l'exp�rience usuelle ne nous pr�sentait pas les divers ph�nom�nes de la poussi�re, il est � pr�sumer \
        que l'atomisme n'e�t pas re�u des philosophes une adh�sion si prompte et qu'il n'e�t pas connu un \
        destin si facilement renouvel�.", Author "Gaston Bachelard";
    "La nature voulant faire vraiment de la chimie a finalement cr�� le chimiste.", Author "Gaston Bachelard";
    "Il semble que ce qui s'attire ce soit des syst�mes de nombres quantiques diff�rents et que ce qui se \
        repousse ce soit des syst�mes de nombres quantiques identiques.", Author "Gaston Bachelard";
    "Passer pour un idiot aux yeux d'un imb�cile est une volupt� de fin gourmet.", Author "Georges Courteline";
    "La parole n'a pas �t� donn�e � l'homme : il l'a prise.",
        Author "Guillaume Apollinaris de Kostrowitzky, dit Apollinaire";
    "Le propre du g�nie est de fournir des id�es aux cr�tins une vingtaine d'ann�es plus tard.",
        Author "Guillaume Apollinaris de Kostrowitzky, dit Apollinaire";
    "Un enfant prodige c'est un enfant dont les parents ont beaucoup d'imagination.", Author "Jean Cocteau";
    "Les miroirs feraient bien de r�fl�chir avant de renvoyer les images.", Author "Jean Cocteau";
    "La Lune est le Soleil des statues.", Author "Jean Cocteau";
    "Un beau livre, c'est celui qui s�me � foison les points d'interrogation.", Author "Jean Cocteau";
    "� force d'aller au fond des choses, on y reste.", Author "Jean Cocteau";
    "La peur de l'ennui est la seule excuse au travail.", Author "Jules Renard";
    "Il faut compter sur les autres comme sur une planche pourrie.", Author "Jules Renard";
    "Une fois qu'une femme vous a donn� son coeur, on ne peut plus se d�barrasser du reste.", Author "John Vanbrugh";
    "Pour se marier il faut un t�moin ; comme pour un accident ou un duel.", Anonymous;
    "Quand un homme dit qu'un jeu est stupide et infantile, c'est que sa femme le bat � tous les coups.", Anonymous;
    "Si l'argent n'ach�te pas l'amour, ca facilite nettement les n�gociations.", Anonymous;
    "La difficult� pour les c�libataires c'est de d�shabiller les femmes, pour les maris c'est de les habiller.",
        Anonymous;
    "Les c�libataire en connaissent plus sur les femmes que les hommes mari�s ; si ce n'�tait pas le cas, \
        il se seraient mari�s aussi.", Anonymous;
    "Le mariage n'est pas un mot, c'est une sentence.", Anonymous;
    "Le mariage est la seule guerre au cours de laquelle on dort avec son ennemi.", Anonymous;
    "Ma femme et moi, nous nous entendons parfaitement ; je n'essaie pas de diriger sa vie et \
        je n'essaie pas de diriger la mienne.", Anonymous;
    "Faites l'amour, pas la guerre. Ou alors faites les deux : mariez-vous !", Anonymous;
    "L'amour, c'est comme le nombre Pi. naturel, irrationnel et tr�s important.", Author "Lisa Hoffman";
    "Je n'ai pas peur du terrorisme : j'ai �t� marie pendant deux ans !", Author "Sam Kinison";
    "Il y a un moyen de transf�rer des fond plus rapide que les transactions bancaires �lectronique : \
        cela s'appelle le mariage.", Author "James Holt McGavran";
    "La fid�lit� est l'art de pratiquer l'adult�re seulement par la pens�e.", Author "D�couly";
    "Le mariage est un d�ner qui commence par le dessert.", Author "Jules Sandeau";
    "L'amour, c'est un coup d'oeil, un coup de rein et un coup d'�ponge.", Author "Sahra Bernard";
    "Le plus d�sagr�able dans la vie des c�libataires, ce sont les maris.", Author "Feydeau";
    "En amour il n'y a que la conqu�te et la rupture qui soient int�ressantes, le reste n'est que du \
        remplissage.", Author "Maurice Donnay";
    "Tchernobyl, Les mutations g�n�tiques continuent : une femme-tronc de 10 m�tres d'�paisseur a �t� attaqu�e \
        par un crocodile de 45 m. Elle n'a d� son salut qu'� un r�flexe de son fils. Celui-ci a assen� au \
        saurien un gros coup de palme sur la t�te arri�re gauche.", Author "Les nuls";

    (* }}} *)

    (* {{{
Edith Cresson a d�clar� qu'un anglais sur quatre est homosexuel. Alors, des Beatles, c'est lequel qui mordait l'oreiller ?...

Les allemands sortent la premi�re voiture qui se boit apr�s manger : l'Audi cointreau. Les nuls

Fait divers: Son lave glace devient fou. Il meurt noy� dans sa voiture. 

Revenus du clerg� Les pr�tres oblig�s de tirer le diable par la queue. Celui-ci ne s'en plaint pas. Les nuls

Que choisir a test� les peep shows. 60 millions de cons sont mateurs. Les nuls.

La soir�e poker qui devait r�unir Johnny Hallyday, Paul-Loup Sulitzer et Eddie Barclay a �t� annul�e. Aucun n'a trouv� de baby-sitter pour garder sa femme, ce n'est que partie remise. Les nuls.

Moscou n'a pas fini de nous �tonner: � peine cent personnes se sont rassembl�es devant le Mausol�e de L�nine, sur la Place Rouge, pour comm�morer le 68me anniversaire de la mort du p�re de la r�volution bolch�vique. Rappelons que l'entr�e est gratuite, ce qui repr�sente huit fois le salaire mensuel d'un ouvrier sovi�tique. Les nuls.

Belge Il meurt d'�puisement entre sa t�l�vision et son canap�. Les nuls

Statistiques Accident de pi�tons a Paris. Un tu� sur deux meurt des suites de son d�c�s. Les nuls

Drame des trottoirs: Un chihuahua qui faisait tranquillement ses besoins a �t� happ� par un motocrotte. Les nuls

R�v�lation : le yoga est fran�ais ! Le pantalon et le slip aux genou, la main gauche qui maintient le pull au-dessus des hanches, un anus dilat� et une main droite qui tient deux feuilles de PQ : telle est la v�ritable position du lotus. Les nuls

Us et coutumes A l'image des Fran�ais qui jettent du riz sur les mari�s, les Chinois jettent des b�rets. Les nuls

D�couverte surprenante Ils avaient un bras dans le ventre et un bras dans le dos. Il n'avaient qu'une narine au nez qui leur servait d'oreille droite. Il avaient un cou tr�s fin et une jambe plus courte que l'autre, une sur le sexe et une dans l'anus. Les Egyptiens n��taient pas dessin�s de profil mais bien de face.  Les nuls

    }}} *)

  |] in
  (* }}} *)
  (* {{{ print sentence *)

  Random.self_init();
  let len = Array.length corpus in
  let pioche = Random.int len in
  let sentence = corpus.(pioche) in
  let (sentence,by) = sentence in
  echo "<div>";
  echo(sprintf "<span id='sentence'>%s</span>" sentence);
  ( match by with Anonymous -> ()
    | Author name -> echo(sprintf "<div id='by'>%s</div>" name);
  );
  echo "</div>";
  echo "<hr style='display:none;' />";

  (* }}} *)
  (* {{{ cut sentence *)
  let phrase = sentence in

  let phrase = Str.global_replace (Str.regexp ",") " ," phrase in
  let phrase = Str.global_replace (Str.regexp ";") " ;" phrase in
  let phrase = Str.global_replace (Str.regexp "'") " ' " phrase in
  let phrase = Str.global_replace (Str.regexp "-") " - " phrase in
  let phrase = Str.global_replace (Str.regexp_string ".") " ." phrase in
  let phrase = Str.global_replace (Str.regexp_string " . . .") " ... " phrase in

  let words = Str.split (Str.regexp " ") phrase in

  (* }}} *)
  (* {{{ abbrs desc list *)
  let abbrs_desc = [
    "Auxiliaires", [
    (* {{{ auxiliary *)
      "AUXA1", "auxiliair avoir 1�re personne du singulier", "AUX-av-1-sing";
      "AUXA2", "auxiliair avoir 2nd  personne du singulier", "AUX-av-2-sing";
      "AUXA3", "auxiliair avoir 3�me personne du singulier", "AUX-av-3-sing";
      "AUXA4", "auxiliair avoir 1�re personne du pluriel",   "AUX-av-1-plur";
      "AUXA5", "auxiliair avoir 2nd  personne du pluriel",   "AUX-av-2-plur";
      "AUXA6", "auxiliair avoir 3�me personne du pluriel",   "AUX-av-3-plur";
      "NA","","";
      "AUXA",  "auxiliair avoir infinitive", "AUX-av-inf";
      "AUXE",  "auxiliair �tre infinitive",  "AUX-etr-inf";
      "NA","","";
      "AUXE4", "auxiliair �tre 1st person pluriel",   "AUX-etr-1-sing";
      "AUXE5", "auxiliair �tre 2nd person pluriel",   "AUX-etr-2-sing";
      "AUXE6", "auxiliair �tre 3rd person pluriel",   "AUX-etr-3-sing";
      "AUXE1", "auxiliair �tre 1st person singulier", "AUX-etr-1-plur";
      "AUXE2", "auxiliair �tre 2nd person singulier", "AUX-etr-2-plur";
      "AUXE3", "auxiliair �tre 3rd person singulier", "AUX-etr-3-plur";
      "NA","","";
    (* }}} *)
    ];
    "D&eacute;terminant", [
    (* {{{ *)
      "DETRMS", "d&eacute;terminant masculin singulier",       "DET-masc-sing";
      "DETRMP", "d&eacute;terminant masculin pluriel",         "DET-masc-plur";
      "DETRFS", "d&eacute;terminant f&eacute;minin singulier", "DET-fem-sing";
      "DETRFP", "d&eacute;terminant f&eacute;minin pluriel",   "DET-fem-plur";
      "NA","","";
      "DINTMS", "d&eacute;terminant ind&eacute;fini masculin singulier",       "DET-masc-sing-indef";
      "DINTMP", "d&eacute;terminant ind&eacute;fini masculin pluriel",         "DET-masc-plur-indef";
      "DINTFS", "d&eacute;terminant ind&eacute;fini f&eacute;minin singulier", "DET-fem-sing-indef";
      "DINTFP", "d&eacute;terminant ind&eacute;fini f&eacute;minin pluriel",   "DET-fem-plur-indef";
      "NA","","";
    (* }}} *)
    ];
    "Verbe Principal", [
    (* {{{ main verb *)
      "VINF",   "verbe principal infinitif", "VERB-inf";
      "NA","","";
      "VERB1",  "verbe principal 1st personne singulier", "VERB-1-sing";
      "VERB2",  "verbe principal 2nd personne singulier", "VERB-2-sing";
      "VERB3",  "verbe principal 3rd personne singulier", "VERB-3-sing";
      "VERB4",  "verbe principal 1st personne pluriel",   "VERB-1-plur";
      "VERB5",  "verbe principal 2nd personne pluriel",   "VERB-2-plur";
      "VERB6",  "verbe principal 3rd personne pluriel",   "VERB-3-plur";
      "NA","","";
    (* }}} *)
    ];
    "Adverbes", [
    (* {{{ adverbs *)
      "NE",   "adverbe n�gatif : particule 'ne'", "ADV-ne";
      "PAS",  "adverbe n�gatif : particule 'pas', 'jamais', 'point'", "ADV-pas";
      "ADVE", "adverbe", "ADV";
      "NA","","";
    (* }}} *)
    ];
    "Adjectif", [
    (* {{{ adjective *)
      "ADJEMS", "adjectif masculin singulier", "ADJ-masc-sing";
      "ADJEMP", "adjectif masculin pluriel",   "ADJ-masc-plur";
      "ADJEFS", "adjectif f�minin singulier",  "ADJ-fem-sing";
      "ADJEFP", "adjectif f�minin pluriel",    "ADJ-fem-plur";
      "NA","","";
      "ADJIFS", "adjectif indefini f�minin singulier",  "ADJ-masc-sing-indef";
      "ADJIFP", "adjectif indefini f�minin pluriel",    "ADJ-masc-plur-indef";
      "ADJIMS", "adjectif indefini masculin singulier", "ADJ-fem-sing-indef";
      "ADJIMP", "adjectif indefini masculin pluriel",   "ADJ-fem-plur-indef";
      "NA","","";
    (* }}} *)
    ];
    "Adposition", [
    (* {{{ adposition *)
      "PAU",    "adposition 'au'",      "P-au";
      "PAUX",   "adposition 'aux'",     "P-aux";
      "PDEA",   "adposition 'de', 'a'", "P-de-a";
      "PREPMS", "adposition 'de'",      "P-ms";
      "PDES",   "adposition 'des'",     "P-des";
      "PREP",   "adposition",           "P";
    (* }}} *)
    ];
    "Participe pass&eacute;", [
    (* {{{ past participle *)
      "PPASMS", "participe pass� masculin singulier", "PP-masc-sing";
      "PPASMP", "participe pass� masculin pluriel",   "PP-masc-plur";
      "PPASFS", "participe pass� f�minin singulier",  "PP-fem-sing";
      "PPASFP", "participe pass� f�minin pluriel",    "PP-fem-plur";
    (* }}} *)
    ];
    "Pronoms", [
    (* {{{ pronoun *)
      "PPOBMS", "pronom personel masculin singulier (object)", "PRO-pers-masc-sing";
      "PPOBMP", "pronom personel masculin pluriel (object)",   "PRO-pers-masc-plur";
      "PPOBFS", "pronom personel f�minin singulier (objet)",   "PRO-pers-fem-sing";
      "PPOBFP", "pronom personel f�minin pluriel (objet)",     "PRO-pers-fem-plur";
      "NA","","";
      "PPER3M", "pronom personel 3rd person masculin singulier", "PRO-pers-3p-masc-sing";
      "PPER6M", "pronom personel 3rd person masculin pluriel",   "PRO-pers-3p-masc-plur";
      "PPER3F", "pronom personel 3rd person f�minin singulier",  "PRO-pers-3p-fem-sing";
      "PPER6F", "pronom personel 3rd person f�minin pluriel",    "PRO-pers-3p-fem-plur";
      "NA","","";
      "PPER1",  "pronom personel 1�re personne du singulier", "PRO-pers-1p-sing";
      "PPER4",  "pronom personel 1�re personne du pluriel",   "PRO-pers-1p-plur";
      "PPER2",  "pronom personel 2nd personne du singulier",  "PRO-pers-2p-sing";
      "PPER5",  "pronom personel 2nd personne du pluriel",    "PRO-pers-2p-plur";
      "NA","","";
      "PINDMS", "pronom indefini masculin singulier", "PRO-ind-masc-sing";
      "PINDMP", "pronom indefini masculin pluriel",   "PRO-ind-masc-plur";
      "PINDFS", "pronom indefini f�minin singulier",  "PRO-ind-fem-sing";
      "PINDFP", "pronom indefini f�minin pluriel",    "PRO-ind-fem-plur";
      "NA","","";
      "PRELMS", "pronom relatif masculin singulier", "PRO-rel-masc-sing";
      "PRELMP", "pronom relatif masculin pluriel",   "PRO-rel-masc-plur";
      "PRELFS", "pronom relatif f�minin singulier",  "PRO-rel-fem-sing";
      "PRELFP", "pronom relatif f�minin pluriel",    "PRO-rel-fem-plur";
      "NA","","";
      "PREFMS", "reflexive pronom masculin singulier", "PRO-refl-masc-sing";
      "PREFMP", "reflexive pronom masculin pluriel",   "PRO-refl-masc-plur";
      "PREFFS", "reflexive pronom f�minin singulier",  "PRO-refl-fem-sing";
      "PREFFP", "reflexive pronom f�minin pluriel",    "PRO-refl-fem-plur";
      "NA","","";
      "PSMS",   "pronom possessif masculin singulier", "PRO-poss-masc-sing";
      "PSMP",   "pronom possessif masculin pluriel",   "PRO-poss-masc-plur";
      "PSFS",   "pronom possessif f�minin singulier",  "PRO-poss-fem-sing";
      "PSFP",   "pronom possessif f�minin pluriel",    "PRO-poss-fem-plur";
      "NA","","";
      "PDETMS", "pronom d�monstratif masculin singulier", "PRO-demon-masc-sing";
      "PDETMP", "pronom d�monstratif masculin pluriel",   "PRO-demon-masc-plur";
      "PDETFS", "pronom d�monstratif f�minin  singulier", "PRO-demon-fem-sing";
      "PDETFP", "pronom d�monstratif f�minin  pluriel",   "PRO-demon-fem-plur";
      "NA","","";
      "PINTMS", "pronom interrogatif masculin singulier", "PRO-int-masc-sing";
      "PINTMP", "pronom interrogatif masculin pluriel",   "PRO-int-masc-plur";
      "PINTFS", "pronom interrogatif f�minin  singulier", "PRO-int-fem-sing";
      "PINTFP", "pronom interrogatif f�minin  pluriel",   "PRO-int-fem-plur";
      "NA","","";
    (* }}} *)
    ];
    "Substantif", [
    (* {{{ substantive *)
      "SUBSMS", "substantif masculin singulier", "SUBST-masc-sing";
      "SUBSMP", "substantif masculin pluriel",   "SUBST-masc-plur";
      "SUBSFS", "substantif feminin singulier",  "SUBST-fem-sing";
      "SUBSFP", "substantif feminin pluriel",    "SUBST-fem-plur";
    (* }}} *)
    ];
    "Divers", [
    (* {{{ *)
      "NPRO",   "nom propre", "NOM-pr";

      "X",      "unique membership class", "X";

      "CSUB",   "subordinative conjunction", "CONJ-sub";
      "CCOO",   "coordinative conjunction",  "CONJ-coord";
      "CHIF",   "numerals", "NUM";

      "PPRE",   "present participe", "PART-pres";
    (* }}} *)
    ];
  ] in
  (* }}} *)
  (* {{{ form *)
  let key = Digest.to_hex(Digest.string sentence) in
  echo "<form action='./graccota' method='post'><div>";
  echo(sprintf "  <input type='hidden' name='key' value='%s' />" key);
  echo "   <fieldset>";
  echo "     <div id='words'>";
  (* TODO label id-for*)
  (* {{{ words *)

  let rec iter_words i = function [] -> ()
  | word::words_tl ->
      echo(sprintf " <div class='_word'><span>%s</span><br />" word);
      begin
        (* {{{ matched item *)
        let one_entry i abbr =
          echo(sprintf "  <input type='hidden' name='w%d' value='%s' id='e%d' />" i abbr i);
        in
        (* }}} *)
        match word with
        (* {{{ punctuation *)
        | ","   -> one_entry i "comma";
        | "."   -> one_entry i "point";
        | "'"   -> one_entry i "squote";
        | ":"   -> one_entry i "colon";
        | ";"   -> one_entry i "semicolon";
        | "-"   -> one_entry i "tiret";  (* ? *)
        | "?"   -> one_entry i "question";
        | "!"   -> one_entry i "bang";
        | "..." -> one_entry i "susp";  (* ? *)
        | "\""  -> one_entry i "dquote";
        | "("   -> one_entry i "lpar";
        | ")"   -> one_entry i "rpar";
        | "�"   -> one_entry i "lquote";
        | "�"   -> one_entry i "rquote";
        (* }}} *)
        | _ -> begin
          (* {{{ select *)
            echo(sprintf
                 "       <select name='w%d' id='e%d'>" i i);
            echo "          <option value='NA'></option>";
            (* {{{ options *)
            let options lst =
              let aux (abbr, expl, short) =
                echo(sprintf "\t<option value='%s'>%s</option>" abbr (*expl*) short)
              in
              let groups (label,lst) =
                echo(sprintf " <optgroup label='%s'>" label);
                List.iter aux lst;
                echo " </optgroup>";
              in
              List.iter groups lst
            in
            options abbrs_desc;
            (* }}} *)
            echo "       </select>";
          (* }}} *)
          end;
      end;
      echo "</div>";
      iter_words (succ i) words_tl
  in
  iter_words 0 words;

  (* }}} *)
  echo "       <div class='_word'>";
  echo "         <input type='submit' />";
  echo "       </div>";
  echo "     </div>";
  echo "   </fieldset>";
  echo "</div></form>";

  echo "<div style='clear:both;'></div>";
  (* }}} *)
  (* {{{ abbrs description table *)
  echo "<div id='grammar_abbr'>";
  echo "<table class='css_table'>";
  List.iter (fun (label,lst) ->
    echo(sprintf "  <tr><td colspan='2' class='_desc_categ'>%s</td></tr>" label);
    List.iter (fun (abbr, desc, short) ->
      (* let abbr = if abbr = "NA" then "" else abbr in *)
      echo(sprintf "  <tr><td>%s</td><td>%s</td></tr>" short desc);
    ) lst
  ) abbrs_desc;
  echo "</table>";
  echo "</div>";
  (* }}} *)
  (* {{{ POST VARS *)

  if (List.length in_lines) > 0 then begin
    let argv = List.hd in_lines in
    let lst = amp_split  argv in
    let lst = List.map cut lst in
    let lst = strip_empty lst in
    let rec loop lst acc =
      match lst with [] -> acc
      | (key,item)::tl ->
          let item =
            if is_enc_chars item
            then dec_chars item
            else item
          in
          let field = sprintf "\t%s='%s'\r\n" key item in
          loop tl (acc^field)
    in
    let get_appache_env env =
      try Unix.getenv env
      with _ -> ""
    in
    let user_id =
      Printf.sprintf "\tuser_agent='%s'\r\n\tremote_addr='%s'\r\n"
          (get_appache_env "HTTP_USER_AGENT")
          (get_appache_env "REMOTE_ADDR")
    in
    let fields = loop lst "" in
    let datas = ("<sentence\r\n" ^ user_id ^ fields ^ "\t/>\r\n") in
    echo ("<!--\r\n"^ datas ^"-->");
  end;
  (* }}} *)
  (* {{{ bench *)
  echo "<div id='bench'>";
  let finish = Unix.gettimeofday() in
  echo(sprintf "<div>exec-time = %.6fs</div>" (finish -. start));
  let p = Unix.times() in
  echo(sprintf "<!-- User and system time for the process = %f &nbsp; %f -->" p.Unix.tms_utime p.Unix.tms_stime);
  echo "</div>";
  (* }}} *)
  (* {{{ valid *)
  echo "<div id='valid'>";
  echo "\
      <a class='vxhtml'\n\
        href='http://validator.w3.org/check/referer'\n\
        title='Check the validity of this site&#8217;s XHTML'\n\
          ><img src='/graccota/button-xhtml.png' alt='HTML Validator' /></a>\n";
  echo "\
      <a class='vcss'\n\
        href='http://jigsaw.w3.org/css-validator/check/referer'\n\
        title='Check the validity of this site&#8217;s CSS'\n\
          ><img src='/graccota/button-css.png' alt='CSS Validator' /></a>\n";
  echo "</div>";
  (* }}} *)
  echo "</body>";
  echo "</html>";
;;
(* }}} *)

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
