(* {{{ COPYING *(

  This code groups bunchs of triangles into striangle strips.
  Copyright (C) 2008  Florent Monnier  <fmonnier@linux-nantes.org>

  This program is free software: you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, either version 3
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>

)* }}} *)
(* {{{ sorting vertices *)

let sort_v_func arr =
  let compf f = if f = 0.0 then 0 else if f > 0.0 then 1 else -1 in
  let sort_y (_,(_,y1,_)) (_,(_,y2,_)) = compf (y1 -. y2) in
  Array.sort sort_y arr;
;;

let sort_verts sort_func verts faces =
  let num_verts = Array.length verts in
  let add_ndx i = (i, verts.(i)) in
  let ndx_verts = Array.init num_verts add_ndx in
  sort_func ndx_verts;
  let rec get_ndx_assoc i acc =
    if i = num_verts then acc else
    let get_old_ndx i =
      let ndx,(_,_,_) = ndx_verts.(i) in
      (ndx)
    in
    let assoc = (get_old_ndx i, i) in
    get_ndx_assoc (succ i) (assoc :: acc)
  in
  let ndx_assoc = get_ndx_assoc 0 [] in
  let rec order_faces acc = function
    | [] -> acc
    | (a,b,c)::tl ->
        let na = List.assoc a ndx_assoc
        and nb = List.assoc b ndx_assoc
        and nc = List.assoc c ndx_assoc in
        order_faces ((na,nb,nc)::acc) tl
  in
  let ord_faces = order_faces [] faces in
  let rem_ndx (_,vert) = vert in
  let sor_verts = Array.map rem_ndx ndx_verts in
  (ord_faces, sor_verts)
;;

(* }}} *)

type group_strips = Tri of (int * int * int) | Strip of (int * int * int) list ;;


Random.self_init() ;;

let take_one_rand l () =
  let len = List.length l in
  let i = Random.int len in
  (List.nth l i), ()
;;


let track = ref [] ;;

let push_track d =
  track := d :: !track;
;;

let take_one_path l path =
  (* The track global var gets a track of each decision
     that have been made.
     If track is reversed and set to path, the decisions
     will be the same.
     If the tail of the path can be cut at any point, so
     the decisions will be the same until this point, and
     after the decisions will be taken randomly.
  *)
  let len = List.length l in
  let pop_path = function
    | [] -> raise Not_found
    | hd::tl -> (hd, tl)
  in
  let i, path =
    try
      let i, path = pop_path path in
      if i >= len then failwith "bug path";
      (i, path)
    with
      Not_found -> (Random.int len), []
  in
  push_track i;
  (List.nth l i), path
;;


let reduce_path face_path percent =
  if face_path = [] then [] else
  let len = List.length face_path in
  let new_len = truncate((float len) *. percent) in

  let rec loop i acc p =
    if i >= new_len then (List.rev acc) else
    match p with
    | [] -> failwith "bug reduce path"
    | hd::tl ->
        loop (succ i) (hd::acc) tl
  in
  loop 0 [] face_path
;;


(* {{{ _group_strips *)

let _group_strips choose_face face_path faces =
  let num_faces = List.length faces in
  let edge_tbl = Hashtbl.create (3 * num_faces) in
  let face_tbl = Hashtbl.create (3 * num_faces) in

  (* table to find a mesh triangle from one of its edges *)
  let fill_edge_tbl ((a,b,c) as f) =
    Hashtbl.add edge_tbl (a,b) f;
    Hashtbl.add edge_tbl (b,c) f;
    Hashtbl.add edge_tbl (c,a) f;
    let todo = true in
    (* table to keep track of done/todo faces *)
    Hashtbl.add face_tbl f todo;
  in
  List.iter fill_edge_tbl faces;

  let edge_tbl_mem conn =
    try
      let f = Hashtbl.find edge_tbl conn in
      (Hashtbl.find face_tbl f)
    with Not_found ->
      (false)
  in
  let edge_tbl_find conn =
    let f = Hashtbl.find edge_tbl conn in
    if (Hashtbl.find face_tbl f)
    then (f)
    else raise Not_found
  in
  let edge_tbl_find_all conn =
    let l = Hashtbl.find_all edge_tbl conn in
    let l = List.filter (fun f -> Hashtbl.find face_tbl f) l in
    (l)
  in
  let face_ok = Hashtbl.find face_tbl in

  let rec remove_each = function [] -> ()
    | f::tl ->
        Hashtbl.replace face_tbl f false;
        remove_each tl;
  in

  let rec aux acc face_path faces =

    (* search the number of faces connected for a given face *)
    let conn_face ((a,b,c) as f) =
      let l1 = edge_tbl_find_all (b,a)
      and l2 = edge_tbl_find_all (c,b)
      and l3 = edge_tbl_find_all (a,c)
      in
      let n1 = List.length l1
      and n2 = List.length l2
      and n3 = List.length l3
      in
      let n_conn = n1 + n2 + n3 in
      (f, n_conn)
    in

    let len = List.length faces in

    try
      (* number of face to pick *)
      let nb = 32 in
      (* search a start point *)
      let rec try_times times =
        if times <= 0 then raise Exit else
        let rec search_sp n acc =
          if n <= 0 then acc else
          let i = Random.int len in
          let this = List.nth faces i in
          search_sp (pred n) (this::acc)
        in
        let start_points = search_sp nb [] in
        let start_points = List.rev_map conn_face start_points in
        let start_points = List.filter (fun (f,c) -> face_ok f(* && c <> 0 *)) start_points in
        let start_points = List.sort (fun (_,a) (_,b) -> a - b) start_points in
        let start_point =
          try fst(List.hd start_points)
          with _ -> Printf.printf "#%!"; try_times (pred times)
        in
        (start_point)
      in
      let start_point = try_times (len / nb) in

      (* choose a direction from the starting point *)
      let get_first_conn (a,b,c) =
        let try_conn conn = edge_tbl_mem conn in
        if try_conn (b,a) then (b,a) else
        if try_conn (a,c) then (a,c) else
        if try_conn (c,b) then (c,b) else
        failwith "first connection bug"
      in

      let dir = false in   (* allways starts on left *)

      let rec main_loop acc f_yet dir conn f =
        try
          if List.mem f f_yet then (acc) else

          (* get the next connected face (or Not_found) *)
          let next_f = edge_tbl_find conn

          and get_next_conn (a,b,c) (d_e) =
            let select a b =
              if dir then a else b
            in
            if (d_e) = (a,b) then select (c,b) (a,c) else
            if (d_e) = (b,c) then select (a,c) (b,a) else
            if (d_e) = (c,a) then select (b,a) (c,b) else
            failwith "connection bug"
          in

          let next_conn = get_next_conn next_f conn
          and dir = not dir in     (* alternates left and right *)

          main_loop (f::acc) (f::f_yet) dir next_conn next_f
        with
          Not_found -> List.rev_append acc [f]
      in
      let strip =
        try main_loop [] [] dir (get_first_conn start_point) start_point
        with Failure("first connection bug") -> [start_point]
      in

      remove_each strip;

      Printf.printf ".%!";

      let still_todo = List.filter (function f -> not(List.mem f strip)) faces
      and done_acc = (Strip strip) :: (acc) in

      aux done_acc face_path still_todo
    with
      Exit ->
        let tris = List.rev_map (function f -> Tri f) faces in
        (List.rev_append tris acc)
  in
  aux [] face_path faces
;;

(* }}} *)
(* {{{ group_strips *)

let group_strips choose_face face_path faces =
  let num_faces = List.length faces in
  let edge_tbl = Hashtbl.create (3 * num_faces) in
  let face_tbl = Hashtbl.create (3 * num_faces) in

  (* table to find a mesh triangle from one of its edges *)
  let fill_edge_tbl ((a,b,c) as f) =
    Hashtbl.add edge_tbl (a,b) f;
    Hashtbl.add edge_tbl (b,c) f;
    Hashtbl.add edge_tbl (c,a) f;
    let todo = true in
    (* table to keep track of done/todo faces *)
    Hashtbl.add face_tbl f todo;
  in
  List.iter fill_edge_tbl faces;

  let edge_tbl_mem conn =
    try
      let f = Hashtbl.find edge_tbl conn in
      (Hashtbl.find face_tbl f)
    with Not_found ->
      (false)
  in
  let edge_tbl_find conn =
    let f = Hashtbl.find edge_tbl conn in
    if (Hashtbl.find face_tbl f)
    then (f)
    else raise Not_found
  in
  let edge_tbl_find_all conn =
    let l = Hashtbl.find_all edge_tbl conn in
    let l = List.filter (fun f -> Hashtbl.find face_tbl f) l in
    (l)
  in

  let rec remove_each = function [] -> ()
    | f::tl ->
        Hashtbl.replace face_tbl f false;
        remove_each tl;
  in

  let rec aux acc face_path faces =

    let conn_nb = Hashtbl.create (3 * num_faces) in

    (* search the number of faces connected for each face *)
    let conn_face max_conn ((a,b,c) as f) =
      let l1 = edge_tbl_find_all (b,a)
      and l2 = edge_tbl_find_all (c,b)
      and l3 = edge_tbl_find_all (a,c)
      in
      let n1 = List.length l1
      and n2 = List.length l2
      and n3 = List.length l3
      in
      let n_conn = n1 + n2 + n3 in
      let max_conn = (if n_conn > max_conn then n_conn else max_conn) in
      Hashtbl.add conn_nb n_conn f;
      (max_conn)
    in
    let max_conn = List.fold_left conn_face 0 faces in

    (* group the faces by their number of connections *)
    let rec conn_grp i acc =
      if i > max_conn then (List.rev acc) else
      let f = Hashtbl.find_all conn_nb i in
      let assoc = (i, f) in
      conn_grp (succ i) (assoc::acc)
    in
    let assoc = conn_grp 0 [] in

    (* do not process faces not connected *)
    let (out, ass) = List.partition (fun (i,_) -> i = 0) assoc in

    let isolated, out =
      let out = List.rev_map snd out in
      let out = List.flatten out in
      let res = List.rev_map (fun f -> Tri f) out in
      (res, out)
    in

    try
      (* search a start point *)
      let rec search_sp i =
        if i > max_conn then raise Exit else
        match List.assoc i ass with
        | [] -> search_sp (succ i)
        | l -> choose_face l face_path  (* choose one face from the list *)
      in
      let start_point, face_path = search_sp 1 in

      (* choose a direction from the starting point *)
      let get_first_conn (a,b,c) =
        let try_conn conn = edge_tbl_mem conn in
        let li = [] in
        let li = if try_conn (b,a) then (b,a)::li else li in
        let li = if try_conn (a,c) then (a,c)::li else li in
        let li = if try_conn (c,b) then (c,b)::li else li in
        match li with
        | [] -> failwith "first connection bug"
        | li ->
        (*  let len = List.length li in
            Printf.eprintf " (%d)" len;
            let func f =
              let q = Hashtbl.find assoc f in
              (q, f)
            in
            let qli = List.map (fun f -> func f) li in
            ignore(qli);
            !take_one li
        *)
            List.hd li;
        (*
            let len = List.length li in
            let i = Random.int len in
            (List.nth li i)
        *)
      in

      let dir = false in   (* allways starts on left *)

      let rec main_loop acc f_yet dir conn f =
        try
          if List.mem f f_yet then (acc) else

          (* get the next connected face (or Not_found) *)
          let next_f = edge_tbl_find conn

          and get_next_conn (a,b,c) (d_e) =
            let select a b =
              if dir then a else b
            in
            if (d_e) = (a,b) then select (c,b) (a,c) else
            if (d_e) = (b,c) then select (a,c) (b,a) else
            if (d_e) = (c,a) then select (b,a) (c,b) else
            failwith "connection bug"
          in

          let next_conn = get_next_conn next_f conn
          and dir = not dir in     (* alternates left and right *)

          main_loop (f::acc) (f::f_yet) dir next_conn next_f
        with
          Not_found -> List.rev_append acc [f]
      in
      let strip = main_loop [] [] dir (get_first_conn start_point) start_point in

      remove_each strip;

      Printf.printf ".%!";

      let still_todo = List.filter (function f -> not(List.mem f strip || List.mem f out)) faces
      and done_acc = (Strip strip) :: (List.rev_append isolated acc) in

      aux done_acc face_path still_todo
    with
      Exit -> (List.rev_append isolated acc)
  in
  aux [] face_path faces
;;

(* }}} *)
(* {{{ _group_strips *)

let _group_strips choose_face face_path faces =
  let rec aux acc face_path faces =
    let num_faces = List.length faces in
    let edge_tbl = Hashtbl.create (3 * num_faces) in

    let edge a b = (a,b) in  (* oriented *)

    (* table to find a mesh triangle from one of its edges *)
    let fill_edge_tbl ((a,b,c) as f) =
      Hashtbl.add edge_tbl (edge a b) f;
      Hashtbl.add edge_tbl (edge b c) f;
      Hashtbl.add edge_tbl (edge c a) f;
    in
    List.iter fill_edge_tbl faces;

    let conn_nb = Hashtbl.create (3 * num_faces) in

    (* search the number of faces connected for each face *)
    let conn_face max_conn ((a,b,c) as f) =
      let l1 = Hashtbl.find_all edge_tbl (edge b a)
      and l2 = Hashtbl.find_all edge_tbl (edge c b)
      and l3 = Hashtbl.find_all edge_tbl (edge a c)
      in
      let n1 = List.length l1
      and n2 = List.length l2
      and n3 = List.length l3
      in
      let n_conn = n1 + n2 + n3 in
      let max_conn = (if n_conn > max_conn then n_conn else max_conn) in
      Hashtbl.add conn_nb n_conn f;
      (max_conn)
    in
    let max_conn = List.fold_left conn_face 0 faces in

    (* group the faces by their number of connections *)
    let rec conn_grp i acc =
      if i > max_conn then (List.rev acc) else
      let f = Hashtbl.find_all conn_nb i in
      let assoc = (i, f) in
      conn_grp (succ i) (assoc::acc)
    in
    let assoc = conn_grp 0 [] in

    (* do not process faces not connected *)
    let (out, ass) = List.partition (fun (i,_) -> i = 0) assoc in

    let isolated, out =
      let out = List.rev_map snd out in
      let out = List.flatten out in
      let res = List.rev_map (fun f -> Tri f) out in
      (res, out)
    in

    try
      (* search a start point *)
      let rec search_sp i =
        if i > max_conn then raise Exit else
        match List.assoc i ass with
        | [] -> search_sp (succ i)
        | l -> choose_face l face_path  (* choose one face from the list *)
      in
      let start_point, face_path = search_sp 1 in

      (* choose a direction from the starting point *)
      let get_first_conn (a,b,c) =
        let try_conn conn = (Hashtbl.mem edge_tbl conn) in
        let li = [] in
        let li = if try_conn (b,a) then (b,a)::li else li in
        let li = if try_conn (a,c) then (a,c)::li else li in
        let li = if try_conn (c,b) then (c,b)::li else li in
        match li with
        | [] -> failwith "first connection bug"
        | li ->
        (*  let len = List.length li in
            Printf.eprintf " (%d)" len;
            let func f =
              let q = Hashtbl.find assoc f in
              (q, f)
            in
            let qli = List.map (fun f -> func f) li in
            ignore(qli);
            !take_one li *)
            List.hd li;
      in

      let dir = ref true in   (* allways starts on left *)
      let select a b =
        dir := not(!dir);     (* alternates left and right *)
        if !dir then a else b
      in

      let get_next_conn (a,b,c) (d_e) =
        if (d_e) = (a,b) then select (c,b) (a,c) else
        if (d_e) = (b,c) then select (a,c) (b,a) else
        if (d_e) = (c,a) then select (b,a) (c,b) else
        failwith "connection bug"
      in

      let rec main_loop acc f_yet conn f =
        try
          if List.mem f f_yet then (acc) else

          (* get the next connected face (or Not_found) *)
          let next_f = Hashtbl.find edge_tbl conn in

          let next_conn = get_next_conn next_f conn in

          main_loop (f::acc) (f::f_yet) next_conn next_f
        with
          Not_found -> List.rev_append acc [f]
      in
      let strip = main_loop [] [] (get_first_conn start_point) start_point in

      Printf.printf ".%!";

      let still_todo = List.filter (function f -> not(List.mem f strip || List.mem f out)) faces in
      let done_acc = (Strip strip) :: (List.rev_append isolated acc) in

      aux done_acc face_path still_todo
    with
      Exit -> (List.rev_append isolated acc)
  in
  aux [] face_path faces
;;

(* }}} *)

(* {{{ make_strips *)

type strip_grp = Tri_ of (int * int * int) | Strip_ of int list

type stripificated = (int * int * int) list * int list list

(* basicaly this is just a type convertion from an intermediate level
   to the usable form *)

let pnt_group f_list =
  let rec loop (a,b,c) acc = function [] -> Strip_(List.rev acc)
    | (d,e,f)::tl ->
        let acc =
          if not(List.mem d [a;b;c]) then d::acc else
          if not(List.mem e [a;b;c]) then e::acc else
          if not(List.mem f [a;b;c]) then f::acc else
          failwith "strip connection bug 3"
        in
        loop (d,e,f) acc tl
  in
  let init = function
    | (a,b,c)::(d,e,f)::tl ->
        let starts =
          if not(List.mem a [d;e;f]) then [c;b;a] else
          if not(List.mem b [d;e;f]) then [a;c;b] else
          if not(List.mem c [d;e;f]) then [b;a;c] else
          failwith "strip connection bug 1"
        in
        let acc =
          if not(List.mem d [a;b;c]) then d::starts else
          if not(List.mem e [a;b;c]) then e::starts else
          if not(List.mem f [a;b;c]) then f::starts else
          failwith "strip connection bug 2"
        in
        loop (d,e,f) acc tl
 
    | (f)::[] -> Tri_ f
    | [] -> failwith "bug: empty strip"
  in
  init f_list
;;

let make_strips l =
  let rec aux acc = function [] -> acc
    | (Tri f)::tl -> aux ((Tri_ f)::acc) tl
    | (Strip f_list)::tl -> aux ((pnt_group f_list)::acc) tl
  in
  let pre = aux [] l in
  let rec part tris strips = function
    | (Tri_ f)::tl -> part (f::tris) strips tl
    | (Strip_ s)::tl -> part tris (s::strips) tl
    | [] -> (tris, strips)
  in
  (part [] [] pre : stripificated)
;;

(* }}} *)


let stripify take_one path faces =
  let strip = make_strips (group_strips take_one path faces) in
  (strip)
;;


let count_strips (tris, strips) =
  let tri_nb = 3 * (List.length tris) in
  let strip_nb = List.fold_left (fun n s -> n + List.length s) 0 strips in
  (strip_nb, tri_nb)
;;


let reentrance (tris, strips) =
  let t = List.rev_map (fun f -> Tri f) tris in
  let split s =
    let rec aux acc (a,b) = function
      | [] -> Strip(List.rev acc)
      | c::tail ->
          let this = (a,b,c) in
          aux (this::acc) (a,c) tail
    in
    match s with
    | a::b::c::tail -> aux [(a,b,c)] (c,b) tail
    | _ -> invalid_arg "uncomplete strip"
  in
  let s = List.rev_map (fun s -> split s) strips in
  (List.rev_append t s)
;;


(* {{{ color_strip *)

let color_strip s =
  let rec aux acc = function [] -> acc
    | (Tri(a,b,c))::tl ->
        let f = (a,b,c, 1.0,1.0,1.0) in
        aux (f::acc) tl
    | (Strip strip)::tl ->
        let r,g,b_ = Random.float 1.0, Random.float 1.0, Random.float 0.6 in
        let col_strip = List.rev_map (fun (a,b,c) -> (a,b,c, r,g,b_)) strip in
        let acc = List.rev_append col_strip acc in
        aux acc tl
  in
  aux [] s
;;
(* }}} *)

(* {{{ print GL *)

let print_gl_colored(meshes, verts) =
  List.iter (fun (a,b,c, r,g,b_) ->
      Printf.printf "  glColor3 %.2f %.2f %.2f;\n" r g b_;
      Printf.printf "  glBegin GL_TRIANGLES;\n";
      let print_vert i =
        let x,y,z = verts.(i) in
        Printf.printf "    glVertex3 (%f) (%f) (%f);\n" x y z;
      in
      print_vert a;
      print_vert b;
      print_vert c;
      Printf.printf "  glEnd();\n \n";
    ) meshes;
;;

let print_gl(meshes, verts) =
  List.iter (fun (a,b,c) ->
      Printf.printf "  glBegin GL_TRIANGLES;\n";
      let print_vert i =
        let x,y,z = verts.(i) in
        Printf.printf "    glVertex3 (%f) (%f) (%f);\n" x y z;
      in
      print_vert a;
      print_vert b;
      print_vert c;
      Printf.printf "  glEnd();\n \n";
    ) meshes;
;;

let print_gl_strips oc ((tris, strips), verts) =
  let print_vert i =
    let (x,y,z) = verts.(i) in
    Printf.fprintf oc "    glVertex3 (%f) (%f) (%f);\n" x y z;
  in
  Printf.fprintf oc "  glColor3 1.0 1.0 1.0;\n";
  Printf.fprintf oc "  glBegin GL_TRIANGLES;\n";
  List.iter (fun (a,b,c) ->
      print_vert a;  print_vert b;  print_vert c;) tris;
  Printf.fprintf oc "  glEnd();\n \n";

  List.iter (function s ->
    let (r,g,b) = Random.float 1.0, Random.float 1.0, Random.float 0.6 in
    Printf.fprintf oc "  glColor3 %.2f %.2f %.2f;\n" r g b;
    Printf.fprintf oc "  glBegin GL_TRIANGLE_STRIP;\n";
    List.iter (fun p -> print_vert p) s;
    Printf.fprintf oc "  glEnd();\n \n";
  ) strips;
;;

(*
open GL

let display_gl_strips((tris, strips), verts) =
  let print_vert i =
    let (x,y,z) = verts.(i) in
    glVertex3 x y z;
  in
  glColor3 1.0 1.0 1.0;
  glBegin GL_TRIANGLES;
  List.iter (fun (a,b,c) ->
      print_vert a;  print_vert b;  print_vert c;) tris;
  glEnd();

  List.iter (function s ->
    let (r,g,b) = Random.float 1.0, Random.float 1.0, Random.float 0.6 in
    glColor3 r g b;
    glBegin GL_TRIANGLE_STRIP;
    List.iter (fun p -> print_vert p) s;
    glEnd();
  ) strips;
;;
*)
(* }}} *)

let print_data oc (tris, strips) verts =
  (* keep verts in an other file, to make it shared with triangles
  Array.iter (function (x,y,z) -> Printf.fprintf oc "%f %f %f\n" x y z;) verts;
  Printf.fprintf oc "\n";
  *)
  List.iter (function (a,b,c) -> Printf.fprintf oc "%d %d %d\n" a b c;) tris;
  List.iter (function s ->
      ignore(List.fold_left (fun sep i -> Printf.fprintf oc "%s%d" sep i; " ") "" s);
      Printf.fprintf oc "\n";
    ) strips;
;;

let print_strips oc (tris, strips) =
  List.iter (function (a,b,c) -> Printf.fprintf oc "%d %d %d\n" a b c;) tris;
  List.iter (function s ->
      ignore(List.fold_left (fun sep i -> Printf.fprintf oc "%s%d" sep i; " ") "" s);
      Printf.fprintf oc "\n";
    ) strips;
;;


(* converts a strip to a list of triangles *)
let tris_of_strip strip =
  let rec aux (a,b) o acc = function
  | [] -> List.rev acc
  | c::tail ->
      let f = (a,b,c)
      and e = if o then (c,b) else (a,c) in
      aux e (not o) (f::acc) tail      
  in
  let e, tail =
    match strip with
    | a::b::tail -> (a,b), tail
    | _ -> invalid_arg "strip"
  in                    
  aux e true [] tail
;;

(* puts the longer strips at the end *)
let sort_strips (tris, strips) =
  let strips = List.sort (fun a b -> (List.length a) - (List.length b)) strips in
  (tris, strips)
;;

(* removes n strips, and add them converted to the triangle list *)
let pop_strips (tris, strips) n =
  let rec aux i acc strips =
    if i >= n then (strips, acc) else
      match strips with
      | hd::tl -> aux (succ i) (hd::acc) tl
      | [] ->
          Printf.eprintf "warning pop strip request greater than the strip length";
          (strips, acc)
  in
  let strips, poped_strips = aux 0 [] strips in
  let poped_tris = tris_of_strip poped_strips in
  let tris = List.rev_append poped_tris tris in
  (tris, strips)
;;


(* makes random choices *)
let brute_force_search verts faces m =
  let take_one = take_one_rand in  (* take random decisions *)
  if m <= 0 then invalid_arg "number of iterations should be positive";
  let proc() =
    let strip = stripify take_one () faces in
    let str_n, tri_n = count_strips strip in
    let n = (str_n + tri_n) in
    Printf.eprintf " %d%!" n;
    (n, strip)
  in
  let rec iter i (n,best) =
    if i >= m then (Printf.eprintf "\n"; best) else
    let (nb,this) = proc() in
    let (n,best) =
      if nb < n then (nb,this) else (n,best)
    in
    iter (succ i) (n,best)
  in
  iter 1 (proc())
;;


(* The path of a stripification is the list of the decisions that
   have been made to get this stripification.
   At each iteration the path of the best stripification is
   reduced according to a percentage so at each iteration
   the beginning of the stripification will be the same than
   the best one. The end will be a random search.
   For m iterations, the percentage will grow form  1/m  to  (m-1)/m
*)
let progressive_search ~verts ~faces ~iter:m =
  let take_one = take_one_path in
  let proc path =
    track := [];
    let strip = stripify take_one path faces in
    let str_n, tri_n = count_strips strip in
    let n = (str_n + tri_n) in
    Printf.eprintf " %d%!" n;
    (n, strip, List.rev !track)
  in
  let rec iter i (n,best,best_path) =
    if i >= m then (Printf.eprintf "\n"; best) else
    begin
      let (nb,this,this_path) =
        let percent = (1.0 /. float m) *. float i in
        let base_path = reduce_path best_path percent in
        let path = base_path in
        proc path
      in
      let (n,best,best_path) =
        if nb < n then (nb,this,this_path) else (n,best,best_path)
      in
      iter (succ i) (n,best,best_path)
    end
  in
  iter 1 (proc [])
;;

(* The standard deviation is greater with the progressive_search
   than with the mix_search. So there's more chance to get a result closer
   to the optimum one.
*)

let mix_search ~verts ~faces ~iter:m ~averg_insert ~progr_insert ~rand_insert =
  let take_one = take_one_path in
  let make_li len f =
    let rec aux i acc =
      if i >= len then acc else
      let this = f() in
      aux (succ i) (this::acc)
    in
    aux 0 []
  in
  let proc path =
    track := [];
    let strip = stripify take_one path faces in
    let str_n, tri_n = count_strips strip in
    let n = (str_n + tri_n) in
    Printf.eprintf " %d%!" n;
    (n, strip, List.rev !track)
  in
  let rec iter i ((best_n,_best,best_path) as best) =
    if i >= m then (Printf.eprintf "\n"; _best) else
    begin
      Printf.eprintf " `%d" best_n;

      let make_rand() =
        let path = [] in
        proc path
      in
      let rand_li = make_li rand_insert make_rand in

      let best_deriv_aver() =
        let progressive_percent = (1.0 /. float m) *. float i in
        let random_percent = 1.0 -. (Random.float 1.0) in
        let percent = (progressive_percent +. random_percent) /. 2.0 in
        let base_path = reduce_path best_path percent in
        let path = base_path in
        proc path
      in
      let best_deriv_progr() =
        let percent = (1.0 /. float m) *. float i in
        let base_path = reduce_path best_path percent in
        let path = base_path in
        proc path
      in
      let drvp_li = make_li progr_insert best_deriv_progr in
      let drva_li = make_li averg_insert best_deriv_aver in

      let new_li = List.rev_append drvp_li rand_li in
      let new_li = List.rev_append drva_li new_li in

      let select (best_n,best,best_path) (this_n,this,this_path) =
        if this_n < best_n
        then (this_n, this, this_path)
        else (best_n, best, best_path)
      in
      let (best) =
        List.fold_left (fun best this -> select best this) best new_li
      in

      iter (succ i) (best)
    end
  in
  iter 1 (proc [])
;;


let parallel_search ~verts ~faces ~iter:m ~nb =
  let take_one = take_one_path in
  let make_li len f =
    let rec aux i acc =
      if i >= len then acc else
      let this = f() in
      aux (succ i) (this::acc)
    in
    aux 0 []
  in
  let proc path () =
    track := [];
    let strip = stripify take_one path faces in
    let str_n, tri_n = count_strips strip in
    let n = (str_n + tri_n) in
    Printf.eprintf " %d%!" n;
    (n, strip, List.rev !track)
  in
  let rec iter i bests =
    let select (best_n,best,best_path) (this_n,this,this_path) =
      if this_n < best_n
      then (this_n, this, this_path)
      else (best_n, best, best_path)
    in
    let _,_best,_ =
      List.fold_left (fun best this -> select best this) (List.hd bests) (List.tl bests)
    in
    if i >= m then (Printf.eprintf "\n"; _best) else
    begin
      (*
      let best_deriv_progr (_,_,_path) =
        let percent = (1.0 /. float m) *. float i in
        let base_path = reduce_path _path percent in
        path := base_path;
        proc()
      in
      let drv_li = List.map best_deriv_progr bests in
      *)
      let get_one_path() =
        let nb = List.length bests in
        (*
        let d = min (Random.int nb) (Random.int nb) in
        *)
        let d = Random.int nb in
        let _,_,one_path = List.nth bests d in
        (one_path)
      in
      let best_deriv_progr() =
        let percent = (1.0 /. float m) *. float i in
        let some_path = get_one_path() in
        let base_path = reduce_path some_path percent in
        let path = base_path in
        proc path ()
      in
      let drv_li = make_li nb best_deriv_progr in

      let new_li = List.rev_append drv_li bests in

      let sort (a_n,_,_) (b_n,_,_) = a_n - b_n in
      let sort_li = List.sort (sort) new_li in

      let rec trunc i acc l =
        if i >= nb then List.rev acc else
        match l with [] -> List.rev acc
        | hd::tl -> trunc (succ i) (hd::acc) tl
      in
      let bests = trunc 0 [] sort_li in

      List.iter (fun (n,_,_) -> Printf.eprintf " `%d" n) bests; Printf.eprintf "\n%!";

      iter (succ i) (bests)
    end
  in
  iter 1 (make_li nb (proc []))
;;



(* Read Datas from file *)

let read_coords_data coords_file =
  let ic = open_in coords_file in
  let verts = ref [] in
  let rec coords_loop() =
    try
      let str = input_line ic in
      let x,y,z = Scanf.sscanf str "%f %f %f" (fun x y z -> x,y,z) in
      verts := (x,y,z) :: !verts;
      coords_loop()
    with
      End_of_file ->
        close_in ic;
        (Array.of_list(List.rev !verts))
  in
  coords_loop()
;;

let read_mesh_data mesh_file =
  let ic = open_in mesh_file in
  let faces = ref [] in
  let rec mesh_loop() =
    try
      let str = input_line ic in
      let a,b,c = Scanf.sscanf str "%d %d %d" (fun a b c -> a,b,c) in
      faces := (a,b,c) :: !faces;
      mesh_loop()
    with
      End_of_file ->
        close_in ic;
        (List.rev !faces)
  in
  mesh_loop()
;;

let read_data coords_file mesh_file =
  let verts = read_coords_data coords_file
  and faces = read_mesh_data mesh_file in
  (verts, faces)
;;


(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
