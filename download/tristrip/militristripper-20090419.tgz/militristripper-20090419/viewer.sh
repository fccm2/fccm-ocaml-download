ocaml -I +glMLite str.cma GL.cma Glu.cma Glut.cma viewer.ml $1 $2
