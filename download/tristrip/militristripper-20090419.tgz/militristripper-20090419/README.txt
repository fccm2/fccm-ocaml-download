
# PREREQUISITES:

A 3D geometry can be represented by a list of faces that
are triangles.
One triangle is defined by 3 points, but most often these
points belong to another triangle too.
So to describe the geometry, instead of defining each
triangle by three (X,Y,Z) coordinates, we first put each
point in a listing, and then the triangles are defined by
three indices.

You can see an example of a geometry description in the files
"sphere.coords" and "sphere.tris" which respectively contain
(X,Y,Z) points coordinates, and a list of triangle given with
the indices of the points.


# TRI-STRIPS:

You will find visuals of what is a "triangle-strip" using
a search engine. The parameter GL_TRIANGLE_STRIP is one of
the parameter we can provide to the function glBegin() in
OpenGL. But the main advantage of trianlge-strips are not
in OpenGL anymore, because for real-time graphics there
are other memory representations more efficient.
Now the main advantage of tristrips is reducing the size
of the data storage.
One can view the tristrippification as some kind of
factorisation.

Files "*.N.strip" are the equivalent of the files "*.tris",
but with a lower file size:

 9,1K -- sphere.coords
 7,0K -- sphere.tris
 3,0K -- sphere.826.strip


# USE:

run make, then use this way:

./mk_strip.opt  sphere.coords sphere.tris

it will output a file like "sphere.826.strip" which
replaces the file "sphere.tris". 826 is the number of
trianlge strips. The less there are tristrips, the lower
the file size is.


# VISUALISATION:

You can visualise the original geometry and the tristrip
equivalent with:

sh viewer.sh sphere.coords sphere.tris
sh viewer.sh sphere.coords sphere.826.strip

The colors are made to visualise the groups of triangle
grouped in a tristrip, but the geometry itself is strictly
equivalent.


# MISC:

This piece of software currenlty returns better results
than the GTS library, but the GTS outputs a result in less
than a second, and this piece of software takes several
minutes (or hours for big geometries).
I think it would enhance the performance if the same
updated hash-table would be used at each iteration, instead
of rebuilding a new one each time (the current state is
very alpha).

Please write to me to tell me what you think about this
piece of software: <fmonnier@linux-nantes.org>


