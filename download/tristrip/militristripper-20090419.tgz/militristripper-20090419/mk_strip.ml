open Strip


let dump (bn,bstrip) verts =
  let rad = Filename.chop_extension Sys.argv.(2) in
  let filename = Printf.sprintf "%s.%d.strip" rad bn in
  let oc = open_out filename in
  let bstrip = sort_strips bstrip in
  print_data oc bstrip verts;
  close_out oc;
;;

type search_type =
  | Mix_search
  | Parallel_search
  | Progressive_search

(* default values *)
let search_type = ref Progressive_search

let _n = ref 10

let iter  = ref 3
let aver  = ref 0
let progr = ref 1
let rand  = ref 0

 
let usage = "usage:\n" ^ Sys.argv.(0) ^ " geom.coords geom.tris -n XX \n \
  [ --mix-search \n \
  | --parallel-search \n \
  | --progressive-search ] \n\
  "
 
let speclist = [
    ("--mix-search",         Arg.Unit (fun () -> search_type := Mix_search        ), ": using a mix-search");
    ("--parallel-search",    Arg.Unit (fun () -> search_type := Parallel_search   ), ": using a parallel-search");
    ("--progressive-search", Arg.Unit (fun () -> search_type := Progressive_search), ": using a progressive-search");
 
    ("-n",  Arg.Int (fun d -> _n := d), ": number of searches to do");

    ("-iter",  Arg.Int (fun d -> iter  := d), ": iter  (for the mix-search)");
    ("-aver",  Arg.Int (fun d -> aver  := d), ": aver  (for the mix-search)");
    ("-progr", Arg.Int (fun d -> progr := d), ": progr (for the mix-search)");
    ("-rand",  Arg.Int (fun d -> rand  := d), ": rand  (for the mix-search)");
  ]
 

let get_arg_geom_files () =
  let argc = Array.length Sys.argv in
  let coords_file, tris_file = ref "", ref "" in
  for i=1 to pred argc do
    if Filename.check_suffix Sys.argv.(i) ".coords" then
      coords_file := Sys.argv.(i);
    if Filename.check_suffix Sys.argv.(i) ".tris" then
      tris_file := Sys.argv.(i);
  done;
  (!coords_file, !tris_file)


let () =
  (* Read the arguments *)
  Arg.parse
    speclist
    (fun _ -> ())
    usage;

  let coords_file, tris_file = get_arg_geom_files () in

  Printf.printf "/%!";
  let verts, faces = read_data coords_file tris_file in
  Printf.printf "/%!";

  (* make n searches *)
  let n = !_n in

  let average li =
    let len = List.length li in
    let tot = List.fold_left (fun acc (this,_) -> acc + this) 0 li in 
    (float tot /. float len)
  in
  let best li =
    List.fold_left
      (fun (bn,bstrip) (n,strip) ->
            if n < bn then (n,strip) else (bn,bstrip)) (List.hd li) (List.tl li)
  in
  let rec loop i acc =
    if i > n then (average acc, best acc) else
    let strip = 
      match !search_type with
      | Mix_search -> mix_search verts faces !iter !aver !progr !rand
      | Parallel_search -> parallel_search ~verts ~faces ~iter:75 ~nb:2
      | Progressive_search -> progressive_search verts faces 130
    in 
    let str_n, tri_n = count_strips strip in
    let n = (str_n + tri_n) in
    Printf.eprintf " result %d: %d\n%!" i n;
    (*
    if n < 2518 then dump n strip verts;
    *)
    loop (succ i) ((n,strip)::acc)
  in
  let aver, best_strip = loop 1 [] in
  Printf.eprintf " %d * %f\n" n aver;
  dump best_strip verts;
;;

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
