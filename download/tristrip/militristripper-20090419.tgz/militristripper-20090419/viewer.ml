open GL
open Glu
open Glut

let b_down = ref false
let anglex = ref (0)
let angley = ref (90)
let xold = ref 0
let yold = ref 0
let slide_lr = ref 0.0
let slide_ud = ref 0.0
let list_id = ref 0

let scale_f = ref 1.8

let () = Random.self_init() ;;

(* {{{ read the datas *)

let read_coords_data coords_file =
  let ic = open_in coords_file in
  let verts = ref [] in
  let rec coords_loop() =
    try
      let str = input_line ic in
      let x,y,z = Scanf.sscanf str "%f %f %f" (fun x y z -> x,y,z) in
      verts := (x,y,z) :: !verts;
      coords_loop()
    with
      End_of_file ->
        close_in ic;
        (Array.of_list(List.rev !verts))
  in
  coords_loop()
;;

let read_mesh_data mesh_file =
  let ic = open_in mesh_file in
  let faces = ref [] in
  let rec mesh_loop() =
    try
      let str = input_line ic in
      let strip = Str.split (Str.regexp " ") str in
      let strip = List.map int_of_string strip in
      faces := strip :: !faces;
      mesh_loop()
    with
      End_of_file ->
        close_in ic;
        (List.rev !faces)
  in
  mesh_loop()
;;

let read_data coords_file mesh_file =
  let verts = read_coords_data coords_file
  and mesh = read_mesh_data mesh_file in
  (verts, mesh)
;;

let verts, strips = read_data Sys.argv.(1) Sys.argv.(2) ;;

(* }}} *)
(* {{{ callback display *)
(* {{{ display_text *)

let display_text ~x ~y ~z ~txt =
  let f = GLUT_BITMAP_9_BY_15 in  (* GLUT_BITMAP_HELVETICA_18 *)

  let restore =
    if (glIsEnabled Enabled.GL_DEPTH_TEST)
    then (fun () -> glEnable GL_DEPTH_TEST;)
    else (fun () -> ())
  in

  (*
  glDisable GL_TEXTURE_2D;
  *)
  glDisable GL_DEPTH_TEST;
  glColor3 1.0 1.0 1.0;

  glRasterPos3 x y z;

  glPushMatrix();
    glLoadIdentity();

    for i=0 to pred(String.length txt)
    do
      glutBitmapCharacter f txt.[i];
    done;

  glPopMatrix();
  restore();
;;
(* }}} *)

let comp = ref false ;;

let print_gl_strips() =
  match !comp with
  | true -> glCallList !list_id;
  | false ->
      glNewList !list_id GL_COMPILE_AND_EXECUTE;
      let print_vert i =
        let (x,y,z) = verts.(i) in
        glVertex3 x y z;
      in
      List.iter (function s ->
          let (r,g,b) =
            ( Random.float 1.0,
              Random.float 1.0,
              Random.float 0.6 )
          in
          glColor3 r g b;
          glBegin GL_TRIANGLE_STRIP;
            List.iter print_vert s;
          glEnd();
        ) strips;
      glEndList();
      comp := true;
;;

let display =
  function () ->
  glClear ~mask:[GL_COLOR_BUFFER_BIT; GL_DEPTH_BUFFER_BIT];

  glLoadIdentity();

  glTranslate ~x:(0.0) ~y:(0.0) ~z:(-10.0);
  glTranslate ~x:(!slide_lr) ~y:(!slide_ud) ~z:(-10.0);

  glRotate ~angle:(float(- !angley)) ~x:1.0 ~y:0.0 ~z:0.0;
  glRotate ~angle:(float(- !anglex)) ~x:0.0 ~y:1.0 ~z:0.0;

  glScale !scale_f !scale_f !scale_f;

  print_gl_strips();

  glFlush();
  glutSwapBuffers();
;;
(* }}} *)
(* {{{ callback reshape *)

let reshape ~width ~height =
  glMatrixMode GL_PROJECTION;
  glLoadIdentity();
  gluPerspective 30. (float width /. float height) 2. 30.;
  glViewport 0 0 width height;
  glMatrixMode GL_MODELVIEW;
  glutPostRedisplay();
;;
(* }}} *)
(* {{{ callback keyboard *)

let keyboard ~key ~x ~y =
  match key with
  | '+' -> scale_f := !scale_f *. 1.2;  glutPostRedisplay();
  | '-' -> scale_f := !scale_f /. 1.2;  glutPostRedisplay();
  | 'e' -> Printf.printf " %d %d\n%!" !anglex !angley;
  | 'p' -> glPolygonMode GL_FRONT_AND_BACK  GL_FILL;  glutPostRedisplay();
  | 'f' -> glPolygonMode GL_FRONT_AND_BACK  GL_LINE;  glutPostRedisplay();
  | 's' -> glPolygonMode GL_FRONT_AND_BACK  GL_POINT; glutPostRedisplay();
  | 'd' -> glEnable GL_DEPTH_TEST; glutPostRedisplay();
  | 'D' -> glDisable GL_DEPTH_TEST; glutPostRedisplay();
  | '.' ->
      glDeleteLists !list_id 1;
      comp := false;
      glutPostRedisplay();
  | 'm' -> 
        (*
        let m = glGetMatrix Get.GL_PROJECTION_MATRIX in
        glLoadIdentity();
        *)
        let m = glGetMatrix Get.GL_MODELVIEW_MATRIX in
        Printf.printf
          " %f  %f  %f  %f\n \
            %f  %f  %f  %f\n \
            %f  %f  %f  %f\n \
            %f  %f  %f  %f\n%!" 
            m.(0).(0)  m.(0).(1)  m.(0).(2)  m.(0).(3)
            m.(1).(0)  m.(1).(1)  m.(1).(2)  m.(1).(3)
            m.(2).(0)  m.(2).(1)  m.(2).(2)  m.(2).(3)
            m.(3).(0)  m.(3).(1)  m.(3).(2)  m.(3).(3);
      (*
      let mats = [
        Get.GL_COLOR_MATRIX;
        Get.GL_MODELVIEW_MATRIX;
        Get.GL_PROJECTION_MATRIX;
        Get.GL_TEXTURE_MATRIX ] in
      List.iter (fun _m ->
        let m = glGetMatrix _m in
        Printf.printf
          " %f  %f  %f  %f\n \
            %f  %f  %f  %f\n \
            %f  %f  %f  %f\n \
            %f  %f  %f  %f\n%!" 
            m.(0).(0)  m.(0).(1)  m.(0).(2)  m.(0).(3)
            m.(1).(0)  m.(1).(1)  m.(1).(2)  m.(1).(3)
            m.(2).(0)  m.(2).(1)  m.(2).(2)  m.(2).(3)
            m.(3).(0)  m.(3).(1)  m.(3).(2)  m.(3).(3);
        ) mats;
      *)
  | '\027'
  | 'q' -> exit(0)
  | _ -> ()
;;
(* }}} *)
(* {{{ callback mouse *)

let mouse ~button ~state ~x ~y =
  match button, state with
  (* if we press the left button *)
  | GLUT_LEFT_BUTTON, GLUT_DOWN ->
      b_down := true;
      xold := x;  (* save mouse position *)
      yold := y;
  (* if we release the left button *)
  | GLUT_LEFT_BUTTON, GLUT_UP ->
      b_down := false;
  | _ -> ()
;;
(* }}} *)
(* {{{ callback motion *)

let motion ~x ~y =
  if !b_down then  (* if the left button is down *)
  begin
 (* change the rotation angles according to the last position
    of the mouse and the new one *)
    anglex := !anglex + (!xold - x);
    angley := !angley + (!yold - y);
    glutPostRedisplay();
  end;
  
  xold := x;
  yold := y;
;;
(* }}} *)
(* {{{ callback special *)

let special ~key ~x ~y =
  match key with
  | GLUT_KEY_UP   -> slide_ud := !slide_ud +. 1.0;  glutPostRedisplay();
  | GLUT_KEY_DOWN -> slide_ud := !slide_ud -. 1.0;  glutPostRedisplay();
  | GLUT_KEY_LEFT  -> slide_lr := !slide_lr -. 1.0; glutPostRedisplay();
  | GLUT_KEY_RIGHT -> slide_lr := !slide_lr +. 1.0; glutPostRedisplay();
  | _ -> ()
;;
(* }}} *)
(* {{{ main init of GL & Glut *)

let () =
  ignore(glutInit Sys.argv);

  glutInitDisplayMode[GLUT_RGBA; GLUT_DOUBLE; GLUT_DEPTH];
  glutInitWindowPosition ~x:200 ~y:200;
  (*
  glutInitWindowSize ~width:640 ~height:480;
  *)
  glutInitWindowSize ~width:800 ~height:600;

  ignore(glutCreateWindow ~title:"demo");

  glPointSize ~size:2.0;
  (*
  glClearColor ~r:0.3 ~g:0.3 ~b:0.3 ~a:0.0;
  *)
  glClearColor ~r:0.0 ~g:0.0 ~b:1.0 ~a:0.0;

  (* init openGL *)
  glEnable GL_DEPTH_TEST;

  list_id := glGenLists 1;

  (* callback functions *)
  glutDisplayFunc ~display;
  glutReshapeFunc ~reshape;
  glutKeyboardFunc ~keyboard;
  glutSpecialFunc ~special;
  glutMouseFunc ~mouse;
  glutMotionFunc ~motion;

  (* enter the main loop *)
  glutMainLoop();
;;
(* }}} *)

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
