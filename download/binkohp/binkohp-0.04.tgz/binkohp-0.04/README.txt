
Binkohp is a little game inspired by the Mah-jong and extended to 3D.
It is released under the GPL license.

Binkohp needs this openGL bindings:
  http://www.linux-nantes.org/~fmonnier/OCaml/GL/
which can be downloaded and compiled localy with the ./configure.sh
script.

The cells have to be removed by pairs with left clic.
And 2 cells can only be removed along the same axis (if 2 cells
are on the opposite of the cube they can't be removed).
Turn arround the cube with the right clic.

  -w 1024x768  : to set the window size
  -s 8         : make a cube with side 8 cells

Press 'p' to put the game in pause.

Press 's' to restart the game.

Press "space" to unselect all unwanted selected cells.

The time spent (in seconds) is displayed in the upper left corner.
When the game is finished the score is printed in the console.

Suggestions and Comments are wellcome, write to:
  <fmonnier () linux-nantes.org>

