cd `dirname $0`
make binkohp.jpg

ocaml -I ../SRC \
   GL.cma Glu.cma Glut.cma \
   jpeg_loader.cma \
   bigarray.cma \
   binkohp.ml $@ | tee -a scores.log

