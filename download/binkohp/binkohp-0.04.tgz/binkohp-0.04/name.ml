#!/usr/bin/env ocaml

let () =
  let str = "binkohp" in

  let off =
    "\001\002\000\003\005\006\004"
  in

  let out = String.copy str in
  for i = 0 to pred (String.length str) do
    let c = int_of_char (str.[i]) in
    let c = char_of_int (pred c) in
    let offset = int_of_char off.[i] in
    out.[offset] <- c;
  done;
  print_endline out;
;;

(* vim: sw=2 sts=2 ts=2 et
 *)
