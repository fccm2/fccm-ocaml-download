TARBALL="glMLite-0.03.51.tgz"
GLMLITE="http://www.linux-nantes.org/~fmonnier/OCaml/GL/download/$TARBALL"

DIR="`basename $TARBALL .tgz`"

#if [ ! -d `ocamlc -where`/glMLite ]
if [ "1" ]
then
	wget $GLMLITE
	tar xzf $TARBALL
	pushd $DIR
	make core jpeg
	popd
	sed -i Makefile -e "s:GL_DIR=+glMLite:GL_DIR=$DIR/SRC/:"
else
	sed -i Makefile -e "s:GL_DIR=$DIR/SRC/:GL_DIR=+glMLite:"
fi

