(* {{{ COPYING *(

  Little game inspired by Mah-jong and extended to 3D.

  Copyright (C) 2008  Florent Monnier
  Contact:  <fmonnier () linux-nantes.org>

  This program is free software: you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, either version 3
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>

)* }}} *)
open GL
open Glu
open Glut

(* {{{ default values *)

(* default dimentions and texture *)
let width, height = 800, 600
let skin = "binkohp.jpg"

(* number of pieces on the side of the cube *)
let side = 6

(* }}} *)
(* {{{ parse command line arguments *)

let parse_args =
  let argc = Array.length Sys.argv in
  let rec aux i (w,h) s t =
    if i >= argc then (w,h,s,t) else
      match Sys.argv.(i) with
      | "--size" | "-size" | "-s" ->
          let s = int_of_string Sys.argv.(i+1) in
          aux (i+2) (w,h) s t

      | "--window" | "-win" | "-w" ->
          let w,h =
            Scanf.sscanf Sys.argv.(i+1) "%dx%d" (fun w h -> (w,h))
          in
          aux (i+2) (w,h) s t

      | "--texture" | "-texture" | "-t" ->
          let t = Sys.argv.(i+1) in
          aux (i+2) (w,h) s t

      | _ ->
          aux (succ i) (w,h) s t
  in
  aux 0
;;

let width, height, side, skin = parse_args (width, height) side skin ;;

(* }}} *)
(* {{{ global vars *)

let ref_time = ref 0
let b_down = ref false
let anglex = ref 0
let angley = ref 0
let xold = ref 0
let yold = ref 0
let pause = ref false
let pause_time = ref 0

(* }}} *)
(* {{{ game matrices *)

(* matrix containing the cell kinds *)
let mat =
  Bigarray.Array3.create
      Bigarray.int8_unsigned Bigarray.c_layout
      side side side
;;

(* matrix containing selected and removed cells *)
(* 0: initial;  1: selected;  2: removed *)
let sel =
  Bigarray.Array3.create
      Bigarray.int8_unsigned Bigarray.c_layout
      side side side
;;

let unselect() =
  for i=0 to pred side do
    for j=0 to pred side do
      for k=0 to pred side do
        if sel.{i,j,k} = 1 then
          sel.{i,j,k} <- 0;
      done;
    done;
  done;
;;

(* depth of each cell, used for picking (selection) *)
let dep =
  Bigarray.Array3.create
      Bigarray.float32 Bigarray.c_layout
      side side side
;;

let odd =
  if (side land 1) = 1 then true else false
;;

(* cells are removed by pair, so the total has to be even *)
let total =
  let t = side * side * side in
  if odd then pred t else t
;;


let get_cells () =
  Random.self_init ();
  let cells = Array.make total 0 in
  let b = Random.int (8 * 8) in
  for i=0 to pred(total/2) do
    let j = i + (total/2) in
    let cel = (i+b) mod (8 * 8) in
    (* add a pair of cell *)
    cells.(i) <- cel;
    cells.(j) <- cel;
  done;
  (* shuffle the cells *)
  let bound = 1001 in
  Array.sort (fun _ _ -> (Random.int bound) - (bound/2)) cells;
  (cells)
;;

let init_mat () =
  let m = side / 2 in  (* middle *)

  let cells = get_cells() in
  let off = ref 0 in

  for i=0 to pred side do
    for j=0 to pred side do
      for k=0 to pred side do
        if odd && i=m && j=m && k=m then
          (* do not fill the center of the cube for odds *)
          ()
        else begin
          let c = cells.(!off) in
          mat.{i,j,k} <- c;
          incr off;
        end;
      done;
    done;
  done;
;;


let init_sel () =
  let m = side / 2 in  (* middle *)
  for i=0 to pred side do
    for j=0 to pred side do
      for k=0 to pred side do
        if odd && i=m && j=m && k=m then
          (* make the center of the cube empty for odds *)
          sel.{i,j,k} <- 2
        else
          sel.{i,j,k} <- 0;
      done;
    done;
  done;
;;

let get_selected () =
  let num = ref 0
  and acc = ref [] in
  for i=0 to pred side do
    for j=0 to pred side do
      for k=0 to pred side do
        if sel.{i,j,k} = 1 then begin
          incr num;
          acc := (i,j,k) :: !acc;
        end;
      done;
    done;
  done;
  (!num, !acc)
;;

let is_a_pair = function
  | (x1,y1,z1)::(x2,y2,z2)::[] ->
      (mat.{x1,y1,z1} = mat.{x2,y2,z2})
  | _ ->
      invalid_arg "is_a_pair"
;;

let sel_remove () =
  for i=0 to pred side do
    for j=0 to pred side do
      for k=0 to pred side do
        if sel.{i,j,k} = 1 then
          sel.{i,j,k} <- 2;
      done;
    done;
  done;
;;

let game_done () =
  try
    for i=0 to pred side do
      for j=0 to pred side do
        for k=0 to pred side do
          if sel.{i,j,k} <> 2 then
            raise Exit
        done;
      done;
    done;
    (true)
  with Exit ->
    (false)
;;

(* {{{ axis selection *)

let neg_x (x,y,z) =
  let rec aux x =
    if x <= 0 then true else
      if sel.{x-1,y,z} <> 2
      then false
      else aux (x-1)
  in
  aux x
;;

let neg_y (x,y,z) =
  let rec aux y =
    if y <= 0 then true else
      if sel.{x,y-1,z} <> 2
      then false
      else aux (y-1)
  in
  aux y
;;

let neg_z (x,y,z) =
  let rec aux z =
    if z <= 0 then true else
      if sel.{x,y,z-1} <> 2
      then false
      else aux (z-1)
  in
  aux z
;;

let pos_x (x,y,z) =
  let rec aux x =
    if x >= pred side then true else
      if sel.{x+1,y,z} <> 2
      then false
      else aux (x+1)
  in
  aux x
;;

let pos_y (x,y,z) =
  let rec aux y =
    if y >= pred side then true else
      if sel.{x,y+1,z} <> 2
      then false
      else aux (y+1)
  in
  aux y
;;

let pos_z (x,y,z) =
  let rec aux z =
    if z >= pred side then true else
      if sel.{x,y,z+1} <> 2
      then false
      else aux (z+1)
  in
  aux z
;;

(* check if the 2 cells can be removed
   along the same axis *)

let same_axis c1 c2 =
  (neg_x c1 && neg_x c2) ||
  (neg_y c1 && neg_y c2) ||
  (neg_z c1 && neg_z c2) ||
  (pos_x c1 && pos_x c2) ||
  (pos_y c1 && pos_y c2) ||
  (pos_z c1 && pos_z c2)
;;

let same_axis = function
  | c1::c2::[] -> same_axis c1 c2;
  | _ -> invalid_arg "same_axis"
;;

(* }}} *)

(* }}} *)
(* {{{ draw cube *)

let draw_cube ~dim ~x ~y ~selected =
  let x1 = (float x) *. 0.125
  and y1 = (float y) *. 0.125 in
  let x2 = x1 +. 0.125
  and y2 = y1 +. 0.125 in

  let min = -. dim and max = dim in

  if selected then
    let r, g, b = (0.7, 0.8, 0.9) in
    glColor3 r g b
  else
    glColor3 1. 1. 1.;

  if !pause then
    glColor3 0.8 0.8 0.8;

  glBegin GL_QUADS;
    glTexCoord2 x1 y1;   glVertex3 min max max;
    glTexCoord2 x1 y2;   glVertex3 min min max;
    glTexCoord2 x2 y2;   glVertex3 max min max;
    glTexCoord2 x2 y1;   glVertex3 max max max;

    glTexCoord2 x1 y1;   glVertex3 max max max;
    glTexCoord2 x1 y2;   glVertex3 max min max;
    glTexCoord2 x2 y2;   glVertex3 max min min;
    glTexCoord2 x2 y1;   glVertex3 max max min;

    glTexCoord2 x1 y1;   glVertex3 max max min;
    glTexCoord2 x1 y2;   glVertex3 max min min;
    glTexCoord2 x2 y2;   glVertex3 min min min;
    glTexCoord2 x2 y1;   glVertex3 min max min;

    glTexCoord2 x1 y1;   glVertex3 min max min;
    glTexCoord2 x1 y2;   glVertex3 min min min;
    glTexCoord2 x2 y2;   glVertex3 min min max;
    glTexCoord2 x2 y1;   glVertex3 min max max;

    glTexCoord2 x1 y1;   glVertex3 min max min;
    glTexCoord2 x1 y2;   glVertex3 min max max;
    glTexCoord2 x2 y2;   glVertex3 max max max;
    glTexCoord2 x2 y1;   glVertex3 max max min;

    glTexCoord2 x2 y1;   glVertex3 max min max;
    glTexCoord2 x1 y1;   glVertex3 min min max;
    glTexCoord2 x1 y2;   glVertex3 min min min;
    glTexCoord2 x2 y2;   glVertex3 max min min;
  glEnd();
;;

(* }}} *)
(* {{{ callback display *)

(* {{{ display text *)

let display_text ~x ~y ~z ~txt =
  (* GLUT_BITMAP_9_BY_15
     GLUT_BITMAP_8_BY_13
     GLUT_BITMAP_TIMES_ROMAN_10
     GLUT_BITMAP_TIMES_ROMAN_24
     GLUT_BITMAP_HELVETICA_10
     GLUT_BITMAP_HELVETICA_12
     GLUT_BITMAP_HELVETICA_18 *)
  let f = GLUT_BITMAP_9_BY_15 in

  let restore = [] in
  let restore =
    if (glIsEnabled Enabled.GL_DEPTH_TEST)
    then (fun () -> glEnable GL_DEPTH_TEST) :: restore
    else restore
  in
  let restore =
    if (glIsEnabled Enabled.GL_TEXTURE_2D)
    then (fun () -> glEnable GL_TEXTURE_2D) :: restore
    else restore
  in

  (*
  glDisable GL_DEPTH_TEST;
  *)
  glDisable GL_TEXTURE_2D;
  glColor3 0.0 0.0 0.0;

  glRasterPos3 x y z;

  glPushMatrix ();
    glLoadIdentity ();

    for i=0 to pred(String.length txt)
    do
      glutBitmapCharacter f txt.[i];
    done;

  glPopMatrix ();

  List.iter (function f -> f ()) restore;
;;

(* }}} *)

let draw_game ~mode =
  glLoadIdentity();

  gluLookAt 0.0 0.0 2.5  0.0 0.0 0.0  0.0 1.0 0.0;

  let time =
    if !pause
    then (!pause_time - !ref_time) / 1000
    else ((glutGet GLUT_ELAPSED_TIME) - !ref_time) / 1000
  in
  display_text (-0.75) (0.55) (0.2) (Printf.sprintf "time %d" time);

  let s = 0.8 /. (float side) in
  glScale s s s;

  glRotate (float !angley) 1.0 0.0 0.0;
  glRotate (float !anglex) 0.0 1.0 0.0;

  let b = float (side - 1) /. 2. in

  (*
  let mode = GL_SELECT in
  *)

  for i=0 to pred side do
    if mode = GL_SELECT then glLoadName i;
    for j=0 to pred side do
      if mode = GL_SELECT then glPushName j;
      for k=0 to pred side do
        if mode = GL_SELECT then glPushName k;

        glPushMatrix ();
          glTranslate ((float i) -. b)
                      ((float j) -. b)
                      ((float k) -. b);

          let m = glGetMatrix Get.GL_MODELVIEW_MATRIX in
          let z = m.(3).(2) in
          dep.{i,j,k} <- z;

          let off_id = mat.{i,j,k} in
          let x = off_id / 8
          and y = off_id mod 8
          in
          let selected =
            if sel.{i,j,k} = 0 then false else true
          in
          let hidden =
            if sel.{i,j,k} = 2 then true else false
          in
          if not hidden then
            draw_cube ~dim:0.4 ~x ~y ~selected;
        glPopMatrix();
        if mode = GL_SELECT then glPopName();
      done;
      if mode = GL_SELECT then glPopName();
    done;
  done;
;;

let display() =
  glClear [GL_COLOR_BUFFER_BIT; GL_DEPTH_BUFFER_BIT];
  draw_game GL_RENDER;
  glFlush();
  glutSwapBuffers();
;;

(* }}} *)
(* {{{ callback keyboard *)

let restart_game () =
  init_sel ();
  init_mat ();
  anglex := 0;
  angley := 0;
  ref_time := glutGet GLUT_ELAPSED_TIME;
;;

let keyboard ~key ~x ~y =
  match key with
  | 'l' ->
      glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MAG_FILTER Mag.GL_LINEAR);
      glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MIN_FILTER Min.GL_LINEAR);
      glutPostRedisplay ();
  | 'n' ->
      glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MAG_FILTER Mag.GL_NEAREST);
      glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MIN_FILTER Min.GL_NEAREST);
      glutPostRedisplay ();

  | 's' ->
      restart_game ();
      glutPostRedisplay ();

  | ' ' ->
      unselect ();
      glutPostRedisplay ();

  | 'P' | 'p' ->
      if !pause then begin
        pause := false;
        glEnable GL_TEXTURE_2D;
        let this_time = glutGet GLUT_ELAPSED_TIME in
        let diff_time = this_time - !pause_time in
        ref_time := !ref_time + diff_time;
      end else begin
        pause := true;
        glDisable GL_TEXTURE_2D;
        pause_time := glutGet GLUT_ELAPSED_TIME;
      end;
      glutPostRedisplay ();

  | '\027'
  | 'Q' | 'q' -> exit(0)
  | _ ->
      glutPostRedisplay ();
;;

(* }}} *)
(* {{{ process hits *)

let process_hits ~hits ~buffer =

  let select_buffer_get ar i =
    let res = Bigarray.Array1.get ar i in
    assert(res >= 0n);
    (Nativeint.to_int res)
  in
  let c = ref 0 in

  let sli = ref [] in

  (*  for each hit  *)
  for i = 0 to pred hits do
    let names = select_buffer_get buffer !c in
    incr c;
    incr c;  (* z1 *)
    incr c;  (* z2 *)
    let arn = Array.make names 0 in
    for j = 0 to pred names do
      let name = select_buffer_get buffer !c in
      arn.(j) <- name;
      incr c;
    done;
    begin
      let xyz = arn.(0), arn.(1), arn.(2) in
      sli := xyz :: !sli;
    end;
  done;

  match !sli with [] -> ()
  | hd::tl ->
      (* get only the nearest *)
      let (x,y,z) =
        let sort (x1,y1,z1) (x2,y2,z2) =
          let depth1 = dep.{x1,y1,z1}
          and depth2 = dep.{x2,y2,z2} in
          if depth1 > depth2
          then (x1,y1,z1)
          else (x2,y2,z2)
        in
        List.fold_left sort hd tl
      in
      begin match sel.{x,y,z} with
        | 0 -> sel.{x,y,z} <- 1
        | 1 -> sel.{x,y,z} <- 0
        | _ -> ()
      end;
      let num_sel, sels = get_selected() in
      if num_sel = 2 && is_a_pair sels && same_axis sels then
        begin
          sel_remove();
          if game_done() then begin
            (* let time = !time in *)
            let secs = float ((glutGet GLUT_ELAPSED_TIME) - !ref_time) /. 1000. in
            let mins = (truncate secs) / 60 in
            let _secs = secs -. (float(mins*60)) in
            if mins = 0 then
              Printf.printf " [side %d] time done: %4.1f seconds\n%!" side secs
            else
              Printf.printf " [side %d] time done: %2d minutes %04.1f seconds\n%!" side mins _secs;
            restart_game();
          end;
        end;
;;

(* }}} *)
(* {{{ callback mouse *)

let mouse ~button ~state ~x ~y =
  begin
    match button, state with
    | GLUT_RIGHT_BUTTON, GLUT_DOWN
    | GLUT_MIDDLE_BUTTON, GLUT_DOWN ->
        b_down := true;
        xold := x;  (* save mouse position *)
        yold := y;

    | GLUT_RIGHT_BUTTON, GLUT_UP
    | GLUT_MIDDLE_BUTTON, GLUT_UP ->
        b_down := false;

    | GLUT_LEFT_BUTTON, GLUT_DOWN ->
        if not(!pause) then begin
          let buffer_size = 4096 in
          let new_select_buffer =
            Bigarray.Array1.create Bigarray.nativeint Bigarray.c_layout
          in
          let select_buffer = new_select_buffer buffer_size in

          let (viewport_x,
               viewport_y,
               viewport_w,
               viewport_h) as viewport = glGetInteger4 Get.GL_VIEWPORT in

          glSelectBufferBA select_buffer;
          ignore(glRenderMode GL_SELECT);

          glInitNames ();
          glPushName 0;

          glMatrixMode GL_PROJECTION;
          glPushMatrix();
          glLoadIdentity();
          (* create a pixel picking region near cursor location *)
          gluPickMatrix (float x) (float(viewport_h - y)) 1.0 1.0 viewport;

          gluPerspective 30.0 ( (float(viewport_w - viewport_x)) /. 
                                (float(viewport_h - viewport_y)) ) 0.02 80.0;

          glMatrixMode GL_MODELVIEW;

            draw_game GL_SELECT;

          glMatrixMode GL_PROJECTION;
          glPopMatrix ();
          glMatrixMode GL_MODELVIEW;

          let hits = glRenderMode GL_RENDER in

            process_hits ~hits ~buffer:select_buffer;
          glutPostRedisplay ();
        end;

    | _ -> ()
  end;
;;

(* }}} *)
(* {{{ callback motion *)

let motion ~x ~y =
  if !b_down && not(!pause) then  (* if the left button is down *)
  begin
 (* change the rotation angles according to the last position
    of the mouse and the new one *)
    anglex := !anglex + (x - !xold); 
    angley := !angley + (y - !yold);
    if !angley > 95 then angley := 95;
    if !angley < -95 then angley := -95;
    glutPostRedisplay ();
  end;
  
  xold := x;
  yold := y;
;;
(* }}} *)
(* {{{ callback reshape *)

let reshape ~width:w ~height:h =
  glViewport 0 0 w h;
  glMatrixMode GL_PROJECTION;
  glLoadIdentity ();
  gluPerspective 30.0 ((float w) /. (float h)) 0.02 80.0;
  glMatrixMode GL_MODELVIEW;
;;

(* }}} *)
(* {{{ callback timer *)

let rec timer ~value =
  (* redisplay to actualise the time display *)
  glutPostRedisplay();
  glutTimerFunc ~msecs:1000 ~timer ~value:();
;;

(* }}} *)
(* {{{ load texture *)

let load_texture ~filename =
  let texture, width, height, internal_format, pixel_data_format =
    Jpeg_loader.load_img (Filename filename)
  in

  let texid = glGenTexture () in
  glBindTexture BindTex.GL_TEXTURE_2D texid;

  (* Parameters for applying the textures *)
  glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MAG_FILTER Mag.GL_LINEAR);
  glTexParameter TexParam.GL_TEXTURE_2D (TexParam.GL_TEXTURE_MIN_FILTER Min.GL_LINEAR);
  glTexImage2D
    ~target:TexTarget.GL_TEXTURE_2D
    ~level:0
    ~internal_format
    ~width
    ~height
    ~format_:pixel_data_format
    ~type_:GL_UNSIGNED_BYTE
    ~pixels:texture
  ;
  glEnable GL_TEXTURE_2D;
;;

(* }}} *)
(* {{{ main *)

let () =
  init_sel ();
  init_mat ();

  (* create the OpenGL window *)
  ignore(glutInit Sys.argv);
  glutInitDisplayMode [GLUT_RGB; GLUT_DOUBLE; GLUT_DEPTH];
  glutInitWindowSize ~width  ~height;
  ignore(glutCreateWindow ~title:"Binkohp");

  load_texture ~filename:skin;

  (* initialise OpenGL *)
  glClearColor ~r:0.7 ~g:0.7 ~b:0.7 ~a:0.0;
  glShadeModel GL_FLAT;
  glEnable GL_DEPTH_TEST;
  glEnable GL_CULL_FACE;

  (* Glut callback functions *)
  glutDisplayFunc ~display;
  glutKeyboardFunc ~keyboard;
  glutMouseFunc ~mouse;
  glutMotionFunc ~motion;
  glutReshapeFunc ~reshape;
  glutTimerFunc ~msecs:1000 ~timer ~value:();

  glutMainLoop ();
;;
(* }}} *)

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
