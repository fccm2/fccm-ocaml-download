(* {{{ COPYING *)
(*
 * +-----------------------------------------------------------------+
 * | Copyright (C) 2006  Florent Monnier                             |
 * +-----------------------------------------------------------------+
 * | This wraper is an attempt of a Ming binding for Objective Caml. |
 * +-----------------------------------------------------------------+
 * |                                                                 |
 * | This program is free software; you can ristribute it and/or   |
 * | modify it under the terms of the GNU General Public License     |
 * | as published by the Free Software Foundation; either version 2  |
 * | of the License, or (at your option) any later version.          |
 * |                                                                 |
 * | This program is distributed in the hope that it will be useful, |
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
 * | GNU General Public License for more details.                    |
 * |                                                                 |
 * | http://www.fsf.org/licensing/licenses/gpl.html                  |
 * |                                                                 |
 * | You should have received a copy of the GNU General Public       |
 * | License along with this program; if not,                        |
 * | write to the Free Software Foundation, Inc.,                    |
 * | 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA    |
 * |                                                                 |
 * +-----------------------------------------------------------------+
 * | Author: Florent Monnier <fmonnier@linux-nantes.fr.eu.org>       |
 * +-----------------------------------------------------------------+
 *
 * $Id$
 * }}} *)

(*  Ming  *)
(* {{{ doc *(

  http://ming.sourceforge.net/examples/

)* }}} *)

(* {{{ module Ming *)

module Ming = struct

external init: unit -> int = "ml_ming_init"
external cleanup: unit -> unit = "ml_ming_cleanup"
external collect_garbage: unit -> unit = "ml_ming_collectgarbage"
external set_cubic_threshold: num:int -> unit = "ml_ming_setcubicthreshold"

external set_scale: scale:float -> unit = "ml_ming_setscale"
external get_scale: unit -> float = "ml_ming_getscale"
external use_swf_version: version:int -> unit = "ml_ming_useswfversion"
external set_swf_compression: level:int -> int = "ml_ming_setswfcompression"

end

let get_content_type () = "Content-type: application/x-shockwave-flash"

(* Ming  }}} *)
(* {{{ module Input *)

type input

module Input = struct

external new_from_file: filename:string -> modes:string -> input = "ml_newswfinput_file"
external destroy: input:input -> unit = "ml_destroyswfinput"
external get_length: input:input -> int = "ml_swfinput_length"

end (* Input  }}} *)
(* {{{ module Character *)

type character
(* a character is any sort of asset that's referenced later-
   SWFBitmap, SWFShape, SWFMorph, SWFSound, SWFSprite are all SWFCharacters *)


module Character = struct

external get_width:  character -> float = "ml_swfcharacter_getwidth"
external get_height: character -> float = "ml_swfcharacter_getheight"

end

(* {{{ cast from and to character *)

type bitmap
type shape
type morph
type sound
type sprite


external bitmap_of_character: character -> bitmap = "ml_id"
external  shape_of_character: character -> shape  = "ml_id"
external  morph_of_character: character -> morph  = "ml_id"
external  sound_of_character: character -> sound  = "ml_id"
external sprite_of_character: character -> sprite = "ml_id"


external character_of_bitmap: bitmap -> character = "ml_id"
external character_of_shape:  shape  -> character = "ml_id"
external character_of_morph:  morph  -> character = "ml_id"
external character_of_sound:  sound  -> character = "ml_id"
external character_of_sprite: sprite -> character = "ml_id"

(* }}} *)

(* Character  }}} *)
(* {{{ module Bitmap *)

module Bitmap = struct

external new_from_input: input:input -> bitmap = "ml_newswfbitmap_frominput"
external destroy: bitmap:bitmap -> unit = "ml_destroyswfbitmap"
external get_width:  bitmap:bitmap -> int = "ml_swfbitmap_getwidth"
external get_height: bitmap:bitmap -> int = "ml_swfbitmap_getheight"

end (* Bitmap  }}} *)
(* {{{ module JpegBitmap *)

type jpeg_bitmap

module JpegBitmap = struct

external new_from_file: filename:string -> modes:string -> jpeg_bitmap = "ml_newswfjpegbitmap"

end (* JpegBitmap  }}} *)
(* {{{ module Gradient *)

type gradient

module Gradient = struct

external new_gradient: unit -> gradient = "ml_newswfgradient"
external destroy: gradient:gradient -> unit = "ml_destroyswfgradient"
external add_entry: gradient:gradient -> ratio:float ->
               r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfgradient_addentry_bytecode"
    "ml_swfgradient_addentry_native"

end (* Gradient  }}} *)
(* {{{ module FillStyle *)

type fill_style

module FillStyle = struct

external new_solid: r:int -> g:int -> b:int -> a:int -> fill_style = "ml_newswfsolidfillstyle"

end (* FillStyle  }}} *)
(* {{{ module LineStyle *)

type line_style

module LineStyle = struct

external new_line_style: width:int ->
              r:int -> g:int -> b:int -> a:int -> line_style
              = "ml_newswflinestyle"

end (* LineStyle  }}} *)
(* {{{ module Shape *)

type fill
type font

module Shape = struct


external new_shape: unit -> shape = "ml_newswfshape"
external destroy: shape:shape -> unit = "ml_destroyswfshape"

external add_solid_fill: shape:shape ->
              r:int -> g:int -> b:int -> a:int -> fill = "ml_swfshape_addsolidfill"
external set_line: shape:shape -> width:int -> r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfshape_setline_bytecode"
    "ml_swfshape_setline_native"
external set_line_style: shape:shape -> width:int -> r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfshape_setlinestyle_bytecode"
    "ml_swfshape_setlinestyle_native"
external hide_line: shape:shape -> unit = "ml_swfshape_hideline"

external move_pen: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_movepen"
external move_pen_to: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_movepento"
external draw_line: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_drawline"
external draw_line_to: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_drawlineto"
external draw_curve: shape:shape -> controlx:float -> controly:float ->
                        anchorx:float -> anchory:float -> unit = "ml_swfshape_drawcurve"
external draw_curve_to: shape:shape -> controlx:float -> controly:float ->
                        anchorx:float -> anchory:float -> unit = "ml_swfshape_drawcurveto"
external draw_circle: shape:shape -> r:float -> unit = "ml_swfshape_drawcircle"
external draw_arc: shape:shape -> r:float -> start_angle:float -> end_angle:float -> unit = "ml_swfshape_drawarc"
external draw_glyph: shape:shape -> font:font -> c:char -> unit = "ml_swfshape_drawglyph"

external set_left_fill: shape:shape -> fill:fill -> unit = "ml_swfshape_setleftfill"
external set_right_fill: shape:shape -> fill:fill -> unit = "ml_swfshape_setrightfill"
external set_left_fill_style:  shape:shape -> fill_style:fill_style -> unit = "ml_swfshape_setleftfillstyle"
external set_right_fill_style: shape:shape -> fill_style:fill_style -> unit = "ml_swfshape_setrightfillstyle"

external add_linear_gradient_fill: shape:shape -> gradient:gradient -> fill = "ml_swfshape_addgradientfill_linear"
external add_radial_gradient_fill: shape:shape -> gradient:gradient -> fill = "ml_swfshape_addgradientfill_radial"


end (* Shape  }}} *)
(* {{{ module Morph *)

module Morph = struct

external new_morph: unit -> morph = "ml_newswfmorphshape"
external destroy: morph:morph -> unit = "ml_destroyswfmorph"
external get_shape1: morph:morph -> shape = "ml_swfmorph_getshape1"
external get_shape2: morph:morph -> shape = "ml_swfmorph_getshape2"

end (* Morph  }}} *)
(* {{{ module Font *)

module Font = struct

external new_font: unit -> font = "ml_newswffont"
external load_from_file: filename:string -> font = "ml_loadswffontfromfile"
external destroy: font:font -> unit = "ml_destroyswffont"
external get_string_width: font:font -> string:string -> float = "ml_swffont_getstringwidth"
external get_ascent:  font:font -> float = "ml_swffont_getascent"
external get_descent: font:font -> float = "ml_swffont_getdescent"
external get_leading: font:font -> float = "ml_swffont_getleading"

end (* Font  }}} *)
(* {{{ module Action *)

type action

module Action = struct

external compile_code: script:string -> action = "ml_compileswfactioncode"
external destroy: action:action -> unit = "ml_destroyswfaction"

end (* Action  }}} *)
(* {{{ module DisplayItem *)

type display_item

module DisplayItem = struct

external set_color_mult: display_item:display_item ->
            r:float -> g:float -> b:float -> a:float -> unit = "ml_swfdisplayitem_setcolormult"

external move: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_move"
external move_to: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_moveto"
external rotate: display_item:display_item -> degrees:float -> unit = "ml_swfdisplayitem_rotate"
external rotate_to: display_item:display_item -> degrees:float -> unit = "ml_swfdisplayitem_rotateto"
external scale: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_scale"
external scale_to: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_scaleto"
external skew_x: display_item:display_item -> x:float -> unit = "ml_swfdisplayitem_skewx"
external skew_x_to: display_item:display_item -> x:float -> unit = "ml_swfdisplayitem_skewxto"

external set_ratio: display_item:display_item -> ratio:float -> unit = "ml_swfdisplayitem_setratio"

end (* DisplayItem  }}} *)
(* {{{ module Fill *)

module Fill = struct

external new_fill: fill_style:fill_style -> fill = "ml_newswffill"
external destroy: fill:fill -> unit = "ml_destroyswffill"

external scale_xy_to: fill:fill -> x:float -> y:float -> unit = "ml_swffill_scalexyto"
external scale_xy: fill:fill -> x:float -> y:float -> unit = "ml_swffill_scalexy"
external scale_x_to: fill:fill -> x:float -> unit = "ml_swffill_scalexto"
external scale_x: fill:fill -> x:float -> unit = "ml_swffill_scalex"
external scale_y_to: fill:fill -> y:float -> unit = "ml_swffill_scaleyto"
external scale_y: fill:fill -> y:float -> unit = "ml_swffill_scaley"

external skew_x_to: fill:fill -> x:float -> unit = "ml_swffill_skewxto"
external skew_x: fill:fill -> x:float -> unit = "ml_swffill_skewx"
external skew_y_to: fill:fill -> y:float -> unit = "ml_swffill_skewyto"
external skew_y: fill:fill -> y:float -> unit = "ml_swffill_skewy"

external move_to: fill:fill -> x:float -> y:float -> unit = "ml_swffill_moveto"
external move: fill:fill -> x:float -> y:float -> unit = "ml_swffill_move"
external rotate_to: fill:fill -> degrees:float -> unit = "ml_swffill_rotateto"
external rotate: fill:fill -> degrees:float -> unit = "ml_swffill_rotate"

end (* Fill  }}} *)
(* {{{ module MovieClip *)

type movie_clip
type block

external block_of_shape: shape:shape -> block = "ml_id"
external block_of_morph: morph:morph -> block = "ml_id"


module MovieClip = struct


external new_movie_clip: unit -> movie_clip = "ml_newswfmovieclip"
external destroy: movie_clip:movie_clip -> unit = "ml_destroyswfmovieclip"
external add: movie_clip:movie_clip -> block:block -> display_item = "ml_swfmovieclip_add"
external next_frame: movie_clip:movie_clip -> unit = "ml_swfmovieclip_nextframe"


end (* MovieClip  }}} *)
(* {{{ module Movie *)

type movie

external block_of_movie_clip: movie_clip:movie_clip -> block = "ml_id"


module Movie = struct

external new_movie: unit -> movie = "ml_newswfmovie"
external destroy: movie:movie -> unit = "ml_destroyswfmovie"
external add: movie:movie -> block:block -> display_item = "ml_swfmovie_add"
external remove: movie:movie -> display_item:display_item -> unit = "ml_swfmovie_remove"
external set_background: movie:movie ->
                    r:int -> g:int -> b:int -> unit = "ml_swfmovie_setbackground"
external set_dimension: movie:movie -> x:float -> y:float -> unit = "ml_swfmovie_setdimension"
external save: movie:movie -> filename:string -> int = "ml_swfmovie_save"
external set_rate: movie:movie -> rate:float -> unit = "ml_swfmovie_setrate"
external next_frame: movie:movie -> unit = "ml_swfmovie_nextframe"


end (* Movie  }}} *)

(* {{{ module OO *)

module OO = struct

(* {{{ class swfFill *)

class swfFill ~fill =
  object
    (*
    val fill = Fill.new_fill ~fill_style
    *)
    val fill = fill
    method get_fill () = fill

    method scale_xy_to ~x ~y = Fill.scale_xy_to ~fill ~x ~y
    method scale_xy ~x ~y = Fill.scale_xy ~fill ~x ~y
    method scale_x_to ~x = Fill.scale_x_to ~fill ~x
    method scale_x ~x = Fill.scale_x ~fill ~x
    method scale_y_to ~y = Fill.scale_y_to ~fill ~y
    method scale_y ~y = Fill.scale_y ~fill ~y

    method scale_to ~scale = Fill.scale_xy_to ~fill ~x:scale ~y:scale
    method scale ~scale = Fill.scale_xy ~fill ~x:scale ~y:scale

    method skew_x_to ~x = Fill.skew_x_to ~fill ~x
    method skew_x ~x = Fill.skew_x ~fill ~x
    method skew_y_to ~y = Fill.skew_y_to ~fill ~y
    method skew_y ~y = Fill.skew_y ~fill ~y

    method move_to ~x ~y = Fill.move_to ~fill ~x ~y
    method move ~x ~y = Fill.move ~fill ~x ~y
    method rotate_to ~degrees = Fill.rotate_to ~fill ~degrees
    method rotate ~degrees = Fill.rotate ~fill ~degrees
  end

(* }}} *)
(* {{{ class swfGradient *)

class swfGradient =
  object
    val gradient = Gradient.new_gradient()
    method add_entry ~ratio ~r ~g ~b ~a =
      Gradient.add_entry ~gradient  ~ratio ~r ~g ~b ~a
    method get_gradient () = gradient
  end

(* }}} *)
(* {{{ class swfFont *)

class swfFont ~filename =
  object
    val font = Font.load_from_file ~filename
    method get_width ~string = Font.get_string_width ~font ~string
    method get_font () = font
    method get_ascent () = Font.get_ascent ~font
    method get_descent () = Font.get_descent ~font
    method get_leading () = Font.get_leading ~font
  end

(* }}} *)
(* {{{ class swfDisplayItem *)

class swfDisplayItem ~display_item =
  object
    val display_item = display_item

    method move ~x ~y = DisplayItem.move ~display_item ~x ~y
    method move_to ~x ~y = DisplayItem.move_to ~display_item ~x ~y
    method rotate ~degrees = DisplayItem.rotate ~display_item ~degrees
    method rotate_to ~degrees = DisplayItem.rotate_to ~display_item ~degrees
    method scale ~x ~y = DisplayItem.scale ~display_item ~x ~y
    method scale_to ~x ~y = DisplayItem.scale_to ~display_item ~x ~y
    method skew_x ~x = DisplayItem.skew_x ~display_item ~x
    method skew_x_to ~x = DisplayItem.skew_x_to ~display_item ~x
    method set_ratio ~ratio = DisplayItem.set_ratio ~display_item ~ratio
    method set_color_mult ~r ~g ~b ~a =
        DisplayItem.set_color_mult ~display_item ~r ~g ~b ~a
  end

(* }}} *)
(* {{{ class swfShape *)

class swfShape ?shape () =
  let shape = match shape with
    | Some shape -> shape
    | None -> Shape.new_shape()
  in
  object
    val shape = shape
    method get_shape () = shape
    method move_pen ~x ~y = Shape.move_pen ~shape ~x ~y
    method move_pen_to ~x ~y = Shape.move_pen_to ~shape ~x ~y
    method draw_line ~x ~y = Shape.draw_line ~shape ~x ~y
    method draw_line_to ~x ~y = Shape.draw_line_to ~shape ~x ~y
    method draw_curve ~controlx ~controly ~anchorx ~anchory =
      Shape.draw_curve ~shape  ~controlx ~controly ~anchorx ~anchory
    method draw_curve_to ~controlx ~controly ~anchorx ~anchory =
      Shape.draw_curve_to ~shape  ~controlx ~controly ~anchorx ~anchory
    method draw_circle ~r = Shape.draw_circle ~shape ~r
    method draw_arc ~r ~start_angle ~end_angle =
      Shape.draw_arc ~shape ~r ~start_angle ~end_angle

    method draw_glyph ~font:(f : swfFont) ~c =
      Shape.draw_glyph ~shape ~font:(f#get_font()) ~c

    method set_left_fill_style ~fill_style =
      Shape.set_left_fill_style ~shape ~fill_style
    method set_right_fill_style ~fill_style =
      Shape.set_right_fill_style ~shape ~fill_style
    method add_fill ~r ~g ~b ~a =
      let fill = Shape.add_solid_fill ~shape  ~r ~g ~b ~a in
      let fill_obj = new swfFill ~fill in
      (fill_obj)
    method add_solid_fill ~r ~g ~b ~a =
      let fill = Shape.add_solid_fill ~shape  ~r ~g ~b ~a in
      let fill_obj = new swfFill ~fill in
      (fill_obj)
    method add_linear_gradient_fill ~gradient:(g : swfGradient) =
      let fill =
        Shape.add_linear_gradient_fill ~shape ~gradient:(g#get_gradient())
      in
      let fill_obj = new swfFill ~fill in
      (fill_obj)
    method add_radial_gradient_fill ~gradient:(g : swfGradient) =
      let fill =
        Shape.add_radial_gradient_fill ~shape ~gradient:(g#get_gradient())
      in
      let fill_obj = new swfFill ~fill in
      (fill_obj)

    method set_left_fill ~fill:(f : swfFill) = Shape.set_left_fill ~shape ~fill:(f#get_fill())
    method set_right_fill ~fill:(f : swfFill) = Shape.set_right_fill ~shape ~fill:(f#get_fill())

    method set_line  ~width  ~r ~g ~b ~a =
      Shape.set_line ~shape  ~width ~r ~g ~b ~a
    method set_line_style  ~width  ~r ~g ~b ~a =
      Shape.set_line_style ~shape  ~width ~r ~g ~b ~a
    method hide_line () = Shape.hide_line ~shape
    method get_block () = block_of_shape ~shape
  end

(* }}} *)
(* {{{ class swfMorph *)

class swfMorph =
  object
    val morph = Morph.new_morph()
    method get_morph () = morph
    method get_shape1() =
      let shape = Morph.get_shape1 ~morph in
      new swfShape ~shape ()
    method get_shape2() =
      let shape = Morph.get_shape2 ~morph in
      new swfShape ~shape ()
  end

(* }}} *)
(* {{{ class swfMovie *)

type item = SWFShape of swfShape | SWFMorph of swfMorph


class swfMovie =
  object 
    val movie = Movie.new_movie()
    val mutable filesize = None
    method set_background ~r ~g ~b =
      Movie.set_background ~movie ~r ~g ~b
    method set_dimension ~x ~y = Movie.set_dimension ~movie ~x ~y
    method set_rate ~rate =
      Movie.set_rate ~movie ~rate
    method next_frame () =
      Movie.next_frame ~movie

    method add ~block =
      let block = match block with
        | SWFShape s -> block_of_shape ~shape:(s#get_shape())
        | SWFMorph m -> block_of_morph ~morph:(m#get_morph())
      in
      let display_item = Movie.add ~movie ~block in
      let obj_item = new swfDisplayItem ~display_item in
      (obj_item)

    method save ~filename =
      let saved = Movie.save ~movie ~filename in
      filesize <- Some saved

    method get_filesize() = filesize
  end

(* }}} *)

end (* OO  }}} *)
(*
(* {{{ module SWF *)

module SWF = struct


end (* SWF  }}} *)
*)
(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
