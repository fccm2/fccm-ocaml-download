(* {{{ COPYING *)
(*
 * +-----------------------------------------------------------------+
 * | Copyright (C) 2006  Florent Monnier                             |
 * +-----------------------------------------------------------------+
 * | This wraper is an attempt of a Ming binding for Objective Caml. |
 * +-----------------------------------------------------------------+
 * |                                                                 |
 * | This program is free software; you can ristribute it and/or   |
 * | modify it under the terms of the GNU General Public License     |
 * | as published by the Free Software Foundation; either version 2  |
 * | of the License, or (at your option) any later version.          |
 * |                                                                 |
 * | This program is distributed in the hope that it will be useful, |
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
 * | GNU General Public License for more details.                    |
 * |                                                                 |
 * | http://www.fsf.org/licensing/licenses/gpl.html                  |
 * |                                                                 |
 * | You should have received a copy of the GNU General Public       |
 * | License along with this program; if not,                        |
 * | write to the Free Software Foundation, Inc.,                    |
 * | 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA    |
 * |                                                                 |
 * +-----------------------------------------------------------------+
 * | Author: Florent Monnier <fmonnier@linux-nantes.fr.eu.org>       |
 * +-----------------------------------------------------------------+
 *
 *
 *  #================================================================#
 *  |      DOCUMENTATION    LICENCE                                  |
 *  +----------------------------------------------------------------+
 *  |  The documentations included in the doc-blocks have been taken |
 *  |  from the Ming section of the PHP documentation, which is      |
 *  |  released under the OPL licence, and available at:             |
 *  |  http://www.php.net/manual/en/ref.ming.php                     |
 *  +----------------------------------------------------------------+
 *  |  Copyright (C) 1997-2006 the PHP Documentation Group           |
 *  |                                                                |
 *  | This material may be distributed only subject to the terms and |
 *  | conditions set forth in the Open Publication License, v1.0 or  |
 *  | later (the latest version is presently available at:           |
 *  | http://www.opencontent.org/openpub/).                          |
 *  |                                                                |
 *  #================================================================#
 *
 *
 * $Id$
 * }}} *)

(** {3 Ming} *)
(* {{{ intro *)
(**
    The comments of this documentation have been taken from the
    {{:http://www.php.net/manual/en/ref.ming.php}Ming section of the PHP documentation},
    which is released under the
    {{:http://www.opencontent.org/openpub/}OPL licence}.

{ul
    {- {{:http://ming.sourceforge.net/examples/}ming exemples}}
}

*)
(* }}} *)

(* {{{ module Ming *)

(** Ming general functions *)
module Ming : sig

(** this module contains the general functions *)


external init: unit -> int = "ml_ming_init"
external cleanup: unit -> unit = "ml_ming_cleanup"
external collect_garbage: unit -> unit = "ml_ming_collectgarbage"
external set_cubic_threshold: num:int -> unit = "ml_ming_setcubicthreshold"
(** Sets the threshold error for drawing cubic beziers.  Lower is more
    accurate, hence larger file size. *)

external set_scale: scale:float -> unit = "ml_ming_setscale"
(** Sets the overall scale, default is 20. *)
external get_scale: unit -> float = "ml_ming_getscale"
external use_swf_version: version:int -> unit = "ml_ming_useswfversion"
(** Sets the version number to use. *)
external set_swf_compression: level:int -> int = "ml_ming_setswfcompression"
(** Sets output compression level. Returns previous value. *)


end

val get_content_type: unit -> string
(** provides the content-type string to use for CGIs. *)

(* Ming  }}} *)
(* {{{ module Input *)

type input

module Input : sig

external new_from_file: filename:string -> modes:string -> input = "ml_newswfinput_file"
external destroy: input:input -> unit = "ml_destroyswfinput"
external get_length: input:input -> int = "ml_swfinput_length"

end (* Input  }}} *)
(* {{{ module Character *)

type character
(** a [character] is any sort of asset that's referenced later-
    {!SWF.bitmap}, {!SWF.shape}, {!SWF.morph}, {!SWF.sound}, {!SWF.sprite}
    are all characters *)


module Character : sig

external get_width:  character -> float = "ml_swfcharacter_getwidth"
external get_height: character -> float = "ml_swfcharacter_getheight"

end


(* {{{ cast from and to character *)

type bitmap
type shape
type morph
type sound
type sprite


external bitmap_of_character: character -> bitmap = "ml_id"
external  shape_of_character: character -> shape  = "ml_id"
external  morph_of_character: character -> morph  = "ml_id"
external  sound_of_character: character -> sound  = "ml_id"
external sprite_of_character: character -> sprite = "ml_id"


external character_of_bitmap: bitmap -> character = "ml_id"
external character_of_shape:  shape  -> character = "ml_id"
external character_of_morph:  morph  -> character = "ml_id"
external character_of_sound:  sound  -> character = "ml_id"
external character_of_sprite: sprite -> character = "ml_id"

(* }}} *)


(* Character  }}} *)
(* {{{ module Bitmap *)

module Bitmap : sig

external new_from_input: input:input -> bitmap = "ml_newswfbitmap_frominput"
external destroy: bitmap:bitmap -> unit = "ml_destroyswfbitmap"
external get_width:  bitmap:bitmap -> int = "ml_swfbitmap_getwidth"
external get_height: bitmap:bitmap -> int = "ml_swfbitmap_getheight"

end (* Bitmap  }}} *)
(* {{{ module JpegBitmap *)

type jpeg_bitmap

module JpegBitmap : sig

external new_from_file: filename:string -> modes:string -> jpeg_bitmap = "ml_newswfjpegbitmap"

end (* JpegBitmap  }}} *)
(* {{{ module Gradient *)

type gradient

module Gradient : sig

external new_gradient: unit -> gradient = "ml_newswfgradient"
external destroy: gradient:gradient -> unit = "ml_destroyswfgradient"
external add_entry: gradient:gradient -> ratio:float ->
               r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfgradient_addentry_bytecode"
    "ml_swfgradient_addentry_native"
(** adds an entry to the gradient list. [ratio] is a number between 0 and 1
    indicating where in the gradient this color appears. *)

end (* Gradient  }}} *)
(* {{{ module FillStyle *)

type fill_style

module FillStyle : sig

external new_solid: r:int -> g:int -> b:int -> a:int -> fill_style = "ml_newswfsolidfillstyle"

end (* FillStyle  }}} *)
(* {{{ module LineStyle *)

type line_style

module LineStyle : sig

external new_line_style: width:int ->
              r:int -> g:int -> b:int -> a:int -> line_style
              = "ml_newswflinestyle"

end (* LineStyle  }}} *)
(* {{{ module Shape *)

type fill
type font

module Shape : sig


external new_shape: unit -> shape = "ml_newswfshape"
external destroy: shape:shape -> unit = "ml_destroyswfshape"

external add_solid_fill: shape:shape ->
                r:int -> g:int -> b:int -> a:int -> fill = "ml_swfshape_addsolidfill"
external set_line: shape:shape -> width:int ->
                r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfshape_setline_bytecode"
    "ml_swfshape_setline_native"
external set_line_style: shape:shape -> width:int ->
                r:int -> g:int -> b:int -> a:int -> unit
  = "ml_swfshape_setlinestyle_bytecode"
    "ml_swfshape_setlinestyle_native"
(** Sets the shape's line style. [width] is the line's width.
    If [width] is 0, the line's style is removed (then, all other arguments are ignor).
    If [width] > 0, then line's color is set to [r], [g], [b], [a]. *)
external hide_line: shape:shape -> unit = "ml_swfshape_hideline"

external move_pen: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_movepen"
external move_pen_to: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_movepento"
external draw_line: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_drawline"
external draw_line_to: shape:shape -> x:float -> y:float -> unit = "ml_swfshape_drawlineto"
external draw_curve: shape:shape -> controlx:float -> controly:float ->
                        anchorx:float -> anchory:float -> unit = "ml_swfshape_drawcurve"
(** Draws a quadratic curve (using the current line style, set by
    {!SWF.Shape.set_line}) from the current pen position to the relative position
    [(anchorx,anchory)] using relative control point [(controlx,controly)]. That is,
    head towards the control point, then smoothly turn to the anchor point. *)
external draw_curve_to: shape:shape -> controlx:float -> controly:float ->
                        anchorx:float -> anchory:float -> unit = "ml_swfshape_drawcurveto"
(* x,y relative to shape origin *)

external draw_circle: shape:shape -> r:float -> unit = "ml_swfshape_drawcircle"
external draw_arc: shape:shape -> r:float -> start_angle:float -> end_angle:float -> unit = "ml_swfshape_drawarc"
(** Draws an arc of radius [r] center at the current location, from angle
    [start_angle] to angle [end_angle] measur clockwise from 12 o'clock *)

external draw_glyph: shape:shape -> font:font -> c:char -> unit = "ml_swfshape_drawglyph"

external set_right_fill_style: shape:shape -> fill_style:fill_style -> unit = "ml_swfshape_setrightfillstyle"
external set_left_fill_style:  shape:shape -> fill_style:fill_style -> unit = "ml_swfshape_setleftfillstyle"

external set_right_fill: shape:shape -> fill:fill -> unit = "ml_swfshape_setrightfill"
external set_left_fill: shape:shape -> fill:fill -> unit = "ml_swfshape_setleftfill"
(** Sets the fill on the left side of the edge- that is, on the interior if
    you're defining the outline of the shape in a counter-clockwise fashion. *)

external add_linear_gradient_fill: shape:shape -> gradient:gradient -> fill = "ml_swfshape_addgradientfill_linear"
external add_radial_gradient_fill: shape:shape -> gradient:gradient -> fill = "ml_swfshape_addgradientfill_radial"


end (* Shape  }}} *)
(* {{{ module Morph *)

module Morph : sig

external new_morph: unit -> morph = "ml_newswfmorphshape"
external destroy: morph:morph -> unit = "ml_destroyswfmorph"
external get_shape1: morph:morph -> shape = "ml_swfmorph_getshape1"
(** gets a handle to the morph's starting shape *)
external get_shape2: morph:morph -> shape = "ml_swfmorph_getshape2"
(** gets a handle to the morph's ending shape *)

end (* Morph  }}} *)
(* {{{ module Font *)

module Font : sig

external new_font: unit -> font = "ml_newswffont"
external load_from_file: filename:string -> font = "ml_loadswffontfromfile"
external destroy: font:font -> unit = "ml_destroyswffont"
external get_string_width: font:font -> string:string -> float = "ml_swffont_getstringwidth"
external get_ascent:  font:font -> float = "ml_swffont_getascent"
external get_descent: font:font -> float = "ml_swffont_getdescent"
external get_leading: font:font -> float = "ml_swffont_getleading"

end (* Font  }}} *)
(* {{{ module Action *)

type action

module Action : sig

external compile_code: script:string -> action = "ml_compileswfactioncode"
external destroy: action:action -> unit = "ml_destroyswfaction"

end (* Action  }}} *)
(* {{{ module DisplayItem *)

type display_item

module DisplayItem : sig

external set_color_mult: display_item:display_item ->
            r:float -> g:float -> b:float -> a:float -> unit = "ml_swfdisplayitem_setcolormult"

external move: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_move"
external move_to: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_moveto"
external rotate: display_item:display_item -> degrees:float -> unit = "ml_swfdisplayitem_rotate"
external rotate_to: display_item:display_item -> degrees:float -> unit = "ml_swfdisplayitem_rotateto"
external scale: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_scale"
external scale_to: display_item:display_item -> x:float -> y:float -> unit = "ml_swfdisplayitem_scaleto"
external skew_x: display_item:display_item -> x:float -> unit = "ml_swfdisplayitem_skewx"
external skew_x_to: display_item:display_item -> x:float -> unit = "ml_swfdisplayitem_skewxto"

external set_ratio: display_item:display_item -> ratio:float -> unit = "ml_swfdisplayitem_setratio"

end (* DisplayItem  }}} *)
(* {{{ module Fill *)

module Fill : sig

external new_fill: fill_style:fill_style -> fill = "ml_newswffill"
external destroy: fill:fill -> unit = "ml_destroyswffill"

external scale_xy_to: fill:fill -> x:float -> y:float -> unit = "ml_swffill_scalexyto"
external scale_xy: fill:fill -> x:float -> y:float -> unit = "ml_swffill_scalexy"
external scale_x_to: fill:fill -> x:float -> unit = "ml_swffill_scalexto"
external scale_x: fill:fill -> x:float -> unit = "ml_swffill_scalex"
external scale_y_to: fill:fill -> y:float -> unit = "ml_swffill_scaleyto"
external scale_y: fill:fill -> y:float -> unit = "ml_swffill_scaley"

external skew_x_to: fill:fill -> x:float -> unit = "ml_swffill_skewxto"
external skew_x: fill:fill -> x:float -> unit = "ml_swffill_skewx"
external skew_y_to: fill:fill -> y:float -> unit = "ml_swffill_skewyto"
external skew_y: fill:fill -> y:float -> unit = "ml_swffill_skewy"

external move_to: fill:fill -> x:float -> y:float -> unit = "ml_swffill_moveto"
external move: fill:fill -> x:float -> y:float -> unit = "ml_swffill_move"
external rotate_to: fill:fill -> degrees:float -> unit = "ml_swffill_rotateto"
external rotate: fill:fill -> degrees:float -> unit = "ml_swffill_rotate"

end (* Fill  }}} *)
(* {{{ module MovieClip *)

type movie_clip
type block

external block_of_shape: shape:shape -> block = "ml_id"
external block_of_morph: morph:morph -> block = "ml_id"


module MovieClip : sig


external new_movie_clip: unit -> movie_clip = "ml_newswfmovieclip"
external destroy: movie_clip:movie_clip -> unit = "ml_destroyswfmovieclip"
external add: movie_clip:movie_clip -> block:block -> display_item = "ml_swfmovieclip_add"
external next_frame: movie_clip:movie_clip -> unit = "ml_swfmovieclip_nextframe"


end (* MovieClip  }}} *)
(* {{{ module Movie *)

type movie

external block_of_movie_clip: movie_clip:movie_clip -> block = "ml_id"


module Movie : sig

external new_movie: unit -> movie = "ml_newswfmovie"
external destroy: movie:movie -> unit = "ml_destroyswfmovie"
external add: movie:movie -> block:block -> display_item = "ml_swfmovie_add"
external remove: movie:movie -> display_item:display_item -> unit = "ml_swfmovie_remove"
external set_background: movie:movie ->
                    r:int -> g:int -> b:int -> unit = "ml_swfmovie_setbackground"
external set_dimension: movie:movie -> x:float -> y:float -> unit = "ml_swfmovie_setdimension"
external save: movie:movie -> filename:string -> int = "ml_swfmovie_save"
external set_rate: movie:movie -> rate:float -> unit = "ml_swfmovie_setrate"
external next_frame: movie:movie -> unit = "ml_swfmovie_nextframe"


end (* Movie  }}} *)

(* {{{ module OO *)

module OO : sig
(** This module is made to be an interface very close to the other Ming bindings
    like the PHP one for exemple. *)

(* {{{ class swfFill *)

class swfFill:
  fill:fill ->
  object
    val fill: fill
    method get_fill: unit -> fill

    method move: x:float -> y:float -> unit
    method move_to: x:float -> y:float -> unit
    method rotate: degrees:float -> unit
    method rotate_to: degrees:float -> unit

    method scale_x: x:float -> unit
    method scale_x_to: x:float -> unit
    method scale_y: y:float -> unit
    method scale_y_to: y:float -> unit
    method scale_xy: x:float -> y:float -> unit
    method scale_xy_to: x:float -> y:float -> unit
    method scale: scale:float -> unit
    method scale_to: scale:float -> unit

    method skew_x: x:float -> unit
    method skew_x_to: x:float -> unit
    method skew_y: y:float -> unit
    method skew_y_to: y:float -> unit
  end

(* }}} *)
(* {{{ class swfGradient *)

class swfGradient:
  object
    val gradient: gradient
    method add_entry:
      ratio:float -> r:int -> g:int -> b:int -> a:int -> unit
    (** {!SWF.Gradient.add_entry} *)
    method get_gradient: unit -> gradient
  end

(* }}} *)
(* {{{ class swfFont *)

class swfFont: filename:string ->
  object
    val font: font
    method get_width: string:string -> float
    method get_font: unit -> font
    method get_ascent:  unit -> float
    method get_descent: unit -> float
    method get_leading: unit -> float
  end

(* }}} *)
(* {{{ class swfDisplayItem *)

class swfDisplayItem:
  display_item:display_item ->
  object
    val display_item: display_item
    method move: x:float -> y:float -> unit
    method move_to: x:float -> y:float -> unit
    method rotate: degrees:float -> unit
    method rotate_to: degrees:float -> unit
    method scale: x:float -> y:float -> unit
    method scale_to: x:float -> y:float -> unit
    method set_color_mult: r:float -> g:float -> b:float -> a:float -> unit
    method set_ratio: ratio:float -> unit
    method skew_x: x:float -> unit
    method skew_x_to: x:float -> unit
  end

(* }}} *)
(* {{{ class swfShape *)

class swfShape: ?shape:shape -> unit ->
  object
    val shape: shape
    method get_shape: unit -> shape
    method add_fill:
                r:int -> g:int -> b:int -> a:int -> swfFill
    method add_solid_fill:
                r:int -> g:int -> b:int -> a:int -> swfFill
    method add_linear_gradient_fill: gradient:swfGradient -> swfFill
    method add_radial_gradient_fill: gradient:swfGradient -> swfFill
    method set_line: width:int ->
                r:int -> g:int -> b:int -> a:int -> unit
    method set_line_style: width:int ->
                r:int -> g:int -> b:int -> a:int -> unit
    method hide_line: unit -> unit
    method move_pen: x:float -> y:float -> unit
    method move_pen_to: x:float -> y:float -> unit
    method draw_line: x:float -> y:float -> unit
    method draw_line_to: x:float -> y:float -> unit
    method draw_curve: controlx:float -> controly:float ->
                anchorx:float -> anchory:float -> unit
    method draw_curve_to: controlx:float -> controly:float ->
                anchorx:float -> anchory:float -> unit
    method draw_circle: r:float -> unit
    method draw_arc: r:float -> start_angle:float -> end_angle:float -> unit
    method draw_glyph: font:swfFont -> c:char -> unit
    method set_left_fill: fill:swfFill -> unit
    method set_right_fill: fill:swfFill -> unit
    method set_left_fill_style: fill_style:fill_style -> unit
    method set_right_fill_style: fill_style:fill_style -> unit
    method get_block: unit -> block
  end

(* }}} *)
(* {{{ class swfMorph *)

class swfMorph:
  object
    val morph: morph
    method get_shape1: unit -> swfShape
    (** {!SWF.Morph.get_shape1} *)
    method get_shape2: unit -> swfShape
    (** {!SWF.Morph.get_shape2} *)
    method get_morph: unit -> morph
  end

(* }}} *)
(* {{{ class swfMovie *)

type item = SWFShape of swfShape | SWFMorph of swfMorph

class swfMovie :
  object
    val mutable filesize : int option
    val movie: movie
    method add: block:item -> swfDisplayItem
    method set_dimension: x:float -> y:float -> unit
    method set_background: r:int -> g:int -> b:int -> unit
    method save: filename:string -> unit
    method get_filesize: unit -> int option
    method set_rate: rate:float -> unit
    method next_frame: unit -> unit
  end

(* }}} *)

end (* 00  }}} *)
(*
(* {{{ module SWF *)

module SWF : sig



end (* SWF  }}} *)
*)
(* vim: sw=4 sts=4 ts=4 et fdm=marker
 *)
