(*  Copyright (C) 1997-2006  the PHP Documentation Group
  This exemple was converted from a PHP exemple found at:
  http://www.php.net/manual/en/function.swfshape.setline.php
  which is available under  Open Publication License:
  http://www.opencontent.org/openpub/  *)

open SWF
open OO

let () =
  let s = new swfShape() in
  let f1 = s#add_fill ~r:0xff ~g:0    ~b:0    ~a:0x7f in
  let f2 = s#add_fill ~r:0xff ~g:0x7f ~b:0    ~a:0x7f in
  let f3 = s#add_fill ~r:0xff ~g:0xff ~b:0    ~a:0x7f in
  let f4 = s#add_fill ~r:0    ~g:0xff ~b:0    ~a:0x7f in
  let f5 = s#add_fill ~r:0    ~g:0    ~b:0xff ~a:0x7f in

  (* {{{ bug: have to declare all line styles before you use them

  s#set_line ~width:40  ~r:0x7f ~g:0  ~b:0  ~a:0x7f;
  s#set_line ~width:40  ~r:0x7f ~g:0x3f ~b:0 ~a:0x7f;
  s#set_line ~width:40  ~r:0x7f ~g:0x7f ~b:0 ~a:0x7f;
  s#set_line ~width:40  ~r:0  ~g:0x7f ~b:0  ~a:0x7f;
  s#set_line ~width:40  ~r:0  ~g:0  ~b:0x7f ~a:0x7f;
  }}} *)

  (* {{{
  ./ming-fonts-1.00/fdb/
  Bitstream Vera Sans Mono-B-I.fdb  Bitstream Vera Sans Mono.fdb  Bitstream Vera Sans-I.fdb   Bitstream Vera Serif.fdb
  Bitstream Vera Sans Mono-B.fdb    Bitstream Vera Sans-B-I.fdb   Bitstream Vera Sans.fdb
  Bitstream Vera Sans Mono-I.fdb    Bitstream Vera Sans-B.fdb     Bitstream Vera Serif-B.fdb
  }}} *)
  let filename = "./ming-fonts-1.00/fdb/Bitstream Vera Serif.fdb" in
  let font = new swfFont ~filename in

  s#set_right_fill ~fill:f1;
  s#set_line ~width:40  ~r:0x7f ~g:0 ~b:0 ~a:0x7f;
  s#draw_glyph ~font  ~c:'!';
  s#move_pen ~x:(font#get_width "!")  ~y:0.0;

  s#set_right_fill ~fill:f2;
  s#set_line ~width:40  ~r:0x7f ~g:0x3f ~b:0 ~a:0x7f;
  s#draw_glyph ~font  ~c:'#';
  s#move_pen ~x:(font#get_width "#")  ~y:0.0;

  s#set_right_fill ~fill:f3;
  s#set_line ~width:40  ~r:0x7f ~g:0x7f ~b:0 ~a:0x7f;
  s#draw_glyph ~font  ~c:'%';
  s#move_pen ~x:(font#get_width "%")  ~y:0.0;

  s#set_right_fill ~fill:f4;
  s#set_line ~width:40  ~r:0 ~g:0x7f ~b:0 ~a:0x7f;
  s#draw_glyph ~font  ~c:'*';
  s#move_pen ~x:(font#get_width "*")  ~y:0.0;

  s#set_right_fill ~fill:f5;
  s#set_line ~width:40  ~r:0 ~g:0 ~b:0x7f ~a:0x7f;
  s#draw_glyph ~font  ~c:'@';

  let m = new swfMovie in
  m#set_dimension ~x:3000.0 ~y:2000.0;
  m#set_rate ~rate:12.0;
  let i = m#add ~block:(SWFShape s) in
  i#move_to ~x:(1500.0 -. (font#get_width "!#%*@") /. 2.0)
            ~y:(1000.0 +. (font#get_ascent()) /. 2.0);

  let size = m#save ~filename:"set_line.ml.swf" in
  ignore(size);

(* vim: sw=2 sts=2 ts=2 et fdm=marker
 *)
