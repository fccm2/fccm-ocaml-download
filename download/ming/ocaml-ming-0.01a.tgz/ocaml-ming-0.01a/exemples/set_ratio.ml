(*  Copyright (C) 1997-2006  the PHP Documentation Group
  This exemple was converted from a PHP exemple found at:
  http://www.php.net/manual/en/function.swfdisplayitem.setratio.php
  which is available under  Open Publication License:
  http://www.opencontent.org/openpub/  *)

open SWF
open OO

let _ =
  let p = new swfMorph in

  let g = new swfGradient in
  g#add_entry 0.00  0  0  0  185;
  g#add_entry 0.16  0xff  0xff  0xff  185;
  g#add_entry 0.32  0  0  0  185;
  g#add_entry 0.48  0xff  0xff  0xff  185;
  g#add_entry 0.64  0  0  0  185;
  g#add_entry 0.80  0xff  0xff  0xff  185;
  g#add_entry 1.00  0  0  0  185;

  let s = p#get_shape1() in
  let f = s#add_radial_gradient_fill g in
  f#scale_to 0.05;
  s#set_left_fill f;
  s#move_pen_to (-160.) (-120.);
  s#draw_line 320.  0.;
  s#draw_line 0.  240.;
  s#draw_line (-320.)  0.;
  s#draw_line 0.  (-240.);

  let g = new swfGradient in
  g#add_entry 0.00  0  0  0  185;
  g#add_entry 0.16  0xff  0  0  185;
  g#add_entry 0.32  0  0  0  185;
  g#add_entry 0.48  0  0xff  0  185;
  g#add_entry 0.64  0  0  0  185;
  g#add_entry 0.80  0  0  0xff  185;
  g#add_entry 1.00  0  0  0  185;

  let s = p#get_shape2() in
  let f = s#add_radial_gradient_fill g  in
  f#scale_to 0.05;
  f#skew_x_to 1.0;
  s#set_left_fill f;
  s#move_pen_to (-160.)  (-120.);
  s#draw_line 320.  0.;
  s#draw_line 0.  240.;
  s#draw_line (-320.)  0.;
  s#draw_line 0.  (-240.);

  let m = new swfMovie in
  m#set_dimension 320.  240.;
  let i = m#add (SWFMorph p) in
  i#move_to 160.  120.;

  for n = 0 to 101 do
   let ratio = (float n /. 100.0) in
   i#set_ratio ~ratio;
   m#next_frame();
  done;

  m#save "set_ratio.ml.swf";

