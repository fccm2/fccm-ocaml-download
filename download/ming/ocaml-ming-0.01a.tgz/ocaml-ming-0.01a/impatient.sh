
make

ocaml SWF.cma  exemples/set_ratio.ml

make display  F=set_ratio.ml.swf


