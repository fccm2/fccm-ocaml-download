/* {{{ COPYING 
 *
 * +-----------------------------------------------------------------+
 * | Copyright (C) 2006  Florent Monnier                             |
 * +-----------------------------------------------------------------+
 * | This wraper is an attempt of a Ming binding for Objective Caml. |
 * +-----------------------------------------------------------------+
 * |                                                                 |
 * | This program is free software; you can redistribute it and/or   |
 * | modify it under the terms of the GNU General Public License     |
 * | as published by the Free Software Foundation; either version 2  |
 * | of the License, or (at your option) any later version.          |
 * |                                                                 |
 * | This program is distributed in the hope that it will be useful, |
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
 * | GNU General Public License for more details.                    |
 * |                                                                 |
 * | http://www.fsf.org/licensing/licenses/gpl.html                  |
 * |                                                                 |
 * | You should have received a copy of the GNU General Public       |
 * | License along with this program; if not,                        |
 * | write to the Free Software Foundation, Inc.,                    |
 * | 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA    |
 * |                                                                 |
 * +-----------------------------------------------------------------+
 * | Author: Florent Monnier <fmonnier@linux-nantes.fr.eu.org>       |
 * +-----------------------------------------------------------------+
 *
 * $Id$
 * }}} */

/* {{{ headers */

#include <stdlib.h>
#include <stdio.h>

#include <ming.h>

#include <caml/memory.h>
#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/compatibility.h>

/* }}} */
/* {{{ id */

CAMLprim value
ml_id( value id )
{
    CAMLparam1( id );
    CAMLreturn( id );
}
/* }}} */

/* {{{ ===== General Ming functions === */

/* {{{ Ming_init */

CAMLprim value
ml_ming_init( value unit )
{
    CAMLparam1( unit );

    int st = Ming_init();

    CAMLreturn( Int_val(st) );
}
/* }}} */
/* {{{ Ming_cleanup */

CAMLprim value
ml_ming_cleanup( value unit)
{
    CAMLparam1( unit );

    Ming_cleanup();

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ Ming_collectGarbage */

CAMLprim value
ml_ming_collectgarbage( value unit )
{
    CAMLparam1( unit );

    Ming_collectGarbage();

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ Ming_setCubicThreshold */

CAMLprim value
ml_ming_setcubicthreshold( value num )
{
    CAMLparam1( num );

    Ming_setCubicThreshold( Int_val(num) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ Ming_setScale */

CAMLprim value
ml_ming_setscale( value scale )
{
    CAMLparam1( scale );

    Ming_setScale( Double_val(scale) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ Ming_getScale */

CAMLprim value
ml_ming_getscale( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_scale );

    float scale = Ming_getScale();

    ml_scale = caml_copy_double( scale );

    CAMLreturn( ml_scale );
}
/* }}} */
/* {{{ Ming_useSWFVersion */

CAMLprim value
ml_ming_useswfversion( value version )
{
    CAMLparam1( version );

    Ming_useSWFVersion( Int_val(version) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ Ming_setSWFCompression */

CAMLprim value
ml_ming_setswfcompression( value level )
{
    CAMLparam1( level );

    int prev_comp = Ming_setSWFCompression( Int_val(level) );

    CAMLreturn( Val_int(prev_comp) );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFInput === */

/* {{{ newSWFInput_file */

CAMLprim value
ml_newswfinput_file( value filename, value modes )
{
    CAMLparam2( filename, modes );
    CAMLlocal1( ml_input );

    FILE *fp;

    fp = fopen( String_val(filename), String_val(modes) );

    SWFInput input = newSWFInput_file( fp );

    ml_input = caml_alloc(2, Abstract_tag);
    Store_field( ml_input, 0, (value)input );
    Store_field( ml_input, 1, (value)fp );

    CAMLreturn( ml_input );
}
/* }}} */
/* {{{ destroySWFInput */

CAMLprim value
ml_destroyswfinput( value ml_input )
{
    CAMLparam1( ml_input );

    SWFInput input;
    input = (SWFInput) Field(ml_input,0);

    destroySWFInput( input );


    FILE *fp;
    fp = (FILE *) Field(ml_input,1);

    int st = fclose( fp );
    printf(" fclose: '%d'\n", st); fflush(stdout);

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFInput_length */

CAMLprim value
ml_swfinput_length( value ml_input )
{
    CAMLparam1( ml_input );

    SWFInput input;
    input = (SWFInput) Field(ml_input,0);

    int len = SWFInput_length( input );

    CAMLreturn( Int_val(len) );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFCharacter === */

/* {{{ SWFCharacter_getWidth */

CAMLprim value
ml_swfcharacter_getwidth( value ml_character )
{
    CAMLparam1( ml_character );

    SWFCharacter character;
    character = (SWFCharacter) Field(ml_character,0);

    float width = SWFCharacter_getWidth( character );

    CAMLreturn( Val_long(width) );
}
/* }}} */
/* {{{ SWFCharacter_getHeight */

CAMLprim value
ml_swfcharacter_getheight( value ml_character )
{
    CAMLparam1( ml_character );

    SWFCharacter character;
    character = (SWFCharacter) Field(ml_character,0);

    float height = SWFCharacter_getHeight( character );

    CAMLreturn( Val_long(height) );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFBitmap === */

/* {{{ newSWFBitmap_fromInput */

CAMLprim value
ml_newswfbitmap_frominput( value ml_input )
{
    CAMLparam1( ml_input );
    CAMLlocal1( ml_bitmap );

    SWFInput input;
    input = (SWFInput) Field(ml_input,0);

    SWFBitmap bitmap = newSWFBitmap_fromInput( input );

    ml_bitmap = caml_alloc(1, Abstract_tag);
    Store_field( ml_bitmap, 0, (value)bitmap );

    CAMLreturn( ml_bitmap );
}
/* }}} */
/* {{{ destroySWFBitmap */

CAMLprim value
ml_destroyswfbitmap( value ml_bitmap )
{
    CAMLparam1( ml_bitmap );

    SWFBitmap bitmap;
    bitmap = (SWFBitmap) Field(ml_bitmap,0);

    destroySWFBitmap( bitmap );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFBitmap_getWidth */

CAMLprim value
ml_swfbitmap_getwidth( value ml_bitmap )
{
    CAMLparam1( ml_bitmap );

    SWFBitmap bitmap;
    bitmap = (SWFBitmap) Field(ml_bitmap,0);

    int width = SWFBitmap_getWidth( bitmap );

    CAMLreturn( Int_val(width) );
}
/* }}} */
/* {{{ SWFBitmap_getHeight */

CAMLprim value
ml_swfbitmap_getheight( value ml_bitmap )
{
    CAMLparam1( ml_bitmap );

    SWFBitmap bitmap;
    bitmap = (SWFBitmap) Field(ml_bitmap,0);

    int height = SWFBitmap_getHeight( bitmap );

    CAMLreturn( Int_val(height) );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFDBLBitmap === */

/* TODO */

/* }}} */
/* {{{ ===== SWFJpegBitmap === */

/* {{{ newSWFJpegBitmap */

CAMLprim value
ml_newswfjpegbitmap( value filename, value modes )
{
    CAMLparam2( filename, modes );
    CAMLlocal1( ml_jpeg );

    FILE *fp;
    fp = fopen( String_val(filename), String_val(modes) );

    SWFJpegBitmap jpeg = newSWFJpegBitmap( fp );

    int st = fclose( fp );
    printf(" fclose: '%d'\n", st); flush(stdout);

    ml_jpeg = caml_alloc(1, Abstract_tag);
    Store_field( ml_jpeg, 0, (value)jpeg );

    CAMLreturn( ml_jpeg );
}
/* }}} */

#if 0
{{{ TODO 
SWFJpegBitmap newSWFJpegBitmap_fromInput(SWFInput input);

SWFJpegWithAlpha newSWFJpegWithAlpha(FILE *f, FILE *alpha);
SWFJpegWithAlpha newSWFJpegWithAlpha_fromInput(SWFInput input, SWFInput alpha);
}}}
#endif

/* }}} */
/* {{{ ===== SWFGradient === */

/* {{{ newSWFGradient */

CAMLprim value
ml_newswfgradient( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_gradient );

    SWFGradient gradient = newSWFGradient();

    ml_gradient = caml_alloc(1, Abstract_tag);
    Store_field( ml_gradient, 0, (value)gradient );

    CAMLreturn( ml_gradient );
}
/* }}} */
/* {{{ destroySWFGradient */

CAMLprim value
ml_destroyswfgradient( value ml_gradient )
{
    CAMLparam1( ml_gradient );

    SWFGradient gradient;
    gradient = (SWFGradient) Field(ml_gradient,0);

    destroySWFGradient( gradient );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFGradient_addEntry */

CAMLprim value
ml_swfgradient_addentry_native(
        value ml_gradient,
        value ratio,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( ml_gradient, ratio, red, green, blue );

    SWFGradient gradient;
    gradient = (SWFGradient) Field(ml_gradient,0);

    SWFGradient_addEntry( gradient, Double_val(ratio),
                    (byte) Int_val(red),
                    (byte) Int_val(green),
                    (byte) Int_val(blue),
                    (byte) Int_val(alpha) );

    CAMLreturn( Val_unit );
}

CAMLprim value
ml_swfgradient_addentry_bytecode(value * argv, int argn)
{
      return ml_swfgradient_addentry_native(
                argv[0],  argv[1],  argv[2],  argv[3],  argv[4],  argv[5] );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFFillStyle === */

/* {{{ newSWFSolidFillStyle */

CAMLprim value
ml_newswfsolidfillstyle(
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam4( red, green, blue, alpha );
    CAMLlocal1( ml_fill_style );

    SWFFillStyle fillStyle =
        newSWFSolidFillStyle(
                (byte) Int_val(red),
                (byte) Int_val(green),
                (byte) Int_val(blue),
                (byte) Int_val(alpha) );

    ml_fill_style = caml_alloc(1, Abstract_tag);
    Store_field( ml_fill_style, 0, (value) fillStyle);

    CAMLreturn( ml_fill_style );
}
/* }}} */

#if 0
{{{
#define SWFFILL_SOLID                   0x00
#define SWFFILL_GRADIENT                0x10
#define SWFFILL_LINEAR_GRADIENT         0x10
#define SWFFILL_RADIAL_GRADIENT         0x12
#define SWFFILL_BITMAP                  0x40
#define SWFFILL_TILED_BITMAP            0x40
#define SWFFILL_CLIPPED_BITMAP          0x41

SWFFillStyle newSWFGradientFillStyle(SWFGradient gradient, byte radial);
SWFFillStyle newSWFBitmapFillStyle(SWFCharacter bitmap, byte flags);

SWFMatrix SWFFillStyle_getMatrix(SWFFillStyle fill);
}}}
#endif

/* }}} */
/* {{{ ===== SWFLineStyle === */

/* {{{ newSWFLineStyle */

CAMLprim value
ml_newswflinestyle(
        value width,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( width, red, green, blue, alpha );
    CAMLlocal1( ml_line_style );

    SWFLineStyle lineStyle = 
        newSWFLineStyle(
                Int_val(width),
                (byte) Int_val(red),
                (byte) Int_val(green),
                (byte) Int_val(blue),
                (byte) Int_val(alpha) );

    ml_line_style = caml_alloc(1, Abstract_tag);
    Store_field( ml_line_style, 0, (value) lineStyle);

    CAMLreturn( ml_line_style );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFShape === */

/* {{{ newSWFShape */

CAMLprim value
ml_newswfshape( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_shape );

    SWFShape shape = newSWFShape();

    ml_shape = caml_alloc(1, Abstract_tag);
    Store_field( ml_shape, 0, (value)shape );

    CAMLreturn( ml_shape );
}
/* }}} */
/* {{{ destroySWFShape */

CAMLprim value
ml_destroyswfshape( value ml_shape )
{
    CAMLparam1( ml_shape );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    destroySWFShape( shape );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_addSolidFill */

CAMLprim value
ml_swfshape_addsolidfill(
        value ml_shape,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( ml_shape, red, green, blue, alpha );
    CAMLlocal1( ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFill fill =
        SWFShape_addSolidFill( shape,
                    (byte) Int_val(red),
                    (byte) Int_val(green),
                    (byte) Int_val(blue),
                    (byte) Int_val(alpha) );

    ml_fill = caml_alloc(1, Abstract_tag);
    Store_field( ml_fill, 0, (value) fill );

    CAMLreturn( ml_fill );
}
/* }}} */
/* {{{ SWFShape_setLine */

CAMLprim value
ml_swfshape_setline_native(
        value ml_shape,
        value width,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( ml_shape, width, red, green, blue );
    CAMLxparam1( alpha );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_setLine( shape, Int_val(width),
                    (byte) Int_val(red),
                    (byte) Int_val(green),
                    (byte) Int_val(blue),
                    (byte) Int_val(alpha) );

    CAMLreturn( Val_unit );
}

CAMLprim value
ml_swfshape_setline_bytecode(value * argv, int argn)
{
      return ml_swfshape_setline_native(
                argv[0],  argv[1],  argv[2],  argv[3],  argv[4],  argv[5] );
}
/* }}} */
/* {{{ SWFShape_setLineStyle */

CAMLprim value
ml_swfshape_setlinestyle_native(
        value ml_shape,
        value width,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( ml_shape, width, red, green, blue );
    CAMLxparam1( alpha );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_setLineStyle( shape, Int_val(width),
                    (byte) Int_val(red),
                    (byte) Int_val(green),
                    (byte) Int_val(blue),
                    (byte) Int_val(alpha) );

    CAMLreturn( Val_unit );
}

CAMLprim value
ml_swfshape_setlinestyle_bytecode(value * argv, int argn)
{
      return ml_swfshape_setlinestyle_native(
                argv[0],  argv[1],  argv[2],  argv[3],  argv[4],  argv[5] );
}
/* }}} */
/* {{{ SWFShape_hideLine */

CAMLprim value
ml_swfshape_hideline( value ml_shape )
{
    CAMLparam1( ml_shape );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_hideLine( shape );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_movePen */

CAMLprim value
ml_swfshape_movepen( value ml_shape, value x, value y )
{
    CAMLparam3( ml_shape, x, y );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_movePen( shape, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_movePenTo */

CAMLprim value
ml_swfshape_movepento( value ml_shape, value x, value y )
{
    CAMLparam3( ml_shape, x, y );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_movePenTo( shape, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawLine */

CAMLprim value
ml_swfshape_drawline( value ml_shape, value dx, value dy )
{
    CAMLparam3( ml_shape, dx, dy );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawLine( shape, Double_val(dx), Double_val(dy) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawLineTo */

CAMLprim value
ml_swfshape_drawlineto( value ml_shape, value x, value y )
{
    CAMLparam3( ml_shape, x, y );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawLineTo( shape, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawCurve */

CAMLprim value
ml_swfshape_drawcurve(
        value ml_shape,
        value controldx,
        value controldy,
        value anchordx,
        value anchordy )
{
    CAMLparam5( ml_shape, controldx, controldy, anchordx, anchordy );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawCurve( shape,
                Double_val(controldx), Double_val(controldy),
                Double_val(anchordx),  Double_val(anchordy) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawCurveTo */

CAMLprim value
ml_swfshape_drawcurveto(
        value ml_shape,
        value controlx,
        value controly,
        value anchorx,
        value anchory )
{
    CAMLparam5( ml_shape, controlx, controly, anchorx, anchory );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawCurveTo( shape,
                Double_val(controlx), Double_val(controly),
                Double_val(anchorx),  Double_val(anchory) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawCircle */

CAMLprim value
ml_swfshape_drawcircle( value ml_shape, value r )
{
    CAMLparam2( ml_shape, r );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawCircle( shape, Double_val(r) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawArc */

CAMLprim value
ml_swfshape_drawarc( value ml_shape, value r, value startAngle, value endAngle )
{
    CAMLparam4( ml_shape, r, startAngle, endAngle );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFShape_drawArc( shape, Double_val(r), Double_val(startAngle), Double_val(endAngle) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_setLeftFill */

CAMLprim value
ml_swfshape_setleftfill( value ml_shape, value ml_fill )
{
    CAMLparam2( ml_shape, ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFShape_setLeftFill( shape, fill );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_setRightFill */

CAMLprim value
ml_swfshape_setrightfill( value ml_shape, value ml_fill )
{
    CAMLparam2( ml_shape, ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFShape_setRightFill( shape, fill );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_setLeftFillStyle */

CAMLprim value
ml_swfshape_setleftfillstyle( value ml_shape, value ml_fill )
{
    CAMLparam2( ml_shape, ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFillStyle fill;
    fill = (SWFFillStyle) Field(ml_fill,0);

    SWFShape_setLeftFillStyle( shape, fill );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_setRightFillStyle */

CAMLprim value
ml_swfshape_setrightfillstyle( value ml_shape, value ml_fill )
{
    CAMLparam2( ml_shape, ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFillStyle fill;
    fill = (SWFFillStyle) Field(ml_fill,0);

    SWFShape_setRightFillStyle( shape, fill );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_drawGlyph */

CAMLprim value
ml_swfshape_drawglyph( value ml_shape, value ml_font, value c )
{
    CAMLparam3( ml_shape, ml_font, c );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    SWFShape_drawGlyph( shape, font,
                (unsigned short) Int_val(c) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFShape_addGradientFill LINEAR */

CAMLprim value
ml_swfshape_addgradientfill_linear( value ml_shape, value ml_gradient )
{
    CAMLparam2( ml_shape, ml_gradient );
    CAMLlocal1( ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFGradient gradient;
    gradient = (SWFGradient) Field(ml_gradient,0);

    byte flags = SWFFILL_LINEAR_GRADIENT;

    SWFFill fill =
        SWFShape_addGradientFill( shape, gradient, flags );

    ml_fill = caml_alloc(1, Abstract_tag);
    Store_field( ml_fill, 0, (value) fill );

    CAMLreturn( ml_fill );
}
/* }}} */
/* {{{ SWFShape_addGradientFill RADIAL */

CAMLprim value
ml_swfshape_addgradientfill_radial( value ml_shape, value ml_gradient )
{
    CAMLparam2( ml_shape, ml_gradient );
    CAMLlocal1( ml_fill );

    SWFShape shape;
    shape = (SWFShape) Field(ml_shape,0);

    SWFGradient gradient;
    gradient = (SWFGradient) Field(ml_gradient,0);

    byte flags = SWFFILL_RADIAL_GRADIENT;

    SWFFill fill =
        SWFShape_addGradientFill( shape, gradient, flags );

    ml_fill = caml_alloc(1, Abstract_tag);
    Store_field( ml_fill, 0, (value) fill );

    CAMLreturn( ml_fill );
}
/* }}} */

#if 0
{{{
SWFFill SWFShape_addBitmapFill(SWFShape shape, SWFBitmap bitmap, byte flags);

/* draw character c from font font into shape shape at size size */
void SWFShape_drawSizedGlyph(SWFShape shape, SWFFont font, unsigned short c, int size);

/* approximate a cubic bezier with quadratic segments */
/* returns the number of segments used */
int SWFShape_drawCubic(SWFShape shape, float bx, float by,
                       float cx, float cy, float dx, float dy);
int SWFShape_drawCubicTo(SWFShape shape, float bx, float by,
                         float cx, float cy, float dx, float dy);
void SWFShape_drawCharacterBounds(SWFShape shape, SWFCharacter character);


/*
 * returns a shape containing the bitmap in a filled rect
 * flag can be SWFFILL_CLIPPED_BITMAP or SWFFILL_TILED_BITMAP
 */
SWFShape newSWFShapeFromBitmap(SWFBitmap bitmap, int flag);

void SWFShape_end(SWFShape shape);

float SWFShape_getPenX(SWFShape shape);
float SWFShape_getPenY(SWFShape shape);
void SWFShape_getPen(SWFShape shape, float* penX, float* penY);


SWFFillStyle SWFShape_addSolidFillStyle(SWFShape shape,
                                        byte r, byte g, byte b, byte a);
SWFFillStyle SWFShape_addGradientFillStyle(SWFShape shape,
                                           SWFGradient gradient, byte flags);
SWFFillStyle SWFShape_addBitmapFillStyle(SWFShape shape,
                                         SWFBitmap bitmap, byte flags);

}}}
#endif
/* }}} */
/* {{{ ===== SWFMorph === */

/* {{{ newSWFMorphShape */

CAMLprim value
ml_newswfmorphshape( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_morph );

    SWFMorph morph = newSWFMorphShape();

    ml_morph = caml_alloc(1, Abstract_tag);
    Store_field( ml_morph, 0, (value)morph );

    CAMLreturn( ml_morph );
}
/* }}} */
/* {{{ destroySWFMorph */

CAMLprim value
ml_destroyswfmorph( value ml_morph )
{
    CAMLparam1( ml_morph );

    SWFMorph morph;
    morph = (SWFMorph) Field(ml_morph,0);

    destroySWFMorph( morph );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMorph_getShape1 */

CAMLprim value
ml_swfmorph_getshape1( value ml_morph )
{
    CAMLparam1( ml_morph );
    CAMLlocal1( ml_shape );

    SWFMorph morph;
    morph = (SWFMorph) Field(ml_morph,0);

    SWFShape shape = SWFMorph_getShape1( morph );

    ml_shape = caml_alloc(1, Abstract_tag);
    Store_field( ml_shape, 0, (value)shape );

    CAMLreturn( ml_shape );
}
/* }}} */
/* {{{ SWFMorph_getShape2 */

CAMLprim value
ml_swfmorph_getshape2( value ml_morph )
{
    CAMLparam1( ml_morph );
    CAMLlocal1( ml_shape );

    SWFMorph morph;
    morph = (SWFMorph) Field(ml_morph,0);

    SWFShape shape = SWFMorph_getShape2( morph );

    ml_shape = caml_alloc(1, Abstract_tag);
    Store_field( ml_shape, 0, (value)shape );

    CAMLreturn( ml_shape );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFFont === */

/* {{{ newSWFFont */

CAMLprim value
ml_newswffont( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_font );

    SWFFont font = newSWFFont();

    ml_font = caml_alloc(1, Abstract_tag);
    Store_field( ml_font, 0, (value)font );

    CAMLreturn( ml_font );
}
/* }}} */
/* {{{ destroySWFFont */

CAMLprim value
ml_destroyswffont( value ml_font )
{
    CAMLparam1( ml_font );

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    destroySWFFont( font );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFont_getAscent */

CAMLprim value
ml_swffont_getascent( value ml_font )
{
    CAMLparam1( ml_font );
    CAMLlocal1( ml_ascent );

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    float ascent = SWFFont_getAscent( font );

    ml_ascent = caml_copy_double( ascent );

    CAMLreturn( ml_ascent );
}
/* }}} */
/* {{{ SWFFont_getDescent */

CAMLprim value
ml_swffont_getdescent( value ml_font )
{
    CAMLparam1( ml_font );
    CAMLlocal1( ml_descent );

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    float descent = SWFFont_getDescent( font );

    ml_descent = caml_copy_double( descent );

    CAMLreturn( ml_descent );
}
/* }}} */
/* {{{ SWFFont_getLeading */

CAMLprim value
ml_swffont_getleading( value ml_font )
{
    CAMLparam1( ml_font );
    CAMLlocal1( ml_leading );

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    float leading = SWFFont_getLeading( font );

    ml_leading = caml_copy_double( leading );

    CAMLreturn( ml_leading );
}
/* }}} */

// TODO: check these functions
/* {{{ loadSWFFontFromFile */

CAMLprim value
ml_loadswffontfromfile( value filename )
{
    CAMLparam1( filename );
    CAMLlocal1( ml_font );

    SWFFont font;

    FILE *file = fopen( String_val(filename), "r");

    if ( file == (FILE *)NULL ) {
        failwith("unable to open font");
    } else {
        font = loadSWFFontFromFile( file );

        int st = fclose(file);
    }
    // TODO: test me

    ml_font = caml_alloc(1, Abstract_tag);
    Store_field( ml_font, 0, (value)font );

    CAMLreturn( ml_font );
}
/* }}} */
/* {{{ SWFFont_getStringWidth */

CAMLprim value
ml_swffont_getstringwidth( value ml_font, value string )
{
    CAMLparam2( ml_font, string );
    CAMLlocal1( ml_width );

    SWFFont font;
    font = (SWFFont) Field(ml_font,0);

    float width =
        SWFFont_getStringWidth( font, (unsigned char *)String_val(string) );
    /* TODO: check the cast of the string
    float SWFFont_getStringWidth(SWFFont font, const unsigned char *string);
    */

    ml_width = caml_copy_double( width );

    CAMLreturn( ml_width );
}
/* }}} */

#if 0
{{{
float SWFFont_getUTF8StringWidth(SWFFont font, const unsigned char *string);

  /* deprecated? */
  float SWFFont_getWideStringWidth(SWFFont font, const unsigned short *string, int len);
  #define SWFFont_getWidth SWFFont_getStringWidth

char *SWFFont_getShape(SWFFont font, unsigned short code);
}}}
#endif
/* }}} */
/* {{{ ===== SWFAction === */

/* {{{ compileSWFActionCode */

CAMLprim value
ml_compileswfactioncode( value script )
{
    CAMLparam1( script );
    CAMLlocal1( ml_action );

    SWFAction action = compileSWFActionCode( String_val(script) );

    ml_action = caml_alloc(1, Abstract_tag);
    Store_field( ml_action, 0, (value)action );

    CAMLreturn( ml_action );
}
/* }}} */
/* {{{ destroySWFAction */

CAMLprim value
ml_destroyswfaction( value ml_action )
{
    CAMLparam1( ml_action );

    SWFAction action;
    action = (SWFAction) Field(ml_action,0);

    destroySWFAction( action );

    CAMLreturn( Val_unit );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFDisplayItem === */

/* {{{ SWFDisplayItem_setColorMult */

CAMLprim value
ml_swfdisplayitem_setcolormult(
        value ml_display_item,
        value red,
        value green,
        value blue,
        value alpha )
{
    CAMLparam5( ml_display_item, red, green, blue, alpha );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_setColorMult( display_item,
                    Double_val(red),
                    Double_val(green),
                    Double_val(blue),
                    Double_val(alpha) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_move */

CAMLprim value
ml_swfdisplayitem_move( value ml_display_item, value x, value y )
{
    CAMLparam3( ml_display_item, x, y );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_move( display_item, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_moveTo */

CAMLprim value
ml_swfdisplayitem_moveto( value ml_display_item, value x, value y )
{
    CAMLparam3( ml_display_item, x, y );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_moveTo( display_item, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_rotate */

CAMLprim value
ml_swfdisplayitem_rotate( value ml_display_item, value degrees )
{
    CAMLparam2( ml_display_item, degrees );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_rotate( display_item, Double_val(degrees) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_rotateTo */

CAMLprim value
ml_swfdisplayitem_rotateto( value ml_display_item, value degrees )
{
    CAMLparam2( ml_display_item, degrees );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_rotateTo( display_item, Double_val(degrees) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_scale */

CAMLprim value
ml_swfdisplayitem_scale( value ml_display_item, value x, value y )
{
    CAMLparam3( ml_display_item, x, y );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_scale( display_item, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_scaleTo */

CAMLprim value
ml_swfdisplayitem_scaleto( value ml_display_item, value x, value y )
{
    CAMLparam3( ml_display_item, x, y );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_scaleTo( display_item, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_skewX */

CAMLprim value
ml_swfdisplayitem_skewx( value ml_display_item, value x )
{
    CAMLparam2( ml_display_item, x );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_skewX( display_item, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_skewXTo */

CAMLprim value
ml_swfdisplayitem_skewxto( value ml_display_item, value x )
{
    CAMLparam2( ml_display_item, x );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_skewXTo( display_item, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFDisplayItem_setRatio */

CAMLprim value
ml_swfdisplayitem_setratio( value ml_display_item, value ratio )
{
    CAMLparam2( ml_display_item, ratio );

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFDisplayItem_setRatio( display_item, Double_val(ratio) );

    CAMLreturn( Val_unit );
}
/* }}} */

/* }}} */
/* {{{ ===== SWFFill === */

/* {{{ newSWFFill */

CAMLprim value
ml_newswffill( value ml_fill_style )
{
    CAMLparam1( ml_fill_style );
    CAMLlocal1( ml_fill );

    SWFFillStyle fill_style;
    fill_style = (SWFFillStyle) Field(ml_fill_style,0);

    SWFFill fill = newSWFFill( fill_style );

    ml_fill = caml_alloc(1, Abstract_tag);
    Store_field( ml_fill, 0, (value)fill );

    CAMLreturn( ml_fill );
}
/* }}} */
/* {{{ destroySWFFill */

CAMLprim value
ml_destroyswffill( value ml_fill )
{
    CAMLparam1( ml_fill );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    destroySWFFill( fill );

    CAMLreturn( Val_unit );
}
/* }}} */

/* {{{ SWFFill_scaleXYTo */

CAMLprim value
ml_swffill_scalexyto( value ml_fill, value x, value y )
{
    CAMLparam3( ml_fill, x, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleXYTo( fill, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_scaleXY */

CAMLprim value
ml_swffill_scalexy( value ml_fill, value x, value y )
{
    CAMLparam3( ml_fill, x, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleXY( fill, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_scaleXTo */

CAMLprim value
ml_swffill_scalexto( value ml_fill, value x )
{
    CAMLparam2( ml_fill, x );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleXTo( fill, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_scaleX */

CAMLprim value
ml_swffill_scalex( value ml_fill, value x )
{
    CAMLparam2( ml_fill, x );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleX( fill, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_scaleYTo */

CAMLprim value
ml_swffill_scaleyto( value ml_fill, value y )
{
    CAMLparam2( ml_fill, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleYTo( fill, Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_scaleY */

CAMLprim value
ml_swffill_scaley( value ml_fill, value y )
{
    CAMLparam2( ml_fill, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_scaleY( fill, Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */

/* {{{ SWFFill_skewXTo */

CAMLprim value
ml_swffill_skewxto( value ml_fill, value x )
{
    CAMLparam2( ml_fill, x );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_skewXTo( fill, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_skewX */

CAMLprim value
ml_swffill_skewx( value ml_fill, value x )
{
    CAMLparam2( ml_fill, x );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_skewX( fill, Double_val(x) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_skewYTo */

CAMLprim value
ml_swffill_skewyto( value ml_fill, value y )
{
    CAMLparam2( ml_fill, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_skewYTo( fill, Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_skewY */

CAMLprim value
ml_swffill_skewy( value ml_fill, value y )
{
    CAMLparam2( ml_fill, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_skewY( fill, Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */

/* {{{ SWFFill_moveTo */

CAMLprim value
ml_swffill_moveto( value ml_fill, value x, value y )
{
    CAMLparam3( ml_fill, x, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_moveTo( fill, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_move */

CAMLprim value
ml_swffill_move( value ml_fill, value x, value y )
{
    CAMLparam3( ml_fill, x, y );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_move( fill, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_rotateTo */

CAMLprim value
ml_swffill_rotateto( value ml_fill, value degrees )
{
    CAMLparam2( ml_fill, degrees );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_rotateTo( fill, Double_val(degrees) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFFill_rotate */

CAMLprim value
ml_swffill_rotate( value ml_fill, value degrees )
{
    CAMLparam2( ml_fill, degrees );

    SWFFill fill;
    fill = (SWFFill) Field(ml_fill,0);

    SWFFill_rotate( fill, Double_val(degrees) );

    CAMLreturn( Val_unit );
}
/* }}} */

#if 0
{{{
/* adds a position object to manipulate SWFFillStyle's matrix */


  /* Deprecated? */
  #define SWFFill_scale    SWFFill_scaleXY
  #define SWFFill_scaleTo  SWFFill_scaleXYTo


void SWFFill_setMatrix(SWFFill fill, float a, float b,
                       float c, float d, float x, float y);
}}}
#endif
/* }}} */
/* {{{ ===== SWFMovieClip === */

/* {{{ newSWFMovieClip */

CAMLprim value
ml_newswfmovieclip( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_movie_clip );

    SWFMovieClip movieClip = newSWFMovieClip();

    ml_movie_clip = caml_alloc(1, Abstract_tag);
    Store_field( ml_movie_clip, 0, (value)movieClip );

    CAMLreturn( ml_movie_clip );
}
/* }}} */
/* {{{ destroySWFMovieClip */

CAMLprim value
ml_destroyswfmovieclip( value ml_movie_clip )
{
    CAMLparam1( ml_movie_clip );

    SWFMovieClip movie_clip;
    movie_clip = (SWFMovieClip) Field(ml_movie_clip,0);

    destroySWFMovieClip( movie_clip );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovieClip_add */

CAMLprim value
ml_swfmovieclip_add( value ml_movie_clip, value ml_block )
{
    CAMLparam2( ml_movie_clip, ml_block );
    CAMLlocal1( ml_display_item );

    SWFMovieClip movie_clip;
    movie_clip = (SWFMovieClip) Field(ml_movie_clip,0);

    SWFBlock block;
    block = (SWFBlock) Field(ml_block,0);

    SWFDisplayItem displayItem =
        SWFMovieClip_add( movie_clip, block );

    ml_display_item = caml_alloc(1, Abstract_tag);
    Store_field( ml_display_item, 0, (value)displayItem );

    CAMLreturn( ml_display_item );
}
/* }}} */
/* {{{ SWFMovieClip_nextFrame */

CAMLprim value
ml_swfmovieclip_nextframe( value ml_movie_clip )
{
    CAMLparam1( ml_movie_clip );

    SWFMovieClip movie_clip;
    movie_clip = (SWFMovieClip) Field(ml_movie_clip,0);

    SWFMovieClip_nextFrame( movie_clip );

    CAMLreturn( Val_unit );
}
/* }}} */

#if 0
void SWFMovieClip_setNumberOfFrames(SWFMovieClip clip, int frames);
void SWFMovieClip_labelFrame(SWFMovieClip clip, const char *label);
#endif
/* }}} */
/* {{{ ===== SWFMovie === */

/* {{{ newSWFMovie */

CAMLprim value
ml_newswfmovie( value unit )
{
    CAMLparam1( unit );
    CAMLlocal1( ml_movie );

    SWFMovie movie = newSWFMovie();

    ml_movie = caml_alloc(1, Abstract_tag);
    Store_field( ml_movie, 0, (value)movie );

    CAMLreturn( ml_movie );
}
/* }}} */
/* {{{ destroySWFMovie */

CAMLprim value
ml_destroyswfmovie( value ml_movie )
{
    CAMLparam1( ml_movie );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    destroySWFMovie( movie );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovie_add */

CAMLprim value
ml_swfmovie_add( value ml_movie, value ml_block )
{
    CAMLparam2( ml_movie, ml_block );
    CAMLlocal1( ml_display_item );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFBlock block;
    block = (SWFBlock) Field(ml_block,0);

    SWFDisplayItem displayItem =
        SWFMovie_add( movie, block );

    ml_display_item = caml_alloc(1, Abstract_tag);
    Store_field( ml_display_item, 0, (value)displayItem );

    CAMLreturn( ml_display_item );
}
/* }}} */
/* {{{ SWFMovie_remove */

CAMLprim value
ml_swfmovie_remove( value ml_movie, value ml_display_item )
{
    CAMLparam2( ml_movie, ml_display_item );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFDisplayItem display_item;
    display_item = (SWFDisplayItem) Field(ml_display_item,0);

    SWFMovie_remove( movie, display_item );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovie_setBackground */

CAMLprim value
ml_swfmovie_setbackground(
        value ml_movie,
        value red,
        value green,
        value blue )
{
    CAMLparam4( ml_movie, red, green, blue );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFMovie_setBackground( movie,
                    (byte) Int_val(red),
                    (byte) Int_val(green),
                    (byte) Int_val(blue) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovie_setDimension */

CAMLprim value
ml_swfmovie_setdimension( value ml_movie, value x, value y )
{
    CAMLparam3( ml_movie, x, y );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFMovie_setDimension( movie, Double_val(x), Double_val(y) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovie_save */

CAMLprim value
ml_swfmovie_save( value ml_movie, value filename )
{
    CAMLparam2( ml_movie, filename );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    int st = SWFMovie_save( movie, String_val(filename) );

    CAMLreturn( Val_int(st) );
}
/* }}} */
/* {{{ SWFMovie_setRate */

CAMLprim value
ml_swfmovie_setrate( value ml_movie, value rate )
{
    CAMLparam2( ml_movie, rate );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFMovie_setRate( movie, Double_val(rate) );

    CAMLreturn( Val_unit );
}
/* }}} */
/* {{{ SWFMovie_nextFrame */

CAMLprim value
ml_swfmovie_nextframe( value ml_movie )
{
    CAMLparam1( ml_movie );

    SWFMovie movie;
    movie = (SWFMovie) Field(ml_movie,0);

    SWFMovie_nextFrame( movie );

    CAMLreturn( Val_unit );
}
/* }}} */

#if 0
{{{
SWFMovie newSWFMovieWithVersion(int version);
void SWFMovie_setNumberOfFrames(SWFMovie movie, int frames);
int SWFMovie_output(SWFMovie movie, SWFByteOutputMethod method, void *data);
}}}
#endif
/* }}} */

#if 0
/* {{{  */

CAMLprim value
ml_( value  )
{
    CAMLparam1(  );
    CAMLlocal1( ml_ );


    CAMLreturn(  );
}
/* }}} */
#endif

/* vim: sw=4 sts=4 ts=4 et fdm=marker
 */
