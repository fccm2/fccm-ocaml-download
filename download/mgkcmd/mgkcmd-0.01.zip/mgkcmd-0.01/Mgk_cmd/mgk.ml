(* Interface for an image-magick command-line tool. *)
(*
 To the extent permitted by law, you can use, modify, and redistribute
 this software.
*)
(* Author: Florent Monnier (2024) *)

(* a buffer to accumulate the pieces of the command *)
type t = Buffer.t

let new_genesis () =
  let b = Buffer.create 120 in
  Buffer.add_string b "convert";
  (b)

let input_image inimg b =
  let s = Printf.sprintf "%s" inimg in
  Buffer.add_string b (" " ^ s);
;;

let set_size ~wh:(w, h) b =
  let s = Printf.sprintf " %dx%d" w h in
  Buffer.add_string b (" -size" ^ s);
;;

let init_canvas c b =
  let s = Printf.sprintf "%s" c in
  Buffer.add_string b (" " ^ s);
;;

let set_filename s b =
  let s = Printf.sprintf "%s" s in
  Buffer.add_string b (" " ^ s);
;;

let set_fill s b =
  Buffer.add_string b (" -fill " ^ s);
;;

let set_stroke s b =
  Buffer.add_string b (" -stroke " ^ s);
;;

let draw_line (x1, y1) (x2, y2) b =
  let s = Printf.sprintf " \"line %d,%d %d,%d\"" x1 y1 x2 y2 in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_point (x, y) b =
  let s = Printf.sprintf " \"point %d,%d\"" x y in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_rectangle (x, y) (w, h) b =
  let s = Printf.sprintf " \"rectangle %d,%d %d,%d\"" x y (x + w) (y + h) in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_circle (cx, cy) (r) b =
  let s = Printf.sprintf " \"circle %d,%d %d,%d\"" cx cy (cx + r) cy in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_ellipse (cx, cy) (rx, ry) b =
  let s = Printf.sprintf " \"ellipse %d,%d %d,%d 0,360\"" cx cy rx ry in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_qbcurve (x1, y1) (x2, y2) (x3, y3) b =
  let s = Printf.sprintf " \"path 'M %d,%d Q %d,%d %d,%d'\"" x1 y1 x2 y2 x3 y3 in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_cbcurve (x1, y1) (x2, y2) (x3, y3) (x4, y4) b =
  let s = Printf.sprintf " \"path 'M %d,%d C %d,%d %d,%d %d,%d'\"" x1 y1 x2 y2 x3 y3 x4 y4 in
  Buffer.add_string b (" -draw" ^ s);
;;

let draw_polygon ps b =
  let ps = List.map (fun (x, y) -> Printf.sprintf "%d,%d" x y) ps in
  let s = Printf.sprintf " \"polygon %s\"" (String.concat " " ps) in
  Buffer.add_string b (" -draw" ^ s);
;;

let set_font font b =
  Buffer.add_string b (" -font " ^ font);
;;

let draw_text (x, y) words b =
  let s = Printf.sprintf " \"text %d,%d '%s'\"" x y words in
  Buffer.add_string b (" -draw" ^ s);
;;

let set_pointsize size b =
  let s = Printf.sprintf " %d" size in
  Buffer.add_string b (" -pointsize" ^ s);
;;

let set_strokewidth size b =
  let s = Printf.sprintf " %g" size in
  Buffer.add_string b (" -strokewidth" ^ s);
;;

let write_command b =
  print_endline (Buffer.contents b);
;;

(* layers *)

type comp_op = string

let over     = "Over"
let multiply = "Multiply"
let screen   = "Screen"
let overlay  = "Overlay"
let darken   = "Darken"
let lighten  = "Lighten"
let add      = "Add"
let subtract = "Subtract"

let plus     = "Plus"
let xor      = "Xor"
let atop     = "Atop"
let out      = "Out"
let src      = "Src"

let src_in   = "SrcIn"
let src_out  = "SrcOut"
let src_over = "SrcOver"

let dst_atop = "DstAtop"
let dst_over = "DstOver"
let dst_out  = "DstOut"

let divide_src = "DivideSrc"
let divide_dst = "DivideDst"

let minus_src = "MinusSrc"
let minus_dst = "MinusDst"

let dissolve = "Dissolve"
let difference = "Difference"

let color_burn = "ColorBurn"
let color_dodge = "ColorDodge"

let linear_burn = "LinearBurn"
let linear_dodge = "LinearDodge"

let hard_light = "HardLight"
let soft_light = "SoftLight"

let copy_opacity = "CopyOpacity"

let seamless_blend = "seamless-blend"

(* compositing documentation:
   https://imagemagick.org/Usage/compose/
 *)

let set_composite_op compop b =
  let s = Printf.sprintf " %s" compop in
  Buffer.add_string b (" -compose" ^ s);
;;

let composite b =
  Buffer.add_string b " -composite";
;;

let compositeop_of_string s = s

let open_layer f b =
  Buffer.add_string b " '('";
  f b;
  Buffer.add_string b " ')'";
;;

let set_geometry (x, y) b =
  let x = if x >= 0 then Printf.sprintf "+%d" x else Printf.sprintf "%d" x in
  let y = if y >= 0 then Printf.sprintf "+%d" y else Printf.sprintf "%d" y in
  Buffer.add_string b (Printf.sprintf " -geometry %s%s" x y);
;;

(* Filters *)

let negate b =
  Buffer.add_string b " -negate";
;;

let blur bv b =
  let s = Printf.sprintf " 0x%xd" bv in
  Buffer.add_string b (" -blur" ^ s);
;;

let normalize b =
  Buffer.add_string b " -normalize";
;;

let shade (a, c) b =
  let s = Printf.sprintf " %dx%d" a c in
  Buffer.add_string b (" -shade" ^ s);
;;

let modulate (bv, sv, hv) b =
  let s = Printf.sprintf " %d,%d,%d" bv sv hv in
  Buffer.add_string b (" -modulate" ^ s);
;;

