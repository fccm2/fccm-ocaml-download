(** Interface for image-magick commands *)
(*
 To the extent permitted by law, you can use, modify, and redistribute
 this software.
*)
(* Author: Florent Monnier (2024) *)

type t
(** holds the command in progress *)

val new_genesis : unit -> t
(** initialise the command for a set of operations *)

val input_image : string -> t -> unit
(** filename of an image to load *)

val set_size : wh:int * int -> t -> unit
(** set dimensions of an image, a canvas, or a layer *)

val init_canvas : string -> t -> unit
(** you can initialise a transparent image with: ["canvas:none"] *)

val set_filename : string -> t -> unit
(** set the filename of the image containing the result *)

val write_command : t -> unit
(** output the resulting command on stdout to produce the requested operations *)

(** {5 Draw} *)
(** draw commands *)

val draw_line : int * int -> int * int -> t -> unit
(** draw operation with a line command *)

val draw_point : int * int -> t -> unit
(** draw operation with a point command *)

val draw_rectangle : int * int -> int * int -> t -> unit
(** draw operation with a rectangle command *)

val draw_circle : int * int -> int -> t -> unit
(** draw operation with a circle command *)

val draw_ellipse : int * int -> int * int -> t -> unit
(** draw operation with a ellipse command *)

val draw_qbcurve : int * int -> int * int -> int * int -> t -> unit
(** draw operation with a quadratic bezier curve command *)

val draw_cbcurve : int * int -> int * int -> int * int -> int * int -> t -> unit
(** draw operation with a cubic bezier curve command *)

val draw_polygon : (int * int) list -> t -> unit
(** draw operation with a rectangle command *)

val draw_text : (int * int) -> string -> t -> unit
(** draw operation with a text command *)

val set_font : string -> t -> unit
(** set the font for the draw-text operation *)

val set_pointsize : int -> t -> unit
(** set the size of the text in points *)

val set_strokewidth : float -> t -> unit
(** set the stroke-width for the draw operations *)

val set_fill : string -> t -> unit
(** set the fill color for the draw operations *)

val set_stroke : string -> t -> unit
(** set the stroke color for the draw operations *)

(** {5 Layers} *)
(** combine different layers *)

type comp_op = string
(** composite operator *)

val over : comp_op
val multiply : comp_op
val screen : comp_op
val overlay : comp_op
val darken : comp_op
val lighten : comp_op
val add : comp_op
val subtract : comp_op
(** most common composite operators *)

val compositeop_of_string : string -> comp_op
(** get a composite operator parameter from a string
    (read the image-magick documentation for a list of composite-operators) *)

val set_composite_op : comp_op -> t -> unit
(** select a composite operator *)

val composite : t -> unit
(** composite operation *)

val open_layer : (t -> unit) -> t -> unit
(** open a new layer *)

val set_geometry : int * int -> t -> unit
(** sets the position for the composition of a layer *)

(** {5 Filters} *)

val negate : t -> unit
val blur : int -> t -> unit
val normalize : t -> unit
val shade : int * int -> t -> unit

val modulate : int * int * int -> t -> unit
(** modulate, with brightness, saturation, hue parameters *)

