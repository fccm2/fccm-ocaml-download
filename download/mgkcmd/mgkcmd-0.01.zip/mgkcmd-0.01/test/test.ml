
let test1 () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(120, 90) mgk;
  Mgk.init_canvas "canvas:none" mgk;
  Mgk.set_filename "test1.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 120x90 canvas:none test1.png
*)

let test2 () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(120, 90) mgk;
  Mgk.init_canvas "canvas:none" mgk;
  Mgk.draw_line (20, 20) (80, 60) mgk;
  Mgk.set_filename "test2.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 120x90 canvas:none -draw "line 20,20 80,60" test2.png
*)

let test3 () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(120, 90) mgk;
  Mgk.init_canvas "canvas:none" mgk;
  Mgk.set_fill "blue" mgk;
  Mgk.set_stroke "black" mgk;
  Mgk.draw_rectangle (80, 10) (30, 20) mgk;
  Mgk.draw_circle (60, 60) 12 mgk;
  Mgk.draw_polygon [(10, 10); (20, 80); (30, 40); (40, 60); (50, 30)] mgk;
  Mgk.set_filename "test3.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 120x90 canvas:none -fill blue -stroke black \
    -draw "rectangle 80,10 110,30" \
    -draw "circle 60,60 72,60" \
    -draw "polygon 10,10 20,80 30,40 40,60 50,30" \
    test3.png
*)

let test4 () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(120, 90) mgk;
  Mgk.init_canvas "canvas:none" mgk;
  Mgk.set_fill "blue" mgk;
  Mgk.set_stroke "black" mgk;
  Mgk.draw_ellipse (80, 25) (30, 20) mgk;
  Mgk.set_font "Generic.ttf" mgk;
  Mgk.set_pointsize 24 mgk;
  Mgk.draw_text (10, 70) "magick" mgk;
  Mgk.set_filename "test4.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 120x90 canvas:none -fill blue -stroke black \
    -draw "ellipse 80,25 30,20 0,360" \
    -font Generic.ttf -pointsize 16 -draw "text 10,70 'magick-words'" \
    test4.png
*)

let test5 () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(200, 200) mgk;
  Mgk.init_canvas "xc:white" mgk;
  Mgk.set_fill "none" mgk;
  Mgk.set_stroke "blue" mgk;
  Mgk.set_strokewidth 2.0 mgk;
  Mgk.draw_qbcurve (10, 150) (50, 10) (150, 150) mgk;
  Mgk.draw_cbcurve (10, 150) (20, 50) (180, 50) (190, 150) mgk;
  Mgk.set_filename "test5.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 200x200 xc:white -fill none -stroke blue -strokewidth 2 \
    -draw "path 'M 10,150 Q 50,10 150,150'" \
    -draw "path 'M 10,150 C 20,50 180,50 190,150'" \
    test5.png
*)

(* should produce the result:
*)

let test6 () =
  let mgk = Mgk.new_genesis () in

  (* red-circle *)
  Mgk.set_size ~wh:(60, 60) mgk;
  Mgk.init_canvas "xc:none" mgk;

  Mgk.set_fill "red" mgk;
  Mgk.set_stroke "none" mgk;
  Mgk.draw_circle (30, 21) 18 mgk;

  Mgk.set_filename "comp_r.png" mgk;
  Mgk.write_command mgk;
;;


let test7 () =
  let mgk = Mgk.new_genesis () in

  (* green-circle *)
  Mgk.set_size ~wh:(60, 60) mgk;
  Mgk.init_canvas "xc:none" mgk;

  Mgk.set_fill "lime" mgk;
  Mgk.set_stroke "none" mgk;
  Mgk.draw_circle (39, 39) 18 mgk;

  Mgk.set_filename "comp_g.png" mgk;
  Mgk.write_command mgk;
;;


let test8 () =
  let mgk = Mgk.new_genesis () in

  (* blue-circle *)
  Mgk.set_size ~wh:(60, 60) mgk;
  Mgk.init_canvas "xc:none" mgk;

  Mgk.set_fill "blue" mgk;
  Mgk.set_stroke "none" mgk;
  Mgk.draw_circle (21, 39) 18 mgk;

  Mgk.set_filename "comp_b.png" mgk;
  Mgk.write_command mgk;
;;


let test9 () =
  let mgk = Mgk.new_genesis () in

  (* red-circle *)
  begin
    Mgk.set_size ~wh:(60, 60) mgk;
    Mgk.init_canvas "xc:none" mgk;
    Mgk.set_fill "red" mgk;
    Mgk.set_stroke "none" mgk;
    Mgk.draw_circle (30, 21) 18 mgk;
  end;

  (* green-circle *)
  Mgk.open_layer (fun mgk ->
    Mgk.set_size ~wh:(60, 60) mgk;
    Mgk.init_canvas "xc:none" mgk;
    Mgk.set_fill "lime" mgk;
    Mgk.set_stroke "none" mgk;
    Mgk.draw_circle (39, 39) 18 mgk;
  ) mgk;

  Mgk.set_composite_op "plus" mgk;
  Mgk.composite mgk;

  (* blue-circle *)
  Mgk.open_layer (fun mgk ->
    Mgk.set_size ~wh:(60, 60) mgk;
    Mgk.init_canvas "xc:none" mgk;
    Mgk.set_fill "blue" mgk;
    Mgk.set_stroke "none" mgk;
    Mgk.draw_circle (21, 39) 18 mgk;
  ) mgk;

  Mgk.set_composite_op "plus" mgk;
  Mgk.composite mgk;

  Mgk.set_filename "test9.png" mgk;
  Mgk.write_command mgk;
;;


let () =
  test9 ();
;;

