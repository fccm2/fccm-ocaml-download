Interface for command-line tool of ImageMagick, from the ocaml programming and
scripting language.
