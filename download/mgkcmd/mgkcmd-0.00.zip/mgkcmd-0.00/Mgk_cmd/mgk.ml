module Mgk = struct
  let new_genesis () =
    let b = Buffer.create 120 in
    Buffer.add_string b "convert";
    (b)

  let set_size ~wh:(w, h) b =
    let s = Printf.sprintf " %dx%d" w h in
    Buffer.add_string b (" -size" ^ s);
  ;;

  let init_canvas c b =
    let s = Printf.sprintf "%s" c in
    Buffer.add_string b (" " ^ s);
  ;;

  let set_filename s b =
    let s = Printf.sprintf "%s" s in
    Buffer.add_string b (" " ^ s);
  ;;

  let write_command b =
    print_endline (Buffer.contents b);
  ;;
end

let () =
  let mgk = Mgk.new_genesis () in
  Mgk.set_size ~wh:(120, 90) mgk;
  Mgk.init_canvas "canvas:none" mgk;
  Mgk.set_filename "test1.png" mgk;
  Mgk.write_command mgk;
;;

(* should produce the result:
convert -size 120x90 canvas:none test1.png
*)
